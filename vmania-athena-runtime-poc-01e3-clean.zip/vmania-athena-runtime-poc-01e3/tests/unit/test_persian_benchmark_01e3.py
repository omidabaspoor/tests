import json
from pathlib import Path

import httpx
import pytest

from athena_runtime.providers.errors import StructuredOutputUnsupported
from athena_runtime.providers.gapgpt_chat import ChatUsage
from athena_runtime.providers.gapgpt_structured import (
    STRUCTURED_MAX_OUTPUT_TOKENS,
    GapGPTStructuredOutputClient,
    StructuredChatResponse,
)
from athena_runtime.providers.persian_benchmark import (
    BENCHMARK_CASES,
    BENCHMARK_MODELS,
    HARD_LOGICAL_CALL_CAP,
    PAIR_PLAN,
    BenchmarkRecord,
    BenchmarkSummary,
    ModelObservation,
    _field_scores,
    requirement_evidence,
    run_benchmark,
    write_benchmark,
)
from athena_runtime.providers.structured_diagnostic import parse_structured_content
from athena_runtime.providers.structured_prompt import (
    STRUCTURED_PROMPT_HASH,
    STRUCTURED_PROMPT_VERSION,
)
from athena_runtime.providers.structured_schema import (
    SCHEMA_HASH,
    SCHEMA_VERSION,
    UNDERSTANDING_JSON_SCHEMA,
)

MOCK_SECRET = "mock-benchmark-secret-not-real"


def content_for(
    case_id: str,
    *,
    extra: dict[str, object] | None = None,
) -> str:
    values = {
        "B01": {
            "task_type": "research",
            "goal_summary": "پیج نیاز به لینک یا اسکرین شات دارد که نفرستاده شده",
            "slots": [
                {
                    "name": "evidence",
                    "value": None,
                    "status": "unknown",
                    "confidence": 0.0,
                }
            ],
            "conflicts": [],
            "missing_hard_slots": ["evidence"],
            "should_clarify": True,
            "clarification_slot": "evidence",
            "freshness": "periodic",
            "risk_category": "low",
            "warning_required": False,
            "required_capability": "web_research",
        },
        "B02": {
            "task_type": "image_edit",
            "goal_summary": "عکس ورودی برای ویرایش هنوز نفرستاده شده نیست",
            "slots": [
                {
                    "name": "input_image",
                    "value": None,
                    "status": "unknown",
                    "confidence": 0.0,
                }
            ],
            "conflicts": [],
            "missing_hard_slots": ["input_image"],
            "should_clarify": True,
            "clarification_slot": "input_image",
            "freshness": "stable",
            "risk_category": "low",
            "warning_required": False,
            "required_capability": "image_edit",
        },
        "B03": {
            "task_type": "caption",
            "goal_summary": "کپشن صمیمی قهوه سرد برای دانشجوها با دعوت به سفارش",
            "slots": [
                {"name": "subject", "value": "قهوه سرد", "status": "explicit", "confidence": 1.0},
                {"name": "audience", "value": "دانشجوها", "status": "explicit", "confidence": 1.0},
                {"name": "tone", "value": "خودمانی", "status": "explicit", "confidence": 1.0},
                {
                    "name": "call_to_action",
                    "value": "دعوت به سفارش",
                    "status": "explicit",
                    "confidence": 1.0,
                },
            ],
            "conflicts": [],
            "missing_hard_slots": [],
            "should_clarify": False,
            "clarification_slot": None,
            "freshness": "stable",
            "risk_category": "low",
            "warning_required": False,
            "required_capability": "text_generation",
        },
    }[case_id]
    if extra:
        values.update(extra)
    return json.dumps(values, ensure_ascii=False)


def response(model: str, case_id: str, *, finish: str = "stop") -> StructuredChatResponse:
    return StructuredChatResponse(
        requested_model=model,
        response_model=model,
        content=content_for(case_id),
        finish_reason=finish,
        usage=ChatUsage(10, 20, 30),
        latency_ms=5,
    )


def test_l01_only_gemini_and_sol_are_allowlisted() -> None:
    assert BENCHMARK_MODELS == ("gemini-3.6-flash", "gpt-5.6-sol")
    assert "gpt-5.6-luna" not in BENCHMARK_MODELS
    assert "claude-sonnet-5" not in BENCHMARK_MODELS


def test_l02_only_three_benchmark_cases_are_defined() -> None:
    assert tuple(case["id"] for case in BENCHMARK_CASES) == ("B01", "B02", "B03")
    assert len(BENCHMARK_CASES) == 3


def test_l03_pair_order_is_exact_and_reproducible() -> None:
    assert PAIR_PLAN == (
        ("B01", "gemini-3.6-flash"),
        ("B01", "gpt-5.6-sol"),
        ("B02", "gemini-3.6-flash"),
        ("B02", "gpt-5.6-sol"),
        ("B03", "gemini-3.6-flash"),
        ("B03", "gpt-5.6-sol"),
    )


def test_l04_hard_call_cap_is_six() -> None:
    assert HARD_LOGICAL_CALL_CAP == 6
    assert len(PAIR_PLAN) == HARD_LOGICAL_CALL_CAP


def test_l05_luna_and_claude_have_no_call_path() -> None:
    source = Path("src/athena_runtime/providers/persian_benchmark.py").read_text(encoding="utf-8")
    assert "gpt-5.6-luna" not in source
    assert "claude-sonnet-5" not in source


@pytest.mark.asyncio
async def test_l06_request_uses_confirmed_schema_and_fixed_config() -> None:
    async def handler(request: httpx.Request) -> httpx.Response:
        body = json.loads(await request.aread())
        assert body["response_format"]["type"] == "json_schema"
        assert body["response_format"]["json_schema"]["strict"] is True
        assert body["response_format"]["json_schema"]["schema"] == UNDERSTANDING_JSON_SCHEMA
        assert body["max_tokens"] == STRUCTURED_MAX_OUTPUT_TOKENS == 300
        assert body["temperature"] == 0 and body["stream"] is False
        return httpx.Response(
            200,
            json={
                "model": BENCHMARK_MODELS[0],
                "choices": [
                    {
                        "message": {"content": content_for("B01")},
                        "finish_reason": "stop",
                    }
                ],
                "usage": {},
            },
            request=request,
        )

    await GapGPTStructuredOutputClient(transport=httpx.MockTransport(handler)).probe(
        model=BENCHMARK_MODELS[0],
        synthetic_user_input=BENCHMARK_CASES[0]["input"],
        secret=MOCK_SECRET,
    )
    assert SCHEMA_VERSION == "athena-understanding-schema-0.2"


@pytest.mark.asyncio
async def test_l07_each_pair_is_called_at_most_once(tmp_path: Path) -> None:
    class FakeClient:
        def __init__(self) -> None:
            self.calls: list[tuple[str, str]] = []

        async def probe(
            self, *, model: str, synthetic_user_input: str, secret: str
        ) -> StructuredChatResponse:
            del secret
            case_id = next(
                case["id"] for case in BENCHMARK_CASES if case["input"] == synthetic_user_input
            )
            self.calls.append((case_id, model))
            return response(model, case_id)

    inventory = tmp_path / "inventory.json"
    inventory.write_text(json.dumps({"models": [{"id": model} for model in BENCHMARK_MODELS]}))
    fake = FakeClient()
    summary = await run_benchmark(
        secret=MOCK_SECRET,
        inventory_path=inventory,
        client=fake,  # type: ignore[arg-type]
    )
    assert fake.calls == list(PAIR_PLAN)
    assert len(fake.calls) == len(set(fake.calls)) == 6
    assert summary.actual_logical_calls == 6


def test_l08_no_retry_repair_fallback_or_tiebreaker() -> None:
    source = (
        Path("src/athena_runtime/providers/persian_benchmark.py")
        .read_text(encoding="utf-8")
        .casefold()
    )
    for forbidden in ("retry", "repair", "fallback", "tie-break", "tiebreak"):
        assert forbidden not in source
    assert source.count("client.probe(") == 1


def test_l09_gold_allowed_sets_and_key_scoring() -> None:
    for case in BENCHMARK_CASES:
        output, diagnostic = parse_structured_content(content_for(case["id"]))
        assert output is not None, diagnostic
        scores = _field_scores(case, output)
        assert set(scores) == {
            "task_type",
            "should_clarify",
            "freshness",
            "risk_category",
            "warning_required",
            "required_capability",
        }
        assert sum(scores.values()) == 6


def test_l10_requirement_evidence_positive_and_negative() -> None:
    for case_id, maximum in (("B01", 1), ("B02", 1), ("B03", 4)):
        positive, _diagnostic = parse_structured_content(content_for(case_id))
        assert positive is not None
        evidence = requirement_evidence(case_id, positive)
        assert evidence.score == evidence.maximum == maximum
    negative, _diagnostic = parse_structured_content(
        content_for(
            "B01",
            extra={
                "goal_summary": "بررسی عمومی پیج",
                "slots": [],
                "missing_hard_slots": [],
                "clarification_slot": None,
            },
        )
    )
    assert negative is not None
    assert requirement_evidence("B01", negative).score == 0


def test_l11_artifact_is_sanitized_and_contains_only_parsed_output(tmp_path: Path) -> None:
    output, diagnostic = parse_structured_content(content_for("B01"))
    assert output is not None
    record = BenchmarkRecord(
        case_id="B01",
        requested_model=BENCHMARK_MODELS[0],
        response_model=BENCHMARK_MODELS[0],
        status="SCHEMA_VALID",
        parsed_output=output.model_dump(mode="json"),
        field_scores={},
        key_field_score=0,
        evidence=requirement_evidence("B01", output),
        diagnostic={"content_length": diagnostic.content_length},
    )
    summary = BenchmarkSummary(
        schema_version=SCHEMA_VERSION,
        schema_hash=SCHEMA_HASH,
        prompt_version=STRUCTURED_PROMPT_VERSION,
        prompt_hash=STRUCTURED_PROMPT_HASH,
        hard_logical_call_cap=6,
        actual_logical_calls=1,
        available_models=BENCHMARK_MODELS,
        missing_models=(),
        records=(record,),
        model_observations=(
            ModelObservation(
                model=BENCHMARK_MODELS[0],
                contract_valid_count=1,
                key_field_score=0,
                requirement_evidence_score=1,
                input_tokens=0,
                output_tokens=0,
                total_tokens=0,
                latency_ms=0,
            ),
        ),
    )
    json_path, markdown_path = tmp_path / "benchmark.json", tmp_path / "benchmark.md"
    write_benchmark(summary, json_path, markdown_path)
    artifact = json_path.read_text() + markdown_path.read_text()
    assert MOCK_SECRET not in artifact
    assert "raw_response" not in artifact
    assert "authorization" not in artifact.casefold()
    assert "system_prompt" not in artifact
    assert BENCHMARK_CASES[0]["input"] not in artifact
    assert summary.decision == "HUMAN_REVIEW_REQUIRED"


@pytest.mark.asyncio
async def test_l12_failures_are_handled_without_extra_calls(tmp_path: Path) -> None:
    class FailureClient:
        def __init__(self) -> None:
            self.calls: list[tuple[str, str]] = []

        async def probe(
            self, *, model: str, synthetic_user_input: str, secret: str
        ) -> StructuredChatResponse:
            del secret
            case_id = next(
                case["id"] for case in BENCHMARK_CASES if case["input"] == synthetic_user_input
            )
            self.calls.append((case_id, model))
            if (case_id, model) == PAIR_PLAN[0]:
                raise StructuredOutputUnsupported("unsupported")
            if (case_id, model) == PAIR_PLAN[1]:
                return response(model, case_id, finish="length")
            if (case_id, model) == PAIR_PLAN[2]:
                result = response(model, case_id)
                return StructuredChatResponse(
                    requested_model=result.requested_model,
                    response_model=result.response_model,
                    content="{bad",
                    finish_reason="stop",
                    usage=result.usage,
                    latency_ms=result.latency_ms,
                )
            return response(model, case_id)

    inventory = tmp_path / "inventory.json"
    inventory.write_text(json.dumps({"models": [{"id": model} for model in BENCHMARK_MODELS]}))
    client = FailureClient()
    summary = await run_benchmark(
        secret=MOCK_SECRET,
        inventory_path=inventory,
        client=client,  # type: ignore[arg-type]
    )
    assert client.calls == list(PAIR_PLAN)
    assert summary.actual_logical_calls == 6
    statuses = [record.status for record in summary.records[:3]]
    assert statuses == [
        "STRUCTURED_OUTPUT_UNSUPPORTED",
        "FINISH_LENGTH",
        "SCHEMA_FAILED",
    ]

    class ValidClient(FailureClient):
        async def probe(
            self, *, model: str, synthetic_user_input: str, secret: str
        ) -> StructuredChatResponse:
            del secret
            case_id = next(
                case["id"] for case in BENCHMARK_CASES if case["input"] == synthetic_user_input
            )
            self.calls.append((case_id, model))
            return response(model, case_id)

    inventory.write_text(json.dumps({"models": [{"id": BENCHMARK_MODELS[0]}]}))
    available_client = ValidClient()
    unavailable_summary = await run_benchmark(
        secret=MOCK_SECRET,
        inventory_path=inventory,
        client=available_client,  # type: ignore[arg-type]
    )
    assert unavailable_summary.actual_logical_calls == 3
    assert all(model == BENCHMARK_MODELS[0] for _case, model in available_client.calls)
    assert sum(record.status == "MODEL_UNAVAILABLE" for record in unavailable_summary.records) == 3
