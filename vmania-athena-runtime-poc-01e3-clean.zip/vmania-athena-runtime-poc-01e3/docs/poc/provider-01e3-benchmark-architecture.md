# GapGPT Persian Understanding Benchmark — Stage A

## Scope

این Benchmark کوچک فقط فهم ساختاریافته سه درخواست فارسی synthetic را میان `gemini-3.6-flash` و `gpt-5.6-sol` مقایسه می‌کند. Production benchmark، model selection نهایی یا Router mapping نیست. Winner خودکار ندارد و Decision Artifact همیشه `HUMAN_REVIEW_REQUIRED` است.

`gpt-5.6-luna` و `claude-sonnet-5` هیچ call path ندارند و هزینه‌ای مصرف نمی‌کنند.

## Contract

همان Adapter تأییدشده استفاده می‌شود:

- Schema: `athena-understanding-schema-0.2`
- Schema hash: `bfba1d5ae55dc3a58d9f239cf1c5bddde398c9abc9e5e276e4587422ce5b8743`
- response_format: strict json_schema
- temperature: 0
- max_tokens: 300
- stream: false
- System Prompt بدون تغییر

## Deterministic plan

ترتیب ثابت:

1. B01 / Gemini
2. B01 / Sol
3. B02 / Gemini
4. B02 / Sol
5. B03 / Gemini
6. B03 / Sol

Hard logical call cap=6 است. هر pair حداکثر یک call، بدون retry/repair/fallback/tie-breaker. Model غایب `MODEL_UNAVAILABLE` می‌شود. Failure call اضافه ایجاد نمی‌کند.

## Scoring

Hard Gate: Schema valid و finish reason غیر length.

شش Key Field مستقل: task_type، should_clarify، freshness، risk_category، warning_required و required_capability. هر field یک امتیاز؛ هر Case حداکثر 6 و هر Model حداکثر 18.

Requirement Evidence جداست:

- B01: evidence/link/screenshot/source باید در missing/unknown/clarification یا summary با بیان نبود منبع دیده شود.
- B02: input image/attachment/source image باید در missing/unknown/clarification یا summary با بیان نبود تصویر دیده شود.
- B03: subject، audience، tone و call-to-action با slot name محدود یا summary keyword محدود بررسی می‌شوند.

Regex آزاد یا output-specific استفاده نشده است. Parsed Structured Output synthetic قابل Artifact است؛ Raw Response/HTTP/Prompt/System/API Key/Authorization/CoT ممنوع‌اند.

## Observations

برای هر model Contract Valid Rate، Key Score، Evidence Score، token usage و latency ثبت می‌شود. Cost-adjusted observation فقط usage/latency را بدون قیمت‌سازی گزارش می‌کند. Human Review الزامی است.

## Execution

Workflow فقط workflow_dispatch است. در Arena هیچ Provider call واقعی انجام نشد؛ HTTP tests کاملاً Mock هستند.
