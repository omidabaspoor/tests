# Persian Benchmark Stage A — Cases

تمام متن‌ها synthetic هستند.

## B01 — Instagram analysis, evidence missing

ورودی: بررسی افت بازدید پیج فروشگاه بدون لینک یا اسکرین‌شات.

Gold: research/file_summary، clarify=true، periodic/live، low، no warning، web_research/file_parse_and_text. Evidence نبود منبع جدا score می‌شود.

## B02 — Image edit, source image missing

ورودی: تغییر پس‌زمینه محصول به جنگل مه‌آلود با حفظ محصول، بدون ارسال عکس.

Gold: image_edit، clarify=true، stable، low، no warning، image_edit capability. Evidence نبود input image جدا score می‌شود.

## B03 — Explicit caption

ورودی: کپشن صمیمی قهوه سرد برای دانشجوها با دعوت به سفارش.

Gold: caption، clarify=false، stable، low، no warning، text_generation. Evidence subject/audience/tone/call-to-action حداکثر چهار امتیاز دارد.

این سه Case برای نتیجه Production-ready کافی نیستند. Winner نهایی خودکار اعلام نمی‌شود و Human Review لازم است. Luna و Claude در این Stage call نمی‌شوند.
