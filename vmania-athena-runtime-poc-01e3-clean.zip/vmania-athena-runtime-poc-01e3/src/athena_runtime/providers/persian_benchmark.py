import argparse
import asyncio
import json
import os
from dataclasses import asdict
from pathlib import Path
from typing import Any, NoReturn

from pydantic import BaseModel, ConfigDict, Field

from athena_runtime.providers.errors import (
    MissingProviderSecret,
    ProviderError,
    StructuredOutputUnsupported,
)
from athena_runtime.providers.gapgpt_discover import atomic_write
from athena_runtime.providers.gapgpt_structured import (
    GapGPTStructuredOutputClient,
    StructuredChatResponse,
)
from athena_runtime.providers.structured_diagnostic import (
    SafeDiagnostic,
    parse_structured_content,
)
from athena_runtime.providers.structured_prompt import (
    STRUCTURED_PROMPT_HASH,
    STRUCTURED_PROMPT_VERSION,
)
from athena_runtime.providers.structured_schema import SCHEMA_HASH, SCHEMA_VERSION
from athena_runtime.providers.understanding import UnderstandingOutput

BENCHMARK_MODELS = ("gemini-3.6-flash", "gpt-5.6-sol")
BENCHMARK_CASES: tuple[dict[str, Any], ...] = (
    {
        "id": "B01",
        "input": (
            "پیج اینستاگرام فروشگاه لباس من رو بررسی کن و بگو چرا بازدیدش کمه؛ "
            "اسکرین‌شات یا لینک هنوز نفرستادم."
        ),
        "task": {"research", "file_summary"},
        "clarify": True,
        "freshness": {"periodic", "live"},
        "risk": {"low"},
        "warning": False,
        "capability": {"web_research", "file_parse_and_text"},
    },
    {
        "id": "B02",
        "input": (
            "می‌خوام پس‌زمینه عکس محصولم جنگل مه‌آلود بشه، ولی خود محصول هیچ "
            "تغییری نکنه. هنوز عکس رو نفرستادم."
        ),
        "task": {"image_edit"},
        "clarify": True,
        "freshness": {"stable"},
        "risk": {"low"},
        "warning": False,
        "capability": {"image_edit"},
    },
    {
        "id": "B03",
        "input": (
            "برای پیج کافه‌ام یک کپشن صمیمی درباره قهوه سرد بنویس؛ مخاطب "
            "دانشجوها هستند، لحن خودمانی باشد و آخرش دعوت به سفارش داشته باشد."
        ),
        "task": {"caption"},
        "clarify": False,
        "freshness": {"stable"},
        "risk": {"low"},
        "warning": False,
        "capability": {"text_generation"},
    },
)
PAIR_PLAN = tuple((case["id"], model) for case in BENCHMARK_CASES for model in BENCHMARK_MODELS)
HARD_LOGICAL_CALL_CAP = 6


class EvidenceResult(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")
    score: int = Field(ge=0, le=4)
    maximum: int = Field(ge=1, le=4)
    checks: dict[str, bool]


class BenchmarkRecord(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")
    case_id: str
    requested_model: str
    response_model: str | None = Field(default=None, max_length=128)
    status: str
    parsed_output: dict[str, Any] | None = None
    field_scores: dict[str, bool]
    key_field_score: int = Field(ge=0, le=6)
    evidence: EvidenceResult | None = None
    input_tokens: int | None = Field(default=None, ge=0)
    output_tokens: int | None = Field(default=None, ge=0)
    total_tokens: int | None = Field(default=None, ge=0)
    latency_ms: int | None = Field(default=None, ge=0)
    finish_reason: str | None = Field(default=None, max_length=64)
    diagnostic: dict[str, object | None] | None = None
    error_code: str | None = None


class ModelObservation(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")
    model: str
    contract_valid_count: int
    contract_total: int = 3
    key_field_score: int
    key_field_maximum: int = 18
    requirement_evidence_score: int
    requirement_evidence_maximum: int = 6
    input_tokens: int
    output_tokens: int
    total_tokens: int
    latency_ms: int
    cost_adjusted_observation: str = "No pricing inference; review usage and latency only."


class BenchmarkSummary(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")
    schema_version: str
    schema_hash: str
    prompt_version: str
    prompt_hash: str
    decision: str = "HUMAN_REVIEW_REQUIRED"
    hard_logical_call_cap: int
    actual_logical_calls: int
    available_models: tuple[str, ...]
    missing_models: tuple[str, ...]
    records: tuple[BenchmarkRecord, ...]
    model_observations: tuple[ModelObservation, ...]


async def run_benchmark(
    *,
    secret: str,
    inventory_path: Path,
    client: GapGPTStructuredOutputClient | None = None,
) -> BenchmarkSummary:
    if not secret:
        raise MissingProviderSecret("provider credential is missing")
    inventory = json.loads(inventory_path.read_text(encoding="utf-8"))
    ids = {
        item.get("id")
        for item in inventory.get("models", [])
        if isinstance(item, dict) and isinstance(item.get("id"), str)
    }
    available = tuple(model for model in BENCHMARK_MODELS if model in ids)
    missing = tuple(model for model in BENCHMARK_MODELS if model not in ids)
    adapter = client or GapGPTStructuredOutputClient()
    records: list[BenchmarkRecord] = []
    calls = 0
    case_by_id = {case["id"]: case for case in BENCHMARK_CASES}
    for case_id, model in PAIR_PLAN:
        case = case_by_id[case_id]
        if model not in available:
            records.append(_failure_record(case_id, model, "MODEL_UNAVAILABLE"))
            continue
        calls += 1
        if calls > HARD_LOGICAL_CALL_CAP:
            raise RuntimeError("benchmark call cap exceeded")
        records.append(await _one_call(adapter, secret, case, model))
    return BenchmarkSummary(
        schema_version=SCHEMA_VERSION,
        schema_hash=SCHEMA_HASH,
        prompt_version=STRUCTURED_PROMPT_VERSION,
        prompt_hash=STRUCTURED_PROMPT_HASH,
        hard_logical_call_cap=HARD_LOGICAL_CALL_CAP,
        actual_logical_calls=calls,
        available_models=available,
        missing_models=missing,
        records=tuple(records),
        model_observations=_observations(records),
    )


async def _one_call(
    client: GapGPTStructuredOutputClient,
    secret: str,
    case: dict[str, Any],
    model: str,
) -> BenchmarkRecord:
    try:
        response = await client.probe(
            model=model, synthetic_user_input=case["input"], secret=secret
        )
    except StructuredOutputUnsupported:
        return _failure_record(case["id"], model, "STRUCTURED_OUTPUT_UNSUPPORTED")
    except ProviderError as exc:
        return _failure_record(case["id"], model, type(exc).__name__.upper())
    output, diagnostic = parse_structured_content(response.content)
    if response.finish_reason == "length":
        return _response_failure(case["id"], model, response, diagnostic, "FINISH_LENGTH")
    if output is None:
        return _response_failure(case["id"], model, response, diagnostic, "SCHEMA_FAILED")
    scores = _field_scores(case, output)
    evidence = requirement_evidence(case["id"], output)
    return BenchmarkRecord(
        case_id=case["id"],
        requested_model=model,
        response_model=_bounded(response.response_model, 128),
        status="SCHEMA_VALID",
        parsed_output=output.model_dump(mode="json"),
        field_scores=scores,
        key_field_score=sum(scores.values()),
        evidence=evidence,
        input_tokens=response.usage.input_tokens,
        output_tokens=response.usage.output_tokens,
        total_tokens=response.usage.total_tokens,
        latency_ms=response.latency_ms,
        finish_reason=_bounded(response.finish_reason, 64),
        diagnostic=asdict(diagnostic),
    )


def _field_scores(case: dict[str, Any], output: UnderstandingOutput) -> dict[str, bool]:
    return {
        "task_type": output.task_type.value in case["task"],
        "should_clarify": output.should_clarify is case["clarify"],
        "freshness": output.freshness.value in case["freshness"],
        "risk_category": output.risk_category.value in case["risk"],
        "warning_required": output.warning_required is case["warning"],
        "required_capability": output.required_capability.value in case["capability"],
    }


def requirement_evidence(case_id: str, output: UnderstandingOutput) -> EvidenceResult:
    slot_names = {slot.name for slot in output.slots}
    unknown_names = {slot.name for slot in output.slots if slot.status == "unknown"}
    missing = set(output.missing_hard_slots)
    clarification = {output.clarification_slot} if output.clarification_slot else set()
    summary = output.goal_summary.casefold()
    unresolved = unknown_names | missing | clarification
    if case_id == "B01":
        names = {"evidence", "instagram_link", "page_link", "screenshot", "source", "page_data"}
        found = bool(unresolved & names) or any(
            token in summary
            for token in (
                "missing link",
                "no screenshot",
                "not provided",
                "لینک نفرست",
                "اسکرین شات نفرست",
                "منبع موجود نیست",
            )
        )
        return EvidenceResult(score=int(found), maximum=1, checks={"missing_page_evidence": found})
    if case_id == "B02":
        names = {"image", "input_image", "attachment", "source_image", "photo"}
        found = bool(unresolved & names) or any(
            token in summary
            for token in (
                "missing image",
                "no image",
                "image not provided",
                "عکس نفرست",
                "تصویر موجود نیست",
            )
        )
        return EvidenceResult(score=int(found), maximum=1, checks={"missing_input_image": found})
    if case_id == "B03":
        checks = {
            "subject": bool(slot_names & {"subject", "topic", "product"})
            or any(token in summary for token in ("coffee", "قهوه", "cold brew")),
            "audience": "audience" in slot_names
            or any(token in summary for token in ("student", "دانشجو")),
            "tone": "tone" in slot_names
            or any(token in summary for token in ("friendly", "casual", "صمیمی", "خودمانی")),
            "call_to_action": bool(slot_names & {"call_to_action", "cta"})
            or any(token in summary for token in ("order", "سفارش", "دعوت")),
        }
        return EvidenceResult(score=sum(checks.values()), maximum=4, checks=checks)
    raise ValueError("unknown benchmark case")


def _response_failure(
    case_id: str,
    model: str,
    response: StructuredChatResponse,
    diagnostic: SafeDiagnostic,
    status: str,
) -> BenchmarkRecord:
    return BenchmarkRecord(
        case_id=case_id,
        requested_model=model,
        response_model=_bounded(response.response_model, 128),
        status=status,
        field_scores={},
        key_field_score=0,
        input_tokens=response.usage.input_tokens,
        output_tokens=response.usage.output_tokens,
        total_tokens=response.usage.total_tokens,
        latency_ms=response.latency_ms,
        finish_reason=_bounded(response.finish_reason, 64),
        diagnostic=asdict(diagnostic),
        error_code=status,
    )


def _failure_record(case_id: str, model: str, status: str) -> BenchmarkRecord:
    return BenchmarkRecord(
        case_id=case_id,
        requested_model=model,
        status=status,
        field_scores={},
        key_field_score=0,
        error_code=status,
    )


def _observations(records: list[BenchmarkRecord]) -> tuple[ModelObservation, ...]:
    values: list[ModelObservation] = []
    for model in BENCHMARK_MODELS:
        selected = [record for record in records if record.requested_model == model]
        values.append(
            ModelObservation(
                model=model,
                contract_valid_count=sum(record.status == "SCHEMA_VALID" for record in selected),
                key_field_score=sum(record.key_field_score for record in selected),
                requirement_evidence_score=sum(
                    record.evidence.score for record in selected if record.evidence is not None
                ),
                input_tokens=sum(record.input_tokens or 0 for record in selected),
                output_tokens=sum(record.output_tokens or 0 for record in selected),
                total_tokens=sum(record.total_tokens or 0 for record in selected),
                latency_ms=sum(record.latency_ms or 0 for record in selected),
            )
        )
    return tuple(values)


def _bounded(value: str | None, maximum: int) -> str | None:
    if value is None:
        return None
    return value.replace("\r", " ").replace("\n", " ")[:maximum]


def write_benchmark(summary: BenchmarkSummary, json_path: Path, markdown_path: Path) -> None:
    atomic_write(
        json_path,
        json.dumps(summary.model_dump(mode="json"), ensure_ascii=False, indent=2) + "\n",
    )
    lines = [
        "# GapGPT Persian Understanding Benchmark — Stage A",
        "",
        f"- Decision: `{summary.decision}`",
        f"- Schema: `{summary.schema_version}` / `{summary.schema_hash}`",
        f"- Prompt: `{summary.prompt_version}` / `{summary.prompt_hash}`",
        f"- Hard call cap: {summary.hard_logical_call_cap}",
        f"- Actual calls: {summary.actual_logical_calls}",
        "",
        "| Model | Contract Valid | Key Score | Evidence | Tokens | Latency ms |",
        "|---|---|---|---|---|---|",
    ]
    for item in summary.model_observations:
        lines.append(
            f"| `{item.model}` | {item.contract_valid_count}/{item.contract_total} | "
            f"{item.key_field_score}/{item.key_field_maximum} | "
            f"{item.requirement_evidence_score}/{item.requirement_evidence_maximum} | "
            f"{item.input_tokens}/{item.output_tokens}/{item.total_tokens} | "
            f"{item.latency_ms} |"
        )
    lines.extend(("", "Human review is required; no automatic winner is selected."))
    atomic_write(markdown_path, "\n".join(lines) + "\n")


async def _run(args: argparse.Namespace) -> int:
    secret = os.environ.get("GAPGPT_API_KEY")
    if not secret:
        raise MissingProviderSecret("provider credential is missing")
    print("Persian Benchmark Stage A: 2 models x 3 cases; hard call cap = 6")
    summary = await run_benchmark(secret=secret, inventory_path=args.inventory)
    write_benchmark(summary, args.json_output, args.markdown_output)
    return 0


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Persian understanding benchmark Stage A")
    parser.add_argument("--inventory", type=Path, required=True)
    parser.add_argument("--json-output", type=Path, required=True)
    parser.add_argument("--markdown-output", type=Path, required=True)
    return parser


def main() -> NoReturn:
    try:
        code = asyncio.run(_run(_parser().parse_args()))
    except MissingProviderSecret:
        print("GAPGPT_API_KEY is required.", file=os.sys.stderr)
        raise SystemExit(2) from None
    except (ProviderError, OSError, json.JSONDecodeError):
        print("Persian benchmark failed safely.", file=os.sys.stderr)
        raise SystemExit(1) from None
    raise SystemExit(code)


if __name__ == "__main__":
    main()
