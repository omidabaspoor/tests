import json
import re
from pathlib import Path

import httpx
import pytest

from athena_runtime.providers.errors import StructuredOutputUnsupported
from athena_runtime.providers.gapgpt_chat import ALLOWED_SMOKE_MODELS, ChatUsage
from athena_runtime.providers.gapgpt_luna_recheck import (
    LUNA_CASE_ID,
    LUNA_HARD_CALL_CAP,
    LUNA_MODEL,
    LUNA_SYNTHETIC_INPUT,
    LunaRecheckArtifact,
    run_luna_recheck,
    write_luna_artifact,
)
from athena_runtime.providers.gapgpt_structured import (
    STRUCTURED_MAX_OUTPUT_TOKENS,
    GapGPTStructuredOutputClient,
    StructuredChatResponse,
)
from athena_runtime.providers.structured_contract import SLOT_NAME_PATTERN
from athena_runtime.providers.structured_diagnostic import parse_structured_content
from athena_runtime.providers.structured_prompt import (
    STRUCTURED_PROMPT_HASH,
    STRUCTURED_PROMPT_VERSION,
)
from athena_runtime.providers.structured_schema import (
    SCHEMA_HASH,
    SCHEMA_VERSION,
    UNDERSTANDING_JSON_SCHEMA,
)

MOCK_SECRET = "mock-secret-obviously-not-real"


def valid_content(slot_name: str = "subject") -> str:
    return json.dumps(
        {
            "task_type": "caption",
            "goal_summary": "synthetic caption classification",
            "slots": [
                {
                    "name": slot_name,
                    "value": None,
                    "status": "unknown",
                    "confidence": 0.0,
                }
            ],
            "conflicts": [],
            "missing_hard_slots": ["subject"],
            "should_clarify": True,
            "clarification_slot": "subject",
            "freshness": "stable",
            "risk_category": "low",
            "warning_required": False,
            "required_capability": "text_generation",
        },
        ensure_ascii=False,
    )


def envelope(request: httpx.Request, content: str) -> httpx.Response:
    return httpx.Response(
        200,
        json={
            "model": LUNA_MODEL,
            "choices": [
                {
                    "message": {"role": "assistant", "content": content},
                    "finish_reason": "stop",
                }
            ],
            "usage": {
                "prompt_tokens": 10,
                "completion_tokens": 20,
                "total_tokens": 30,
            },
        },
        request=request,
    )


def test_k01_slot_name_pattern_has_one_canonical_source() -> None:
    contract = Path("src/athena_runtime/providers/structured_contract.py").read_text(
        encoding="utf-8"
    )
    parser = Path("src/athena_runtime/providers/understanding.py").read_text(encoding="utf-8")
    schema = Path("src/athena_runtime/providers/structured_schema.py").read_text(encoding="utf-8")
    assert SLOT_NAME_PATTERN == r"^[a-z][a-z0-9_]{0,63}$"
    assert contract.count(SLOT_NAME_PATTERN) == 1
    assert SLOT_NAME_PATTERN not in parser
    assert SLOT_NAME_PATTERN not in schema
    assert "SLOT_NAME_PATTERN" in parser and "SLOT_NAME_PATTERN" in schema


def test_k02_slot_name_schema_has_aligned_pattern_and_bounds() -> None:
    name_schema = UNDERSTANDING_JSON_SCHEMA["properties"]["slots"]["items"]["properties"]["name"]
    assert name_schema == {
        "type": "string",
        "minLength": 1,
        "maxLength": 64,
        "pattern": SLOT_NAME_PATTERN,
    }


def test_k03_valid_subject_is_accepted_by_parser_and_contract() -> None:
    output, diagnostic = parse_structured_content(valid_content("subject"))
    assert output is not None and output.slots[0].name == "subject"
    assert diagnostic.validation_error_type is None
    assert re.fullmatch(SLOT_NAME_PATTERN, "subject") is not None


def test_k04_non_ascii_slot_name_is_rejected_by_both() -> None:
    output, diagnostic = parse_structured_content(valid_content("موضوع"))
    assert output is None
    assert diagnostic.validation_error_location == "slots.0.name"
    assert diagnostic.validation_error_type == "string_pattern_mismatch"
    assert re.fullmatch(SLOT_NAME_PATTERN, "موضوع") is None


@pytest.mark.asyncio
async def test_k05_request_remains_strict_json_schema_with_300_tokens() -> None:
    async def handler(request: httpx.Request) -> httpx.Response:
        body = json.loads(await request.aread())
        assert body["response_format"]["type"] == "json_schema"
        assert body["response_format"]["json_schema"]["strict"] is True
        assert body["response_format"]["json_schema"]["schema"] == UNDERSTANDING_JSON_SCHEMA
        assert body["max_tokens"] == STRUCTURED_MAX_OUTPUT_TOKENS == 300
        assert body["temperature"] == 0 and body["stream"] is False
        return envelope(request, valid_content())

    await GapGPTStructuredOutputClient(transport=httpx.MockTransport(handler)).probe(
        model=LUNA_MODEL, synthetic_user_input=LUNA_SYNTHETIC_INPUT, secret=MOCK_SECRET
    )


@pytest.mark.asyncio
async def test_k06_recheck_can_call_only_luna(tmp_path: Path) -> None:
    class FakeClient:
        def __init__(self) -> None:
            self.models: list[str] = []

        async def probe(
            self, *, model: str, synthetic_user_input: str, secret: str
        ) -> StructuredChatResponse:
            del synthetic_user_input, secret
            self.models.append(model)
            return StructuredChatResponse(
                requested_model=model,
                response_model=model,
                content=valid_content(),
                finish_reason="stop",
                usage=ChatUsage(1, 2, 3),
                latency_ms=1,
            )

    inventory = tmp_path / "inventory.json"
    inventory.write_text(json.dumps({"models": [{"id": model} for model in ALLOWED_SMOKE_MODELS]}))
    fake = FakeClient()
    artifact = await run_luna_recheck(
        secret=MOCK_SECRET,
        inventory_path=inventory,
        client=fake,  # type: ignore[arg-type]
    )
    assert fake.models == [LUNA_MODEL]
    assert artifact.status == "SCHEMA_VALID"


def test_k07_only_c01_and_hard_cap_one_are_defined() -> None:
    assert LUNA_MODEL == "gpt-5.6-luna"
    assert LUNA_CASE_ID == "C01"
    assert LUNA_SYNTHETIC_INPUT == "یه کپشن میخوام"
    assert LUNA_HARD_CALL_CAP == 1


@pytest.mark.asyncio
@pytest.mark.parametrize("status", [400, 422])
async def test_k08_unsupported_has_no_retry(status: int) -> None:
    calls = 0

    def handler(request: httpx.Request) -> httpx.Response:
        nonlocal calls
        calls += 1
        return httpx.Response(status, request=request)

    with pytest.raises(StructuredOutputUnsupported):
        await GapGPTStructuredOutputClient(transport=httpx.MockTransport(handler)).probe(
            model=LUNA_MODEL, synthetic_user_input=LUNA_SYNTHETIC_INPUT, secret=MOCK_SECRET
        )
    assert calls == 1


def test_k09_artifact_contains_no_raw_prompt_response_or_secret(tmp_path: Path) -> None:
    artifact = LunaRecheckArtifact(
        schema_version=SCHEMA_VERSION,
        schema_hash=SCHEMA_HASH,
        prompt_version=STRUCTURED_PROMPT_VERSION,
        prompt_hash=STRUCTURED_PROMPT_HASH,
        requested_model=LUNA_MODEL,
        case_id=LUNA_CASE_ID,
        status="SCHEMA_FAILED",
        actual_logical_calls=1,
        diagnostic={
            "content_length": 12,
            "first_non_whitespace_character": "{",
            "starts_with_code_fence": False,
            "validation_error_location": "slots.0.name",
            "validation_error_type": "string_pattern_mismatch",
            "validation_error_message": "String should match pattern.",
            "response_format_mode": "json_schema",
        },
    )
    json_path, markdown_path = tmp_path / "luna.json", tmp_path / "luna.md"
    write_luna_artifact(artifact, json_path, markdown_path)
    data = json_path.read_text() + markdown_path.read_text()
    assert MOCK_SECRET not in data
    assert LUNA_SYNTHETIC_INPUT not in data
    assert "raw_response" not in data
    assert "system_prompt" not in data
    assert "authorization" not in data.casefold()


def test_k10_runner_has_no_retry_repair_fallback_or_second_call() -> None:
    source = Path("src/athena_runtime/providers/gapgpt_luna_recheck.py").read_text(encoding="utf-8")
    lowered = source.casefold()
    assert "retry" not in lowered
    assert "repair" not in lowered
    assert "fallback" not in lowered
    assert "for model" not in lowered
    assert "while " not in lowered
    assert source.count("adapter.probe(") == 1
