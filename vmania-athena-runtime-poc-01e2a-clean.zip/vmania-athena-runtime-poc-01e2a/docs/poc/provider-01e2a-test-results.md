# GapGPT 01E.2a — Test Results

## Local

```text
pytest -q -m "not integration"
184 passed, 37 deselected

pytest -q tests/unit/test_gapgpt_luna_recheck_01e2a.py
11 passed

ruff check .
All checks passed!

python -m compileall -q src tests alembic
PASS
```

هیچ Provider Call واقعی انجام نشد؛ فقط MockTransport و Fake Client استفاده شد.

## K01–K10

| ID | Result |
|---|---|
| K01 one canonical pattern constant | PASS_STATIC |
| K02 JSON Schema pattern/bounds aligned | PASS_STATIC |
| K03 subject accepted by parser/contract | PASS |
| K04 non-ASCII slot rejected by both | PASS |
| K05 strict json_schema/300 tokens | PASS_MOCK |
| K06 Luna-only call | PASS_MOCK |
| K07 C01-only/cap=1 | PASS_STATIC |
| K08 400/422 unsupported/no retry | PASS_MOCK |
| K09 sanitized artifact | PASS |
| K10 no retry/repair/fallback/second call | PASS_STATIC |

## Workflow

`gapgpt-luna-contract-recheck.yml` فقط workflow_dispatch است. همه non-integration tests، discovery، plan=1، Luna recheck و sanitized two-file artifact با retention سه روز تعریف شده‌اند. Workflow اجرا نشده است.

## Secret and model safety

- Secret واقعی در Source/Test/Log/Artifact نیست.
- Mock Secret آشکار و غیرواقعی است.
- Gemini، Sol و Claude در Runner call path وجود ندارند.
- Luna absent از Inventory برابر zero Chat call است.
