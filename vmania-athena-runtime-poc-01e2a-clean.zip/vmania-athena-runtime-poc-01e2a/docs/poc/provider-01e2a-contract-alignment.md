# GapGPT 01E.2a — Slot Contract Alignment and Luna Recheck

## Alignment

Canonical Slot Name pattern اکنون فقط در `structured_contract.py` تعریف می‌شود:

```text
^[a-z][a-z0-9_]{0,63}$
```

Pydantic `UnderstandingSlot.name` و JSON Schema `slots[].name.pattern` هر دو همان Constant را import می‌کنند. Schema name contract شامل type=string، minLength=1، maxLength=64 و pattern است.

- Schema Version: `athena-understanding-schema-0.2`
- Schema SHA-256: `bfba1d5ae55dc3a58d9f239cf1c5bddde398c9abc9e5e276e4587422ce5b8743`
- Prompt Version: `structured-capability-0.1` — بدون تغییر
- Prompt SHA-256: `814d051a3464124d8c7eb92cdbcd25628cdf8f3b513c1577171245977e66a4e9`

## Drift review

تمام fieldهای JSON Schema و Pydantic Output static بررسی شدند. Drift دیگری که باعث «Schema پذیرش / Parser رد» شود پیدا نشد.

چند محدودیت Schema محافظه‌کارانه‌تر از Parser باقی است و در Scope این fix تغییر نکرد:

- Schema برای string slot value سقف 300 دارد؛ Parser union سقف مستقل ندارد.
- Schema برای itemهای conflicts/missing طول 1..64 دارد؛ Parser فقط array count را محدود می‌کند.
- Schema clarification_slot غیرخالی می‌خواهد؛ Parser string خالی را جدا منع نمی‌کند.

این موارد Provider را محدودتر می‌کنند و علت پذیرش Provider/رد Parser نیستند؛ توسعه Contract خارج Scope انجام نشد.

## Luna recheck

Runner فقط model `gpt-5.6-luna` و case `C01` را می‌شناسد. Hard logical call cap=1 است. Inventory بدون Luna → صفر Chat call و MODEL_UNAVAILABLE. 400/422 → STRUCTURED_OUTPUT_UNSUPPORTED بدون retry. هر response فقط یک بار parse می‌شود؛ repair، fallback، Stage B و call دوم وجود ندارد.

Request همان strict json_schema، temperature=0، max_tokens=300 و stream=false است. Gemini و Sol دوباره Call نمی‌شوند. Claude دوباره Call نمی‌شود.

## Artifact

Artifact فقط schema/prompt version/hash، modelها، C01، status، actual calls، usage، latency، finish reason و diagnostic امن دارد. Raw content، prompt، system instruction، API key و Authorization header schema ندارند. Artifact workflow فقط دو فایل Luna را upload می‌کند و retention=3 days است.

## Status

نتیجه Luna هنوز Hypothesis است تا workflow_dispatch واقعی با GitHub Secret اجرا شود. این مرحله Production Benchmark یا model selection نیست. هیچ Request واقعی در Arena ارسال نشد.
