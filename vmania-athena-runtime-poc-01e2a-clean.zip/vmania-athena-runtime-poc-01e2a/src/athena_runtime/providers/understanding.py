import json
from enum import StrEnum
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, ValidationError

from athena_runtime.providers.structured_contract import SLOT_NAME_PATTERN

MAX_STRUCTURED_OUTPUT_BYTES = 32_768


class UnderstandingTask(StrEnum):
    CAPTION = "caption"
    RESEARCH = "research"
    GENERAL_WRITING = "general_writing"
    POLICY_RESPONSE = "policy_response"
    IMAGE_GENERATION = "image_generation"
    IMAGE_EDIT = "image_edit"
    FILE_SUMMARY = "file_summary"
    CALCULATION = "calculation"
    SOFTWARE_PROJECT = "software_project"
    UNKNOWN = "unknown"


class UnderstandingFreshness(StrEnum):
    STABLE = "stable"
    PERIODIC = "periodic"
    DAILY = "daily"
    LIVE = "live"


class UnderstandingRisk(StrEnum):
    LOW = "low"
    MEDIUM = "medium"
    MEDICAL = "medical"
    LEGAL = "legal"
    FINANCIAL = "financial"
    PROMPT_INJECTION = "prompt_injection"
    HIGH = "high"


class UnderstandingCapability(StrEnum):
    NONE = "none"
    TEXT_GENERATION = "text_generation"
    WEB_RESEARCH = "web_research"
    POLICY_RESPONSE = "policy_response"
    IMAGE_GENERATION = "image_generation"
    IMAGE_EDIT = "image_edit"
    FILE_PARSE_AND_TEXT = "file_parse_and_text"
    DETERMINISTIC_CALCULATOR = "deterministic_calculator"
    SANDBOXED_CODE_RUNTIME = "sandboxed_code_runtime"


class UnderstandingSlot(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid", strict=True)
    name: str = Field(pattern=SLOT_NAME_PATTERN)
    value: str | int | float | bool | None = None
    status: str = Field(pattern=r"^(explicit|inferred|defaulted|unknown|conflicting)$")
    confidence: float = Field(ge=0, le=1)


class UnderstandingOutput(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid", strict=True)
    task_type: UnderstandingTask
    goal_summary: str = Field(min_length=1, max_length=300)
    slots: tuple[UnderstandingSlot, ...] = Field(max_length=32)
    conflicts: tuple[str, ...] = Field(max_length=16)
    missing_hard_slots: tuple[str, ...] = Field(max_length=16)
    should_clarify: bool
    clarification_slot: str | None = Field(default=None, max_length=64)
    freshness: UnderstandingFreshness
    risk_category: UnderstandingRisk
    warning_required: bool
    required_capability: UnderstandingCapability


class StructuredParseError(Exception):
    def __init__(self, code: str) -> None:
        super().__init__(code)
        self.code = code


def parse_understanding(content: str) -> UnderstandingOutput:
    encoded = content.encode("utf-8")
    if len(encoded) > MAX_STRUCTURED_OUTPUT_BYTES:
        raise StructuredParseError("OUTPUT_TOO_LARGE")
    stripped = content.strip()
    if stripped.startswith("```") or stripped.endswith("```"):
        raise StructuredParseError("CODE_FENCE_NOT_ALLOWED")
    try:
        value: Any = json.loads(stripped)
    except json.JSONDecodeError as exc:
        raise StructuredParseError("MALFORMED_JSON") from exc
    if not isinstance(value, dict):
        raise StructuredParseError("JSON_OBJECT_REQUIRED")
    try:
        return UnderstandingOutput.model_validate(value)
    except ValidationError as exc:
        raise StructuredParseError("SCHEMA_VALIDATION_FAILED") from exc
