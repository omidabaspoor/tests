SLOT_NAME_PATTERN = r"^[a-z][a-z0-9_]{0,63}$"
