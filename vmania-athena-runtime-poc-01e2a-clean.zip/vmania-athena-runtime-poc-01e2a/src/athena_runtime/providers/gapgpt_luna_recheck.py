import argparse
import asyncio
import json
import os
from dataclasses import asdict
from pathlib import Path
from typing import NoReturn

from pydantic import BaseModel, ConfigDict, Field

from athena_runtime.providers.errors import (
    MissingProviderSecret,
    ProviderError,
    StructuredOutputUnsupported,
)
from athena_runtime.providers.gapgpt_discover import atomic_write
from athena_runtime.providers.gapgpt_structured import (
    GapGPTStructuredOutputClient,
    StructuredChatResponse,
)
from athena_runtime.providers.structured_diagnostic import parse_structured_content
from athena_runtime.providers.structured_prompt import (
    STRUCTURED_PROMPT_HASH,
    STRUCTURED_PROMPT_VERSION,
)
from athena_runtime.providers.structured_schema import SCHEMA_HASH, SCHEMA_VERSION

LUNA_MODEL = "gpt-5.6-luna"
LUNA_CASE_ID = "C01"
LUNA_SYNTHETIC_INPUT = "یه کپشن میخوام"
LUNA_HARD_CALL_CAP = 1


class LunaRecheckArtifact(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")
    schema_version: str
    schema_hash: str
    prompt_version: str
    prompt_hash: str
    requested_model: str
    response_model: str | None = Field(default=None, max_length=128)
    case_id: str
    status: str
    actual_logical_calls: int = Field(ge=0, le=1)
    input_tokens: int | None = Field(default=None, ge=0)
    output_tokens: int | None = Field(default=None, ge=0)
    total_tokens: int | None = Field(default=None, ge=0)
    latency_ms: int | None = Field(default=None, ge=0)
    finish_reason: str | None = Field(default=None, max_length=64)
    diagnostic: dict[str, object | None] | None = None


async def run_luna_recheck(
    *,
    secret: str,
    inventory_path: Path,
    client: GapGPTStructuredOutputClient | None = None,
) -> LunaRecheckArtifact:
    if not secret:
        raise MissingProviderSecret("provider credential is missing")
    inventory = json.loads(inventory_path.read_text(encoding="utf-8"))
    model_ids = {
        item.get("id")
        for item in inventory.get("models", [])
        if isinstance(item, dict) and isinstance(item.get("id"), str)
    }
    if LUNA_MODEL not in model_ids:
        return _artifact(status="MODEL_UNAVAILABLE", actual_calls=0)
    adapter = client or GapGPTStructuredOutputClient()
    try:
        response = await adapter.probe(
            model=LUNA_MODEL,
            synthetic_user_input=LUNA_SYNTHETIC_INPUT,
            secret=secret,
        )
    except StructuredOutputUnsupported:
        return _artifact(status="STRUCTURED_OUTPUT_UNSUPPORTED", actual_calls=1)
    except ProviderError as exc:
        return _artifact(status=type(exc).__name__.upper(), actual_calls=1)
    return _from_response(response)


def _from_response(response: StructuredChatResponse) -> LunaRecheckArtifact:
    output, diagnostic = parse_structured_content(response.content)
    if response.finish_reason == "length":
        status = "FINISH_LENGTH"
    elif output is None:
        status = "SCHEMA_FAILED"
    else:
        status = "SCHEMA_VALID"
    return _artifact(
        status=status,
        actual_calls=1,
        response_model=_bounded(response.response_model, 128),
        input_tokens=response.usage.input_tokens,
        output_tokens=response.usage.output_tokens,
        total_tokens=response.usage.total_tokens,
        latency_ms=response.latency_ms,
        finish_reason=_bounded(response.finish_reason, 64),
        diagnostic=asdict(diagnostic),
    )


def _artifact(
    *,
    status: str,
    actual_calls: int,
    response_model: str | None = None,
    input_tokens: int | None = None,
    output_tokens: int | None = None,
    total_tokens: int | None = None,
    latency_ms: int | None = None,
    finish_reason: str | None = None,
    diagnostic: dict[str, object | None] | None = None,
) -> LunaRecheckArtifact:
    return LunaRecheckArtifact(
        schema_version=SCHEMA_VERSION,
        schema_hash=SCHEMA_HASH,
        prompt_version=STRUCTURED_PROMPT_VERSION,
        prompt_hash=STRUCTURED_PROMPT_HASH,
        requested_model=LUNA_MODEL,
        response_model=response_model,
        case_id=LUNA_CASE_ID,
        status=status,
        actual_logical_calls=actual_calls,
        input_tokens=input_tokens,
        output_tokens=output_tokens,
        total_tokens=total_tokens,
        latency_ms=latency_ms,
        finish_reason=finish_reason,
        diagnostic=diagnostic,
    )


def _bounded(value: str | None, maximum: int) -> str | None:
    if value is None:
        return None
    return value.replace("\r", " ").replace("\n", " ")[:maximum]


def write_luna_artifact(
    artifact: LunaRecheckArtifact, json_path: Path, markdown_path: Path
) -> None:
    atomic_write(
        json_path,
        json.dumps(artifact.model_dump(mode="json"), ensure_ascii=False, indent=2) + "\n",
    )
    lines = [
        "# GapGPT Luna Schema Contract Recheck",
        "",
        f"- Schema version: `{artifact.schema_version}`",
        f"- Schema hash: `{artifact.schema_hash}`",
        f"- Prompt version: `{artifact.prompt_version}`",
        f"- Prompt hash: `{artifact.prompt_hash}`",
        f"- Requested model: `{artifact.requested_model}`",
        f"- Response model: `{artifact.response_model or '—'}`",
        f"- Case: `{artifact.case_id}`",
        f"- Status: `{artifact.status}`",
        f"- Actual logical calls: {artifact.actual_logical_calls}",
        "- Tokens input/output/total: "
        f"{artifact.input_tokens}/{artifact.output_tokens}/{artifact.total_tokens}",
        f"- Latency ms: {artifact.latency_ms}",
        f"- Finish reason: `{artifact.finish_reason or '—'}`",
    ]
    if artifact.diagnostic:
        lines.extend(("", "## Safe Diagnostic", ""))
        for key, value in artifact.diagnostic.items():
            lines.append(f"- {key}: `{value}`")
    atomic_write(markdown_path, "\n".join(lines) + "\n")


async def _run(args: argparse.Namespace) -> int:
    secret = os.environ.get("GAPGPT_API_KEY")
    if not secret:
        raise MissingProviderSecret("provider credential is missing")
    print("Luna recheck plan: model=1, case=1, hard logical call cap=1")
    artifact = await run_luna_recheck(secret=secret, inventory_path=args.inventory)
    write_luna_artifact(artifact, args.json_output, args.markdown_output)
    return 0


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="GapGPT Luna schema alignment recheck")
    parser.add_argument("--inventory", type=Path, required=True)
    parser.add_argument("--json-output", type=Path, required=True)
    parser.add_argument("--markdown-output", type=Path, required=True)
    return parser


def main() -> NoReturn:
    try:
        code = asyncio.run(_run(_parser().parse_args()))
    except MissingProviderSecret:
        print("GAPGPT_API_KEY is required.", file=os.sys.stderr)
        raise SystemExit(2) from None
    except (ProviderError, OSError, json.JSONDecodeError):
        print("Luna schema recheck failed safely.", file=os.sys.stderr)
        raise SystemExit(1) from None
    raise SystemExit(code)


if __name__ == "__main__":
    main()
