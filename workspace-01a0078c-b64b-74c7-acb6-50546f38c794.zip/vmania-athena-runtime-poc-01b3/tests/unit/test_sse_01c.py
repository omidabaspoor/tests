import asyncio
from datetime import UTC, datetime
from uuid import UUID, uuid4

import pytest

from athena_runtime.api.contracts import PublicEvent, RunView
from athena_runtime.api.sse import stream_events
from athena_runtime.persistence.context import WorkspaceContext
from athena_runtime.runs import RunState


class EmptyRunningReader:
    async def list_after(
        self,
        context: WorkspaceContext,
        run_id: UUID,
        after_sequence: int,
        *,
        limit: int,
    ) -> tuple[PublicEvent, ...]:
        return ()

    async def current_run(self, context: WorkspaceContext, run_id: UUID) -> RunView | None:
        return RunView(run_id, RunState.RUNNING, 1)


@pytest.mark.asyncio
async def test_e05_heartbeat_is_comment_without_event_id() -> None:
    workspace, run_id = WorkspaceContext(uuid4(), "p"), uuid4()
    generator = stream_events(
        EmptyRunningReader(),
        workspace,
        run_id,
        0,
        poll_interval=0,
        heartbeat_interval=0,
    )
    frame = await anext(generator)
    await generator.aclose()
    assert frame == ": heartbeat\n\n"
    assert "id:" not in frame and "event:" not in frame


@pytest.mark.asyncio
async def test_e07_client_cancellation_propagates_cleanly() -> None:
    entered = asyncio.Event()

    class BlockingReader(EmptyRunningReader):
        async def list_after(
            self,
            context: WorkspaceContext,
            run_id: UUID,
            after_sequence: int,
            *,
            limit: int,
        ) -> tuple[PublicEvent, ...]:
            entered.set()
            await asyncio.Event().wait()
            return ()

    generator = stream_events(BlockingReader(), WorkspaceContext(uuid4(), "p"), uuid4(), 0)
    task = asyncio.create_task(anext(generator))
    await entered.wait()
    task.cancel()
    with pytest.raises(asyncio.CancelledError):
        await task


@pytest.mark.asyncio
async def test_e10_batch_limit_and_backpressure_are_bounded() -> None:
    workspace, run_id = WorkspaceContext(uuid4(), "p"), uuid4()
    now = datetime.now(UTC)

    class BatchReader(EmptyRunningReader):
        def __init__(self) -> None:
            self.limits: list[int] = []
            self.done = False

        async def list_after(
            self,
            context: WorkspaceContext,
            run_id: UUID,
            after_sequence: int,
            *,
            limit: int,
        ) -> tuple[PublicEvent, ...]:
            self.limits.append(limit)
            if self.done:
                return ()
            self.done = True
            return tuple(
                PublicEvent(uuid4(), run_id, index, "page.parsing", now, {})
                for index in range(1, 6)
            )

        async def current_run(self, context: WorkspaceContext, run_id: UUID) -> RunView | None:
            return RunView(run_id, RunState.COMPLETED, 1)

    reader = BatchReader()
    frames = [
        frame
        async for frame in stream_events(
            reader, workspace, run_id, 0, batch_limit=5, poll_interval=0
        )
    ]
    assert len(frames) == 5
    assert reader.limits == [5, 5]
    with pytest.raises(ValueError, match="limit"):
        async for _ in stream_events(reader, workspace, run_id, 0, batch_limit=101):
            pass
