import json
from datetime import UTC, datetime
from uuid import UUID, uuid4

import httpx
import pytest
from fastapi import Request

from athena_runtime.api.app import create_app
from athena_runtime.api.contracts import AuthContext, PublicEvent, RunView
from athena_runtime.api.errors import RUN_NOT_STOPPABLE
from athena_runtime.persistence.context import WorkspaceContext
from athena_runtime.runs import RunState


class FakeBackend:
    def __init__(self) -> None:
        self.runs: dict[UUID, tuple[UUID, RunState, int]] = {}
        self.events: dict[UUID, list[tuple[PublicEvent, str]]] = {}

    async def create_run(self, auth: AuthContext, goal: str) -> RunView:
        assert goal
        run_id = uuid4()
        self.runs[run_id] = (auth.workspace.workspace_id, RunState.CREATED, 0)
        return RunView(run_id, RunState.CREATED, 0)

    async def get_run(self, auth: AuthContext, run_id: UUID) -> RunView | None:
        value = self.runs.get(run_id)
        if value is None or value[0] != auth.workspace.workspace_id:
            return None
        return RunView(run_id, value[1], value[2])

    async def stop_run(self, auth: AuthContext, run_id: UUID) -> RunView | None:
        run = await self.get_run(auth, run_id)
        if run is None:
            return None
        if run.state is RunState.COMPLETED:
            raise RUN_NOT_STOPPABLE
        if run.state is RunState.STOPPED:
            return run
        value = (auth.workspace.workspace_id, RunState.STOPPED, run.version + 1)
        self.runs[run_id] = value
        return RunView(run_id, value[1], value[2])

    async def list_after(
        self,
        context: WorkspaceContext,
        run_id: UUID,
        after_sequence: int,
        *,
        limit: int,
    ) -> tuple[PublicEvent, ...]:
        run = self.runs.get(run_id)
        if run is None or run[0] != context.workspace_id:
            return ()
        return tuple(
            event
            for event, visibility in self.events.get(run_id, [])
            if visibility == "user" and event.sequence > after_sequence
        )[:limit]

    async def current_run(self, context: WorkspaceContext, run_id: UUID) -> RunView | None:
        value = self.runs.get(run_id)
        if value is None or value[0] != context.workspace_id:
            return None
        return RunView(run_id, value[1], value[2])


async def fake_auth(request: Request) -> AuthContext:
    workspace = request.headers.get("X-Test-Workspace")
    if workspace is None:
        from athena_runtime.api.errors import UNAUTHENTICATED

        raise UNAUTHENTICATED
    return AuthContext("test-principal", WorkspaceContext(UUID(workspace), "test-principal"))


@pytest.fixture
def backend() -> FakeBackend:
    return FakeBackend()


@pytest.fixture
def app(backend: FakeBackend):
    return create_app(backend, backend, auth_dependency=fake_auth)


@pytest.fixture
def transport(app):
    return httpx.ASGITransport(app=app, raise_app_exceptions=False)


@pytest.mark.asyncio
async def test_a01_production_default_without_auth_is_401(backend: FakeBackend) -> None:
    production = create_app(backend, backend)
    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=production), base_url="http://test"
    ) as client:
        response = await client.post("/v1/runs", json={"goal": "یک هدف کوتاه"})
    assert response.status_code == 401
    assert response.json()["error"]["code"] == "UNAUTHENTICATED"


@pytest.mark.asyncio
async def test_a02_a04_create_and_get_same_workspace(
    transport: httpx.ASGITransport,
) -> None:
    workspace = uuid4()
    headers = {"X-Test-Workspace": str(workspace)}
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
        created = await client.post("/v1/runs", json={"goal": "یک هدف کوتاه"}, headers=headers)
        run_id = created.json()["run_id"]
        fetched = await client.get(f"/v1/runs/{run_id}", headers=headers)
    assert created.status_code == 201
    assert created.json()["status"] == "created"
    assert fetched.status_code == 200 and fetched.json()["run_id"] == run_id


@pytest.mark.asyncio
@pytest.mark.parametrize("field", ["workspace_id", "model", "tool", "budget", "policy"])
async def test_a03_client_cannot_inject_server_fields(
    transport: httpx.ASGITransport, field: str
) -> None:
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
        response = await client.post(
            "/v1/runs",
            json={"goal": "یک هدف کوتاه", field: "attacker"},
            headers={"X-Test-Workspace": str(uuid4())},
        )
    assert response.status_code == 422
    assert response.json()["error"]["code"] == "VALIDATION_ERROR"


@pytest.mark.asyncio
async def test_a05_cross_workspace_is_not_found(
    backend: FakeBackend, transport: httpx.ASGITransport
) -> None:
    owner, other = uuid4(), uuid4()
    run_id = uuid4()
    backend.runs[run_id] = (owner, RunState.CREATED, 0)
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
        response = await client.get(f"/v1/runs/{run_id}", headers={"X-Test-Workspace": str(other)})
    assert response.status_code == 404
    assert response.json()["error"]["code"] == "RUN_NOT_FOUND"


@pytest.mark.asyncio
async def test_a06_a07_stop_is_allowed_and_idempotent(
    backend: FakeBackend, transport: httpx.ASGITransport
) -> None:
    workspace, run_id = uuid4(), uuid4()
    backend.runs[run_id] = (workspace, RunState.CREATED, 0)
    headers = {"X-Test-Workspace": str(workspace)}
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
        first = await client.post(f"/v1/runs/{run_id}/stop", headers=headers)
        second = await client.post(f"/v1/runs/{run_id}/stop", headers=headers)
    assert first.json()["status"] == second.json()["status"] == "stopped"
    assert backend.runs[run_id][2] == 1


@pytest.mark.asyncio
async def test_a08_completed_run_is_not_changed(
    backend: FakeBackend, transport: httpx.ASGITransport
) -> None:
    workspace, run_id = uuid4(), uuid4()
    backend.runs[run_id] = (workspace, RunState.COMPLETED, 4)
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
        response = await client.post(
            f"/v1/runs/{run_id}/stop",
            headers={"X-Test-Workspace": str(workspace)},
        )
    assert response.status_code == 409
    assert backend.runs[run_id][1:] == (RunState.COMPLETED, 4)


@pytest.mark.asyncio
async def test_a09_a10_validation_error_is_safe_and_has_request_id(
    transport: httpx.ASGITransport,
) -> None:
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
        response = await client.post(
            "/v1/runs",
            json={"goal": "x"},
            headers={"X-Test-Workspace": str(uuid4())},
        )
    body = response.json()
    assert response.status_code == 422
    assert set(body) == {"error"}
    assert body["error"]["request_id"] == response.headers["X-Request-ID"]
    assert "trace" not in json.dumps(body).lower() and "sql" not in json.dumps(body).lower()


@pytest.mark.asyncio
async def test_e01_e02_e03_e04_e06_e08_replay_visibility_terminal_and_scope(
    backend: FakeBackend, transport: httpx.ASGITransport
) -> None:
    workspace, other, run_id = uuid4(), uuid4(), uuid4()
    backend.runs[run_id] = (workspace, RunState.COMPLETED, 2)
    now = datetime.now(UTC)
    backend.events[run_id] = [
        (PublicEvent(uuid4(), run_id, 1, "brief.compiling", now, {}), "user"),
        (PublicEvent(uuid4(), run_id, 2, "secret.internal", now, {"code": "x"}), "internal"),
        (PublicEvent(uuid4(), run_id, 3, "run.completed", now, {}), "user"),
        (PublicEvent(uuid4(), run_id, 4, "audit.record", now, {}), "audit"),
    ]
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
        full = await client.get(
            f"/v1/runs/{run_id}/events",
            headers={"X-Test-Workspace": str(workspace)},
        )
        replay = await client.get(
            f"/v1/runs/{run_id}/events",
            headers={"X-Test-Workspace": str(workspace), "Last-Event-ID": "1"},
        )
        hidden = await client.get(
            f"/v1/runs/{run_id}/events",
            headers={"X-Test-Workspace": str(other)},
        )
    assert full.status_code == 200
    assert full.headers["content-type"].startswith("text/event-stream")
    assert [line for line in full.text.splitlines() if line.startswith("id:")] == ["id: 1", "id: 3"]
    assert [line for line in replay.text.splitlines() if line.startswith("id:")] == ["id: 3"]
    assert "secret.internal" not in full.text and "audit.record" not in full.text
    assert hidden.status_code == 404


@pytest.mark.asyncio
async def test_e09_invalid_last_event_id_is_400(
    backend: FakeBackend, transport: httpx.ASGITransport
) -> None:
    workspace, run_id = uuid4(), uuid4()
    backend.runs[run_id] = (workspace, RunState.COMPLETED, 0)
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
        response = await client.get(
            f"/v1/runs/{run_id}/events",
            headers={"X-Test-Workspace": str(workspace), "Last-Event-ID": "-1"},
        )
    assert response.status_code == 400
