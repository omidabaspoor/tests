from datetime import UTC, datetime, timedelta

import pytest

from athena_runtime.api.live_action import (
    TEMPLATE_REGISTRY,
    TEMPLATE_VERSION,
    CompletionGate,
    LiveActionProjector,
)

NOW = datetime(2026, 1, 1, tzinfo=UTC)


def test_la01_unknown_event_creates_no_status() -> None:
    assert LiveActionProjector().project("r", "unknown.event", {}, NOW) is None


def test_la02_template_is_exact() -> None:
    status = LiveActionProjector().project("r", "brief.compiling", {}, NOW)
    assert status is not None
    assert status.text == "دارم درخواستت رو دقیق می‌کنم."


def test_la03_raw_payload_is_never_rendered() -> None:
    raw = "RAW_PRIVATE_VALUE"
    status = LiveActionProjector().project(
        "r", "source.searching", {"query": raw, "provider": raw}, NOW
    )
    assert status is not None and raw not in status.text


def test_la04_sensitive_payload_is_rejected() -> None:
    projector = LiveActionProjector()
    assert projector.project("r", "brief.compiling", {"prompt": "private"}, NOW) is None
    assert (
        projector.project("r2", "brief.compiling", {"nested": {"tool_args": {"x": 1}}}, NOW) is None
    )


def test_la05_similar_status_is_deduplicated() -> None:
    projector = LiveActionProjector()
    assert projector.project("r", "brief.compiling", {}, NOW) is not None
    assert projector.project("r", "brief.compiling", {}, NOW + timedelta(seconds=3)) is None


def test_la06_normal_status_is_throttled_for_two_seconds() -> None:
    projector = LiveActionProjector()
    assert projector.project("r", "brief.compiling", {}, NOW) is not None
    assert projector.project("r", "source.searching", {}, NOW + timedelta(seconds=1)) is None
    assert projector.project("r", "source.searching", {}, NOW + timedelta(seconds=2)) is not None


def test_la07_terminal_status_bypasses_throttle() -> None:
    projector = LiveActionProjector()
    projector.project("r", "brief.compiling", {}, NOW)
    assert projector.project("r", "run.failed", {}, NOW) is not None


def test_la08_creative_percentage_is_forbidden() -> None:
    for event_type in ("content.drafting", "image.generating", "quality.checking"):
        status = LiveActionProjector().project(
            event_type,
            event_type,
            {"progress_current": 1, "progress_total": 2},
            NOW,
        )
        assert status is not None and status.progress_percent is None


def test_la09_countable_upload_or_page_percentage_is_valid() -> None:
    status = LiveActionProjector().project(
        "r",
        "file.uploading",
        {"progress_current": 2, "progress_total": 4},
        NOW,
    )
    assert status is not None and status.progress_percent == 50


def test_la10_variant_is_stable_for_a_run() -> None:
    first = LiveActionProjector().project("stable", "source.searching", {}, NOW)
    second = LiveActionProjector().project("stable", "source.searching", {}, NOW)
    assert first is not None and second is not None and first.variant == second.variant


def test_la11_template_version_is_present() -> None:
    status = LiveActionProjector().project("r", "run.failed", {}, NOW)
    assert status is not None and status.template_version == TEMPLATE_VERSION


def test_la12_completed_without_markers_is_rejected() -> None:
    gate = CompletionGate()
    projector = LiveActionProjector(completion_gate=gate)
    with pytest.raises(ValueError, match="markers"):
        projector.project("r", "run.completed", {}, NOW)


def test_la13_completed_after_all_markers_is_valid() -> None:
    gate = CompletionGate()
    for marker in ("quality.decision", "artifact.not_required", "cost.status"):
        gate.record("r", marker)
    gate.require_completed("r")
    status = LiveActionProjector(completion_gate=gate).project("r", "run.completed", {}, NOW)
    assert status is not None and status.text == "آماده شد."


def test_la14_stopped_status_follows_stop_event() -> None:
    status = LiveActionProjector().project("r", "run.stopped", {}, NOW)
    assert status is not None and status.text == "کار متوقف شد."


def test_la15_all_registered_outputs_are_short_fixed_persian() -> None:
    assert TEMPLATE_REGISTRY
    for event_type, templates in TEMPLATE_REGISTRY.items():
        for text in templates:
            assert 3 <= len(text) <= 100, event_type
            assert any("\u0600" <= character <= "\u06ff" for character in text)
            assert "{" not in text and "}" not in text
