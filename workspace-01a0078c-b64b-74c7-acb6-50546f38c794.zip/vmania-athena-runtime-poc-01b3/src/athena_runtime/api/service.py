from datetime import UTC, datetime, timedelta
from uuid import UUID

from athena_runtime.api.contracts import AuthContext, RunView
from athena_runtime.api.errors import RUN_NOT_STOPPABLE, ApiError
from athena_runtime.errors import InvalidTransition
from athena_runtime.persistence.errors import OptimisticLockError
from athena_runtime.persistence.repositories import RunStore, RunTransitionService
from athena_runtime.runs import RunState


class PostgresRunApiService:
    def __init__(
        self,
        runs: RunStore,
        transitions: RunTransitionService,
        *,
        max_steps: int = 12,
        max_cost_microunits: int = 100_000,
        deadline: timedelta = timedelta(minutes=10),
    ) -> None:
        self._runs = runs
        self._transitions = transitions
        self._max_steps = max_steps
        self._max_cost = max_cost_microunits
        self._deadline = deadline

    async def create_run(self, auth: AuthContext, goal: str) -> RunView:
        del goal  # Goal persistence/planning is intentionally outside this PoC.
        run_id = await self._runs.create(
            auth.workspace,
            max_cost_microunits=self._max_cost,
            max_steps=self._max_steps,
            deadline_at=datetime.now(UTC) + self._deadline,
        )
        return RunView(run_id, RunState.CREATED, 0)

    async def get_run(self, auth: AuthContext, run_id: UUID) -> RunView | None:
        snapshot = await self._runs.load(auth.workspace, run_id)
        if snapshot is None:
            return None
        return RunView(run_id, snapshot.run.state, snapshot.version)

    async def stop_run(self, auth: AuthContext, run_id: UUID) -> RunView | None:
        snapshot = await self._runs.load(auth.workspace, run_id)
        if snapshot is None:
            return None
        if snapshot.run.state is RunState.STOPPED:
            return RunView(run_id, snapshot.run.state, snapshot.version)
        if snapshot.run.state in {
            RunState.COMPLETED,
            RunState.FAILED,
            RunState.EXPIRED,
            RunState.BLOCKED,
        }:
            raise RUN_NOT_STOPPABLE
        try:
            version = await self._transitions.transition(
                auth.workspace,
                run_id,
                expected_version=snapshot.version,
                to_state=RunState.STOPPED,
            )
        except (InvalidTransition, OptimisticLockError) as exc:
            raise ApiError(
                409,
                "RUN_STATE_CONFLICT",
                "وضعیت کار تغییر کرده است.",
                retryable=True,
                action="retry",
            ) from exc
        return RunView(run_id, RunState.STOPPED, version)
