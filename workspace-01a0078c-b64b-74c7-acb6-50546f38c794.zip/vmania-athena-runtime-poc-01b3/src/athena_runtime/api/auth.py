from collections.abc import Awaitable, Callable

from fastapi import Request

from athena_runtime.api.contracts import AuthContext
from athena_runtime.api.errors import UNAUTHENTICATED

AuthDependency = Callable[[Request], Awaitable[AuthContext]]


async def deny_unauthenticated(request: Request) -> AuthContext:
    del request
    raise UNAUTHENTICATED
