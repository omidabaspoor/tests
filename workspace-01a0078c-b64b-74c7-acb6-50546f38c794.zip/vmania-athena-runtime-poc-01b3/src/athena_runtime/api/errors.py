from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class ApiError(Exception):
    status_code: int
    code: str
    message: str
    retryable: bool = False
    action: str | None = None


RUN_NOT_FOUND = ApiError(404, "RUN_NOT_FOUND", "این کار پیدا نشد.")
UNAUTHENTICATED = ApiError(401, "UNAUTHENTICATED", "احراز هویت لازم است.")
INVALID_EVENT_CURSOR = ApiError(400, "INVALID_EVENT_CURSOR", "شناسه رویداد نامعتبر است.")
RUN_NOT_STOPPABLE = ApiError(409, "RUN_NOT_STOPPABLE", "این کار قابل توقف نیست.")
BODY_TOO_LARGE = ApiError(413, "BODY_TOO_LARGE", "درخواست بیش از حد بزرگ است.")
