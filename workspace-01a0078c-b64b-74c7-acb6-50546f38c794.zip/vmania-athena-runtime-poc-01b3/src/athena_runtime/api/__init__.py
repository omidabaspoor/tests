"""Restricted internal Run API, replayable SSE, and deterministic status projection."""
