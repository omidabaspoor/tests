from collections.abc import Awaitable, Callable
from uuid import UUID, uuid4

from fastapi import Depends, FastAPI, Header, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse, StreamingResponse

from athena_runtime.api.auth import AuthDependency, deny_unauthenticated
from athena_runtime.api.contracts import (
    AuthContext,
    CreateRunBody,
    ErrorBody,
    ErrorResponse,
    EventReader,
    RunApiService,
    RunResponse,
)
from athena_runtime.api.errors import (
    BODY_TOO_LARGE,
    INVALID_EVENT_CURSOR,
    RUN_NOT_FOUND,
    ApiError,
)
from athena_runtime.api.sse import stream_events

MAX_BODY_BYTES = 16_384


def create_app(
    service: RunApiService,
    event_reader: EventReader,
    *,
    auth_dependency: AuthDependency = deny_unauthenticated,
    enable_docs: bool = False,
) -> FastAPI:
    app = FastAPI(
        title="Athena Runtime Internal API",
        version="0.1.0",
        docs_url="/docs" if enable_docs else None,
        redoc_url=None,
        openapi_url="/openapi.json" if enable_docs else None,
    )

    @app.middleware("http")
    async def request_contract(
        request: Request,
        call_next: Callable[[Request], Awaitable[object]],
    ) -> object:
        request.state.request_id = str(uuid4())
        length = request.headers.get("content-length")
        if length is not None:
            try:
                too_large = int(length) > MAX_BODY_BYTES
            except ValueError:
                too_large = True
            if too_large:
                return _error_response(request, BODY_TOO_LARGE)
        body = await request.body()
        if len(body) > MAX_BODY_BYTES:
            return _error_response(request, BODY_TOO_LARGE)
        response = await call_next(request)
        response.headers["X-Request-ID"] = request.state.request_id
        return response

    @app.exception_handler(ApiError)
    async def api_error_handler(request: Request, error: ApiError) -> JSONResponse:
        return _error_response(request, error)

    @app.exception_handler(RequestValidationError)
    async def validation_error_handler(
        request: Request, error: RequestValidationError
    ) -> JSONResponse:
        del error
        return _error_response(
            request,
            ApiError(422, "VALIDATION_ERROR", "اطلاعات درخواست معتبر نیست."),
        )

    @app.exception_handler(Exception)
    async def internal_error_handler(request: Request, error: Exception) -> JSONResponse:
        del error
        return _error_response(
            request,
            ApiError(500, "INTERNAL_ERROR", "خطای داخلی رخ داد.", retryable=True),
        )

    auth_parameter = Depends(auth_dependency)

    @app.post("/v1/runs", response_model=RunResponse, status_code=201)
    async def create_run(
        body: CreateRunBody,
        auth: AuthContext = auth_parameter,
    ) -> RunResponse:
        run = await service.create_run(auth, body.goal)
        return _run_response(run.run_id, run.state)

    @app.get("/v1/runs/{run_id}", response_model=RunResponse)
    async def get_run(
        run_id: UUID,
        auth: AuthContext = auth_parameter,
    ) -> RunResponse:
        run = await service.get_run(auth, run_id)
        if run is None:
            raise RUN_NOT_FOUND
        return _run_response(run.run_id, run.state)

    @app.post("/v1/runs/{run_id}/stop", response_model=RunResponse)
    async def stop_run(
        run_id: UUID,
        auth: AuthContext = auth_parameter,
    ) -> RunResponse:
        run = await service.stop_run(auth, run_id)
        if run is None:
            raise RUN_NOT_FOUND
        return _run_response(run.run_id, run.state)

    @app.get("/v1/runs/{run_id}/events")
    async def run_events(
        run_id: UUID,
        auth: AuthContext = auth_parameter,
        last_event_id: str | None = Header(default=None, alias="Last-Event-ID"),
    ) -> StreamingResponse:
        after = _parse_last_event_id(last_event_id)
        run = await event_reader.current_run(auth.workspace, run_id)
        if run is None:
            raise RUN_NOT_FOUND
        return StreamingResponse(
            stream_events(event_reader, auth.workspace, run_id, after),
            media_type="text/event-stream",
            headers={
                "Cache-Control": "no-cache, no-transform",
                "X-Accel-Buffering": "no",
            },
        )

    return app


def _parse_last_event_id(value: str | None) -> int:
    if value is None:
        return 0
    if not value.isascii() or not value.isdigit():
        raise INVALID_EVENT_CURSOR
    parsed = int(value)
    if parsed < 0:
        raise INVALID_EVENT_CURSOR
    return parsed


def _run_response(run_id: UUID, state: object) -> RunResponse:
    return RunResponse(
        run_id=run_id,
        status=state,
        events_url=f"/v1/runs/{run_id}/events",
    )


def _error_response(request: Request, error: ApiError) -> JSONResponse:
    request_id = getattr(request.state, "request_id", str(uuid4()))
    body = ErrorResponse(
        error=ErrorBody(
            code=error.code,
            message=error.message,
            retryable=error.retryable,
            action=error.action,
            request_id=request_id,
        )
    )
    return JSONResponse(
        status_code=error.status_code,
        content=body.model_dump(mode="json"),
        headers={"X-Request-ID": request_id},
    )
