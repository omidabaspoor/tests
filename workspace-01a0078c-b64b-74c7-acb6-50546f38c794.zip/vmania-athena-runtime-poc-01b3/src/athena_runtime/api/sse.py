import asyncio
import json
import re
from collections.abc import AsyncIterator
from time import monotonic
from uuid import UUID

from athena_runtime.api.contracts import EventReader, PublicEvent
from athena_runtime.persistence.context import WorkspaceContext
from athena_runtime.runs import TERMINAL

_EVENT_TYPE = re.compile(r"^[a-z0-9][a-z0-9._-]{0,63}$")


def encode_event(event: PublicEvent) -> str:
    event_type = event.event_type
    if not _EVENT_TYPE.fullmatch(event_type):
        event_type = "event.unknown"
    data = {
        "event_id": str(event.event_id),
        "run_id": str(event.run_id),
        "sequence": event.sequence,
        "type": event_type,
        "created_at": event.created_at.isoformat(),
        "payload": event.payload,
    }
    encoded = json.dumps(data, ensure_ascii=False, separators=(",", ":"))
    return f"id: {data['sequence']}\nevent: {event_type}\ndata: {encoded}\n\n"


async def stream_events(
    reader: EventReader,
    context: WorkspaceContext,
    run_id: UUID,
    after_sequence: int,
    *,
    batch_limit: int = 50,
    poll_interval: float = 0.25,
    heartbeat_interval: float = 10.0,
) -> AsyncIterator[str]:
    if not 1 <= batch_limit <= 100:
        raise ValueError("SSE batch limit outside allowed range")
    cursor = after_sequence
    last_output = monotonic()
    try:
        while True:
            events = await reader.list_after(context, run_id, cursor, limit=batch_limit)
            for event in events:
                cursor = event.sequence
                last_output = monotonic()
                yield encode_event(event)
            run = await reader.current_run(context, run_id)
            if run is None:
                return
            if run.state in TERMINAL and not events:
                return
            if events:
                await asyncio.sleep(0)
                continue
            await asyncio.sleep(poll_interval)
            if monotonic() - last_output >= heartbeat_interval:
                last_output = monotonic()
                yield ": heartbeat\n\n"
    except asyncio.CancelledError:
        raise
