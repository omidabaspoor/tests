import hashlib
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

from pydantic import BaseModel, ConfigDict

TEMPLATE_VERSION = "01c.v1"
TEMPLATE_REGISTRY: dict[str, tuple[str, ...]] = {
    "brief.compiling": ("دارم درخواستت رو دقیق می‌کنم.",),
    "source.searching": ("دارم منابع تازه رو بررسی می‌کنم.",),
    "file.parsing": ("فایل خونده شد. دارم بخش‌های مهمش رو مرتب می‌کنم.",),
    "file.uploading": ("دارم فایل رو دریافت می‌کنم.",),
    "page.parsing": ("دارم صفحه‌ها رو بررسی می‌کنم.",),
    "content.drafting": ("دارم پیش‌نویس رو آماده می‌کنم.",),
    "image.generating": ("دارم تصویر رو می‌سازم.",),
    "image.editing": ("دارم تغییرها رو روی تصویر اعمال می‌کنم.",),
    "quality.checking": ("پیش‌نویس آماده‌ست. دارم جزئیاتش رو بررسی می‌کنم.",),
    "quality.repairing": ("دارم یک ایراد رو اصلاح می‌کنم.",),
    "provider.retrying": ("این مرحله درست پیش نرفت؛ دارم از مسیر جایگزین ادامه می‌دم.",),
    "approval.waiting": ("برای ادامه، تأییدت لازمه.",),
    "run.completed": ("آماده شد.",),
    "run.stopped": ("کار متوقف شد.",),
    "run.failed": ("این کار کامل نشد. می‌تونی دوباره تلاش کنی.",),
}
_IMPORTANT = frozenset({"approval.waiting", "run.completed", "run.stopped", "run.failed"})
_COUNTABLE = frozenset({"file.uploading", "file.parsing", "page.parsing"})
_FORBIDDEN_PROGRESS_PREFIXES = ("content.", "image.", "quality.")
_SENSITIVE_KEYS = frozenset(
    {"chain_of_thought", "reasoning_trace", "prompt", "secret", "api_key", "tool_args"}
)


class UserStatus(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")
    text: str
    event_type: str
    template_version: str
    variant: int
    progress_percent: int | None = None


@dataclass(slots=True)
class _ProjectionState:
    last_text: str | None = None
    last_at: datetime | None = None


class LiveActionProjector:
    def __init__(
        self,
        *,
        throttle_seconds: float = 2.0,
        completion_gate: "CompletionGate | None" = None,
    ) -> None:
        if throttle_seconds < 2.0:
            raise ValueError("normal status throttle must be at least two seconds")
        self._throttle = throttle_seconds
        self._completion_gate = completion_gate or CompletionGate()
        self._states: dict[str, _ProjectionState] = {}

    def project(
        self,
        run_id: str,
        event_type: str,
        payload: dict[str, Any],
        occurred_at: datetime,
    ) -> UserStatus | None:
        templates = TEMPLATE_REGISTRY.get(event_type)
        if templates is None or _contains_sensitive(payload):
            return None
        if event_type == "run.completed":
            self._completion_gate.require_completed(run_id)
        variant = _stable_variant(run_id, event_type, len(templates))
        text = templates[variant]
        state = self._states.setdefault(run_id, _ProjectionState())
        if state.last_text == text:
            return None
        if (
            event_type not in _IMPORTANT
            and state.last_at is not None
            and (occurred_at - state.last_at).total_seconds() < self._throttle
        ):
            return None
        progress = _progress_percent(event_type, payload)
        state.last_text = text
        state.last_at = occurred_at
        return UserStatus(
            text=text,
            event_type=event_type,
            template_version=TEMPLATE_VERSION,
            variant=variant,
            progress_percent=progress,
        )


def _stable_variant(run_id: str, event_type: str, count: int) -> int:
    digest = hashlib.sha256(f"{run_id}:{event_type}".encode()).digest()
    return int.from_bytes(digest[:8], "big") % count


def _progress_percent(event_type: str, payload: dict[str, Any]) -> int | None:
    if event_type.startswith(_FORBIDDEN_PROGRESS_PREFIXES) or event_type not in _COUNTABLE:
        return None
    current = payload.get("progress_current")
    total = payload.get("progress_total")
    if (
        not isinstance(current, int)
        or isinstance(current, bool)
        or not isinstance(total, int)
        or isinstance(total, bool)
        or total <= 0
        or current < 0
        or current > total
    ):
        return None
    return current * 100 // total


def _contains_sensitive(value: Any) -> bool:
    if isinstance(value, dict):
        return any(
            str(key).lower() in _SENSITIVE_KEYS or _contains_sensitive(item)
            for key, item in value.items()
        )
    if isinstance(value, list):
        return any(_contains_sensitive(item) for item in value)
    return False


@dataclass(slots=True)
class CompletionGate:
    _markers: dict[str, set[str]] = field(default_factory=dict)

    def record(self, run_id: str, event_type: str) -> None:
        self._markers.setdefault(run_id, set()).add(event_type)

    def require_completed(self, run_id: str) -> None:
        markers = self._markers.get(run_id, set())
        has_quality = "quality.decision" in markers
        has_artifact = bool(markers & {"artifact.ready", "artifact.not_required"})
        has_cost = "cost.status" in markers
        if not (has_quality and has_artifact and has_cost):
            raise ValueError("completion markers are incomplete")
