# Athena Internal Run API, Replayable SSE, and Live Action — 01C

## Scope

این PoC فقط Run API محدود، Error Contract، Event Read Repository، SSE polling/replay، Stop contract و projector قطعی Live Action را اضافه می‌کند. Model، Tool، Worker، Memory، Login واقعی، Payment، Redis، WebSocket و UI وجود ندارند.

## Gate

Persistence gate روی GitHub Actions run `31941514123` برای Python 3.12 و 3.13 سبز شد؛ هر دو Job شامل Unit، Migration Up، PostgreSQL Integration، Migration Down/Up، Wheel و Lint موفق بودند. محیط محلی PostgreSQL ندارد؛ بنابراین Integration جدید 01C محلی اجرا نشده است.

## Components

- `api/app.py`: FastAPI factory بدون docs عمومی در حالت production، endpointها، request ID و error handlers.
- `api/auth.py`: dependency پیش‌فرض fail-closed. Test app می‌تواند Fake dependency تزریق کند؛ header تستی در production وجود ندارد.
- `api/service.py`: create/get/stop روی Repositoryهای PostgreSQL تأییدشده.
- `api/event_read.py`: query cursor-based فقط با WorkspaceContext و visibility=user.
- `api/sse.py`: frame encoding، Last-Event-ID replay، heartbeat، polling محدود و terminal drain.
- `api/live_action.py`: template registry ثابت، projector بدون مدل و completion marker gate.

## Endpoints

- `POST /v1/runs`: Body فقط `{ "goal": "..." }`. Workspace، model، tool، policy و budget با `extra=forbid` رد می‌شوند. Server max steps/cost/deadline را تعیین می‌کند.
- `GET /v1/runs/{uuid}`: داده cross-workspace به شکل 404 بازگردانده می‌شود.
- `POST /v1/runs/{uuid}/stop`: stop مجاز از Domain graph، stop تکراری idempotent و completed بدون تغییر باقی می‌ماند.
- `GET /v1/runs/{uuid}/events`: `text/event-stream` با replay از `Last-Event-ID`.

Production default Auth همیشه 401 است. Auth واقعی خارج Scope و فقط Protocol/dependency قابل override تعریف شده است. Workspace هیچ‌گاه از Body یا Query خوانده نمی‌شود.

## SSE contract

```text
id: <global run sequence>
event: <structured public event type>
data: {"event_id":"...","run_id":"...","sequence":3,"type":"...","created_at":"...","payload":{...}}
```

- cursor فقط integer نامنفی است.
- query فقط `sequence > cursor`، مرتب و limitدار است؛ ID renumber نمی‌شود، پس gap ناشی از event داخلی پنهان نمی‌شود.
- internal/audit rowها query نمی‌شوند.
- payload عمومی whitelist محدود دارد: countable progress و code ساختاریافته؛ prompt، secret، tool args یا متن خام عبور نمی‌کند.
- heartbeat فقط comment `: heartbeat` است و ID ندارد.
- terminal stream بعد از drain آخرین event بسته می‌شود.
- cancellation دوباره propagate می‌شود و هیچ write انجام نمی‌دهد.
- Polling محدود PostgreSQL استفاده شده؛ LISTEN/NOTIFY و Redis خارج Scope هستند.

## Event read limits

- Default batch: 50
- Maximum batch: 100
- Cursor: global sequence همان Run
- Workspace: فقط Auth WorkspaceContext
- Ordinary transaction: READ COMMITTED

## Event schema

```json
{
  "event_id": "uuid",
  "run_id": "uuid",
  "sequence": 1,
  "type": "source.searching",
  "created_at": "UTC ISO-8601",
  "payload": {
    "progress_current": 1,
    "progress_total": 4,
    "countable": true,
    "code": "SAFE_CODE"
  }
}
```

Database event واقعی منبع است. Projector متن آزاد payload را به status تبدیل نمی‌کند.

## Template registry

Registry version: `01c.v1`

| Event | متن ثابت |
|---|---|
| brief.compiling | دارم درخواستت رو دقیق می‌کنم. |
| source.searching | دارم منابع تازه رو بررسی می‌کنم. |
| file.parsing | فایل خونده شد. دارم بخش‌های مهمش رو مرتب می‌کنم. |
| content.drafting | دارم پیش‌نویس رو آماده می‌کنم. |
| image.generating | دارم تصویر رو می‌سازم. |
| image.editing | دارم تغییرها رو روی تصویر اعمال می‌کنم. |
| quality.checking | پیش‌نویس آماده‌ست. دارم جزئیاتش رو بررسی می‌کنم. |
| quality.repairing | دارم یک ایراد رو اصلاح می‌کنم. |
| provider.retrying | این مرحله درست پیش نرفت؛ دارم از مسیر جایگزین ادامه می‌دم. |
| run.completed | آماده شد. |
| run.stopped | کار متوقف شد. |
| run.failed | این کار کامل نشد. می‌تونی دوباره تلاش کنی. |

Variant با SHA-256 پایدار run/event انتخاب می‌شود. normal status حداقل دو ثانیه throttle، متن مشابه deduplicate و terminal/approval/failure بدون throttle است. Progress فقط برای upload/page/file countable معتبر است و برای content/image/quality نمایش داده نمی‌شود.

## Completion rule

Endpoint عمومی event یا `run.completed` نمی‌سازد. `CompletionGate` تستی completed را فقط بعد از این markerها می‌پذیرد:

- `quality.decision`
- `artifact.ready` یا `artifact.not_required`
- `cost.status`

این gate مدل Quality/Artifact/Cost واقعی نیست.
