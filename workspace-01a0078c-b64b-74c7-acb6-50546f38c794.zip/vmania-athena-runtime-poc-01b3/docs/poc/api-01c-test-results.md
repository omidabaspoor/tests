# API 01C — Test Results

## Persistence gate

GitHub Actions run `31941514123` (`Athena PostgreSQL Gate`) در commit `5b10064e79aed0a4cae5629093f72d298022fae2` موفق بود:

- Python 3.12: PASS
- Python 3.13: PASS
- Migration Up: PASS
- PostgreSQL Integration: PASS
- Migration Down/Up: PASS
- Wheel/Lint/Compile: PASS

## Local results

```text
pip install -e '.[dev]'
PASS

pytest -q -m "not integration"
84 passed, 32 deselected

ruff check .
All checks passed!

python -m compileall -q src tests alembic
PASS

python -m build --wheel
PASS

isolated wheel install + API import smoke
PASS

alembic upgrade head --sql
PASS

alembic downgrade 20260816_01b:base --sql
PASS
```

PostgreSQL محلی موجود نبود. 32 Integration test تعریف شده‌اند و Integration جدید 01C محلی اجرا نشده است. دو تست PostgreSQL جدید create/get/stop و event cursor/visibility در CI بعدی اجرا خواهند شد.

## A01–A10

| ID | Result |
|---|---|
| A01 بدون Auth | PASS_UNIT |
| A02 ساخت Run | PASS_UNIT |
| A03 رد Workspace/Model/Tool/Budget injection | PASS_UNIT |
| A04 GET همان Workspace | PASS_UNIT |
| A05 Cross-workspace 404 | PASS_UNIT |
| A06 Stop مجاز | PASS_UNIT |
| A07 Stop تکراری idempotent | PASS_UNIT |
| A08 Completed تغییر نکند | PASS_UNIT |
| A09 Validation امن | PASS_UNIT |
| A10 Request ID | PASS_UNIT |

## E01–E10

| ID | Result |
|---|---|
| E01 ترتیب sequence | PASS_UNIT |
| E02 Last-Event-ID بدون duplicate | PASS_UNIT |
| E03 reconnect با global IDs و بدون renumber/gap پنهان | PASS_UNIT |
| E04 internal/audit نشت نکند | PASS_UNIT |
| E05 heartbeat بدون ID | PASS_UNIT |
| E06 terminal drain و close | PASS_UNIT |
| E07 cancellation propagate | PASS_UNIT |
| E08 cross-workspace stream 404 | PASS_UNIT |
| E09 cursor نامعتبر 400 | PASS_UNIT |
| E10 batch limit/backpressure | PASS_UNIT |

## LA01–LA15

| ID | Result |
|---|---|
| LA01 unknown → None | PASS |
| LA02 template صحیح | PASS |
| LA03 raw payload render نشود | PASS |
| LA04 sensitive payload رد شود | PASS |
| LA05 deduplicate | PASS |
| LA06 دو ثانیه throttle | PASS |
| LA07 terminal bypass | PASS |
| LA08 درصد creative ممنوع | PASS |
| LA09 درصد countable معتبر | PASS |
| LA10 variant پایدار | PASS |
| LA11 template version | PASS |
| LA12 completed بدون marker رد | PASS |
| LA13 completed معتبر با markerها | PASS |
| LA14 stopped status | PASS |
| LA15 متن فارسی کوتاه و ثابت | PASS |

## Summary

- Unit/Security: **84 PASS**
- Integration defined: **32**
- Integration executed locally: **0**
- API PostgreSQL CI after 01C: **NOT_RUN_YET**
- SSE replay unit result: **PASS**
- Cross-workspace API/SSE unit result: **PASS / 404**
- Unauthorized side effects in executed tests: **0**
