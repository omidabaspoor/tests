# API 01C — Decisions and Risk Remaining

## Decisions

1. **FastAPI factory، نه global app**: service، event reader و auth dependency صریح تزریق می‌شوند. Production default بدون Auth fail-closed است.
2. **No client workspace**: Workspace فقط داخل `AuthContext` است. Pydantic body `extra=forbid` هر server-owned field را رد می‌کند.
3. **Cross-workspace 404**: RLS/repository result نامرئی با `RUN_NOT_FOUND` یکسان می‌شود تا وجود Run افشا نشود.
4. **Stop uses Domain/Persistence contract**: Stop جدید از `RunTransitionService` و function اتمیک state/event/outbox استفاده می‌کند. تکرار stopped write دوم ندارد.
5. **SSE without extra library**: frameها مستقیم encode می‌شوند؛ PostgreSQL polling محدود، batch حداکثر 100 و heartbeat comment است.
6. **Actual event only**: SSE فقط row واقعی `run_events` را می‌خواند. Projector فقط event type ساختاریافته را به template ثابت map می‌کند و payload خام را render نمی‌کند.
7. **Visibility at query boundary**: فقط `visibility=user` خوانده می‌شود؛ internal/audit حتی وارد encoder نمی‌شوند.
8. **Public payload whitelist**: دفاع مستقل API علاوه بر DB payload limits؛ کلیدهای ناشناخته و داده provider/model/tool حذف می‌شوند.
9. **No blind completion**: هیچ endpoint عمومی completed نمی‌سازد. CompletionGate فقط test/internal proof است.
10. **Public docs disabled**: docs/openapi route فقط با flag صریح test/development فعال می‌شود. CORS wildcard تعریف نشده است.
11. **Dependencies**: FastAPI runtime و httpx development اضافه شدند؛ SSE library اضافه نشد.

## Error contract

تمام خطاهای API با request ID امن هستند:

```json
{
  "error": {
    "code": "RUN_NOT_FOUND",
    "message": "این کار پیدا نشد.",
    "retryable": false,
    "action": null,
    "request_id": "uuid"
  }
}
```

Validation، auth، state conflict و internal exception هیچ stack trace یا SQL به client نمی‌دهند.

## OpenAPI

Snapshot در `docs/poc/openapi-01c.json` نگهداری می‌شود. این فایل contract review است؛ endpoint عمومی docs در production فعال نیست.

## Trade-offs

- Polling latency و load برای PoC پذیرفته شده است؛ production fan-out/retention طراحی نشده است.
- Goal پس از validation در این PoC persistence نمی‌شود، چون schema/planner خارج Scope است.
- SSE delivery at-least-once در reconnect است؛ cursor صحیح client duplicate را حذف می‌کند. Exactly-once transport ادعا نمی‌شود.
- Gapهای global sequence می‌توانند نشان دهند event غیرعمومی وجود داشته، اما نوع و payload آن افشا نمی‌شود؛ sequence renumber نمی‌شود.
- In-memory projector state برای dedup/throttle process-local است؛ durable projector state خارج Scope است.

## Risk Remaining

- Integration جدید API/Event Reader باید در PostgreSQL CI اجرا شود؛ محیط محلی Database ندارد.
- Slow-client disconnect behavior در ASGI unit test پوشش داده شده، اما proxy buffering/timeout production تست نشده است.
- Auth واقعی، rate limiting، trusted proxy/request ID propagation، deployment TLS و audit کامل خارج Scope هستند.
- Event retention و long-running stream connection budget هنوز طراحی Production نیست.
- Template localization/version migration و accessibility نیازمند مرحله محصول است.
