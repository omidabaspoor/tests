# GapGPT Model Discovery Adapter — 01E.0

## Scope

فقط `GET https://api.gapgpt.app/v1/models` پشتیبانی می‌شود. Chat، Image، Embedding، Tool، Benchmark، Router mapping و capability inference وجود ندارند.

## Components

- `providers/base.py`: immutable `ModelDescriptor`, `ModelInventory` و discovery Protocol.
- `providers/gapgpt.py`: config امن، HTTP discovery، bounded response، retry محدود و parser.
- `providers/gapgpt_discover.py`: CLI و atomic JSON/Markdown artifact writer.
- `providers/errors.py`: خطاهای sanitize‌شده بدون request/header/secret.

## Request contract

```text
GET /v1/models
Authorization: Bearer <GAPGPT_API_KEY from environment>
Accept: application/json
```

Base URL پیش‌فرض ثابت است. HTTPS، host `api.gapgpt.app`، port 443/default و path `/v1` enforce می‌شوند. Redirect خاموش، TLS verify روشن و `trust_env=False` است؛ proxy از config/user پذیرفته نمی‌شود.

Secret فقط argument محلی `discover_models` و Authorization header در عمر AsyncClient است. Config، Inventory، Artifact و Exception هیچ Secret/Hash/Header ندارند.

## Inventory

Model ID regex و طول محدود دارد. owned_by/object/created فقط در صورت بازگشت API ثبت می‌شوند. field ناشناخته ignore می‌شود. `raw_capabilities` همیشه خالی است؛ از نام مدل قابلیت، قیمت یا tier حدس زده نمی‌شود. Duplicate اولین descriptor را نگه می‌دارد و warning ثبت می‌کند.

Response با stream تا سقف config خوانده می‌شود؛ raw response log نمی‌شود. فقط JSON object با `data` list پذیرفته می‌شود.

## Retry matrix

- 400/401/403/404/redirect/malformed/schema: بدون retry
- 429: یک retry، Retry-After بین 0 و 1 ثانیه clamp
- 500/502/503/504: یک retry با 0.1 ثانیه
- Timeout: یک retry
- سایر transport errorها: بدون loop

حداکثر دو attempt است.

## CLI

```bash
export GAPGPT_API_KEY='<injected secret>'
python -m athena_runtime.providers.gapgpt_discover \
  --json-output artifacts/gapgpt-model-inventory.json \
  --markdown-output artifacts/gapgpt-model-inventory.md
```

Secret مفقود exit 2 و پیام کوتاه می‌دهد. خروجی با temp file هم‌دایرکتوری، fsync، chmod 0600 و `os.replace` نوشته می‌شود. Artifact فقط Inventory غیرحساس است.
