# GapGPT Discovery Security 01E.0

## Trust boundaries

- Environment secret: trusted deployment input؛ هرگز log/store/hash نمی‌شود.
- GapGPT HTTP response: untrusted؛ size، status، JSON shape و descriptor schema validate می‌شود.
- CLI output path: operator input؛ parent ساخته و file atomic/0600 می‌شود.
- Inventory artifact: non-sensitive metadata only.

## Controls

- HTTPS + exact host/path allowlist
- no URL credentials/query/fragment/non-443 port
- TLS verification on
- redirects off, preventing Authorization forwarding
- environment proxy disabled
- response byte ceiling before complete accumulation
- no raw body/header logging
- sanitized exception messages and bounded retry
- strict model ID charset/length
- no model capability/price inference
- markdown cell newline/pipe escaping
- workflow `workflow_dispatch` only and artifact retention 3 days

## Secret handling

`GAPGPT_API_KEY` is read only by CLI runtime. GitHub workflow injects `${{ secrets.GAPGPT_API_KEY }}` only in Discovery step. Provider unit tests use a fake string and MockTransport. Workflow does not use `set -x`. JSON/Markdown writers receive only `ModelInventory`, which has no secret field.

## Non-capabilities

Static G15 verifies the client contains no chat completion, image, embedding or POST endpoint. No request to GapGPT was made while building or testing this workspace. Real `/models` execution is deferred to manual GitHub Actions.

## Remaining risks

- Actual service TLS/status/schema behavior awaits manual CI discovery.
- Artifact model IDs/ownership are provider-supplied metadata and should remain informational.
- Secret scanning and GitHub environment protections remain repository operations outside this workspace.
