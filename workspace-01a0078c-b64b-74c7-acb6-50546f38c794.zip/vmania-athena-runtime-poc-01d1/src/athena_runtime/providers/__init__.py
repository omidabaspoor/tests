"""Provider adapters. No model-generation capability is enabled in 01E.0."""
