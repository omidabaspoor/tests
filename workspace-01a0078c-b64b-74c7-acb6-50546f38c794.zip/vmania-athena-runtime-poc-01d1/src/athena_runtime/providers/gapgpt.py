import asyncio
import json
from collections.abc import Awaitable, Callable
from datetime import UTC, datetime
from urllib.parse import urlsplit

import httpx
from pydantic import BaseModel, ConfigDict, Field, ValidationError, model_validator

from athena_runtime.providers.base import ModelDescriptor, ModelInventory
from athena_runtime.providers.errors import (
    MissingProviderSecret,
    ProviderAuthenticationError,
    ProviderRateLimitError,
    ProviderRedirectError,
    ProviderResponseError,
)

Sleep = Callable[[float], Awaitable[None]]
_ALLOWED_HOSTS = frozenset({"api.gapgpt.app"})
_RETRYABLE_SERVER = frozenset({500, 502, 503, 504})


class GapGPTConfig(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")
    base_url: str = "https://api.gapgpt.app/v1"
    timeout_connect: float = Field(default=5.0, gt=0, le=30)
    timeout_read: float = Field(default=15.0, gt=0, le=60)
    max_response_bytes: int = Field(default=1_000_000, gt=0, le=5_000_000)
    user_agent: str = Field(
        default="athena-runtime-gapgpt-discovery/0.1", min_length=1, max_length=128
    )

    @model_validator(mode="after")
    def secure_url(self) -> "GapGPTConfig":
        parsed = urlsplit(self.base_url)
        if parsed.scheme != "https":
            raise ValueError("provider base URL must use HTTPS")
        if parsed.hostname not in _ALLOWED_HOSTS:
            raise ValueError("provider host is not allowlisted")
        if parsed.username or parsed.password or parsed.query or parsed.fragment:
            raise ValueError("provider base URL contains forbidden components")
        if parsed.port not in {None, 443}:
            raise ValueError("provider port is not allowlisted")
        if parsed.path.rstrip("/") != "/v1":
            raise ValueError("provider path must be /v1")
        return self


class GapGPTModelDiscoveryClient:
    def __init__(
        self,
        config: GapGPTConfig | None = None,
        *,
        transport: httpx.AsyncBaseTransport | None = None,
        sleep: Sleep = asyncio.sleep,
    ) -> None:
        self._config = config or GapGPTConfig()
        self._transport = transport
        self._sleep = sleep

    async def discover_models(self, secret: str) -> ModelInventory:
        if not secret or not secret.strip():
            raise MissingProviderSecret("provider credential is missing")
        timeout = httpx.Timeout(
            connect=self._config.timeout_connect,
            read=self._config.timeout_read,
            write=self._config.timeout_read,
            pool=self._config.timeout_connect,
        )
        async with httpx.AsyncClient(
            base_url=self._config.base_url.rstrip("/") + "/",
            timeout=timeout,
            follow_redirects=False,
            verify=True,
            trust_env=False,
            transport=self._transport,
            headers={
                "Authorization": f"Bearer {secret}",
                "Accept": "application/json",
                "User-Agent": self._config.user_agent,
            },
        ) as client:
            for attempt in range(2):
                try:
                    async with client.stream("GET", "models") as response:
                        if 300 <= response.status_code < 400:
                            raise ProviderRedirectError("provider redirect is forbidden")
                        if response.status_code in {401, 403}:
                            raise ProviderAuthenticationError("provider authentication failed")
                        if response.status_code in {400, 404}:
                            raise ProviderResponseError("provider rejected discovery request")
                        if response.status_code == 429:
                            if attempt == 0:
                                await self._sleep(_retry_after(response))
                                continue
                            raise ProviderRateLimitError("provider rate limit persisted")
                        if response.status_code in _RETRYABLE_SERVER:
                            if attempt == 0:
                                await self._sleep(0.1)
                                continue
                            raise ProviderResponseError("provider temporarily unavailable")
                        if response.status_code != 200:
                            raise ProviderResponseError("unexpected provider status")
                        body = await _bounded_body(response, self._config.max_response_bytes)
                        return _parse_inventory(body, self._config.base_url)
                except httpx.TimeoutException as exc:
                    if attempt == 0:
                        await self._sleep(0.1)
                        continue
                    raise ProviderResponseError("provider discovery timed out") from exc
                except httpx.RequestError as exc:
                    raise ProviderResponseError("provider transport failed") from exc
        raise ProviderResponseError("provider discovery failed")


async def _bounded_body(response: httpx.Response, maximum: int) -> bytes:
    body = bytearray()
    async for chunk in response.aiter_bytes():
        body.extend(chunk)
        if len(body) > maximum:
            raise ProviderResponseError("provider response exceeded size limit")
    return bytes(body)


def _parse_inventory(body: bytes, base_url: str) -> ModelInventory:
    try:
        payload = json.loads(body)
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ProviderResponseError("provider returned malformed JSON") from exc
    if not isinstance(payload, dict) or not isinstance(payload.get("data"), list):
        raise ProviderResponseError("provider inventory schema is invalid")
    models: list[ModelDescriptor] = []
    seen: set[str] = set()
    warnings: list[str] = []
    for value in payload["data"]:
        if not isinstance(value, dict):
            raise ProviderResponseError("provider model descriptor is invalid")
        try:
            descriptor = ModelDescriptor.model_validate(value)
        except ValidationError as exc:
            raise ProviderResponseError("provider model descriptor is invalid") from exc
        if descriptor.id in seen:
            warnings.append(f"duplicate_model_id:{descriptor.id}")
            continue
        seen.add(descriptor.id)
        models.append(descriptor)
    return ModelInventory(
        fetched_at=datetime.now(UTC),
        base_url_host=urlsplit(base_url).hostname or "",
        models=tuple(models),
        warnings=tuple(warnings),
    )


def _retry_after(response: httpx.Response) -> float:
    raw = response.headers.get("Retry-After", "0.1")
    try:
        value = float(raw)
    except ValueError:
        return 0.1
    return min(max(value, 0.0), 1.0)
