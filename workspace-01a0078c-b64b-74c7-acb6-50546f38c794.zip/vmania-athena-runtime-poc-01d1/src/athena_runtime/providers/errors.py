class ProviderError(Exception):
    """Sanitized provider boundary error."""


class MissingProviderSecret(ProviderError):
    pass


class ProviderConfigurationError(ProviderError):
    pass


class ProviderAuthenticationError(ProviderError):
    pass


class ProviderRateLimitError(ProviderError):
    pass


class ProviderResponseError(ProviderError):
    pass


class ProviderRedirectError(ProviderError):
    pass
