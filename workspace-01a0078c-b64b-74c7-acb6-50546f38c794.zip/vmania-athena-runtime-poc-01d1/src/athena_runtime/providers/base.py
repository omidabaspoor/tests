from datetime import datetime
from typing import Protocol

from pydantic import BaseModel, ConfigDict, Field


class ModelDescriptor(BaseModel):
    model_config = ConfigDict(frozen=True, extra="ignore", strict=True)
    id: str = Field(pattern=r"^[A-Za-z0-9][A-Za-z0-9._:/-]{0,127}$")
    owned_by: str | None = Field(default=None, max_length=128)
    object: str | None = Field(default=None, max_length=64)
    created: int | None = Field(default=None, ge=0)
    raw_capabilities: tuple[str, ...] = ()


class ModelInventory(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")
    provider: str = "gapgpt"
    fetched_at: datetime
    base_url_host: str
    models: tuple[ModelDescriptor, ...]
    warnings: tuple[str, ...] = ()


class ModelDiscoveryProvider(Protocol):
    async def discover_models(self, secret: str) -> ModelInventory: ...
