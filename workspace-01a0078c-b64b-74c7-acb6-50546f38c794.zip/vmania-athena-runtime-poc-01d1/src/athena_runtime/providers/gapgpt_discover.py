import argparse
import asyncio
import json
import os
import tempfile
from pathlib import Path
from typing import NoReturn

from athena_runtime.providers.base import ModelInventory
from athena_runtime.providers.errors import MissingProviderSecret, ProviderError
from athena_runtime.providers.gapgpt import GapGPTModelDiscoveryClient


def atomic_write(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary_name = tempfile.mkstemp(
        prefix=f".{path.name}.", suffix=".tmp", dir=path.parent
    )
    temporary = Path(temporary_name)
    try:
        os.fchmod(descriptor, 0o600)
        with os.fdopen(descriptor, "w", encoding="utf-8") as stream:
            stream.write(content)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
        os.chmod(path, 0o600)
    except Exception:
        temporary.unlink(missing_ok=True)
        raise


def _markdown_cell(value: str | None) -> str:
    if value is None:
        return "—"
    return value.replace("|", "\\|").replace("\r", " ").replace("\n", " ")


def write_inventory(inventory: ModelInventory, json_output: Path, markdown_output: Path) -> None:
    encoded = json.dumps(
        inventory.model_dump(mode="json"), ensure_ascii=False, indent=2, sort_keys=True
    )
    lines = [
        "# GapGPT Model Inventory",
        "",
        f"- Provider: `{inventory.provider}`",
        f"- Host: `{inventory.base_url_host}`",
        f"- Fetched at: `{inventory.fetched_at.isoformat()}`",
        f"- Models: {len(inventory.models)}",
        "",
        "| Model ID | Owned By | Object | Created |",
        "|---|---|---|---|",
    ]
    for model in inventory.models:
        lines.append(
            f"| `{model.id}` | {_markdown_cell(model.owned_by)} | "
            f"{_markdown_cell(model.object)} | "
            f"{model.created if model.created is not None else '—'} |"
        )
    if inventory.warnings:
        lines.extend(("", "## Warnings", ""))
        lines.extend(f"- `{warning}`" for warning in inventory.warnings)
    atomic_write(json_output, encoded + "\n")
    atomic_write(markdown_output, "\n".join(lines) + "\n")


async def _run(args: argparse.Namespace) -> int:
    secret = os.environ.get("GAPGPT_API_KEY")
    if not secret:
        raise MissingProviderSecret("provider credential is missing")
    inventory = await GapGPTModelDiscoveryClient().discover_models(secret)
    write_inventory(inventory, args.json_output, args.markdown_output)
    return 0


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Discover GapGPT models safely")
    parser.add_argument("--json-output", type=Path, required=True)
    parser.add_argument("--markdown-output", type=Path, required=True)
    return parser


def main() -> NoReturn:
    try:
        code = asyncio.run(_run(_parser().parse_args()))
    except MissingProviderSecret:
        print("GAPGPT_API_KEY is required.", file=os.sys.stderr)
        raise SystemExit(2) from None
    except ProviderError:
        print("GapGPT discovery failed safely.", file=os.sys.stderr)
        raise SystemExit(1) from None
    raise SystemExit(code)


if __name__ == "__main__":
    main()
