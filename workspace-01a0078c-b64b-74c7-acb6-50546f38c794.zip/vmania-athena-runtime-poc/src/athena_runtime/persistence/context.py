import re
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from dataclasses import dataclass
from typing import Protocol
from uuid import UUID

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncConnection, AsyncEngine


class WorkspaceAuthorizer(Protocol):
    async def authorize_workspace(self, principal_id: str, workspace_id: UUID) -> bool: ...


@dataclass(frozen=True, slots=True)
class WorkspaceContext:
    workspace_id: UUID
    principal_id: str


class WorkspaceContextFactory:
    def __init__(self, authorizer: WorkspaceAuthorizer) -> None:
        self._authorizer = authorizer

    async def create(self, principal_id: str, workspace_id: UUID) -> WorkspaceContext:
        if not await self._authorizer.authorize_workspace(principal_id, workspace_id):
            raise PermissionError("workspace authorization denied")
        return WorkspaceContext(workspace_id, principal_id)


class WorkspaceTransactionManager:
    def __init__(self, engine: AsyncEngine, *, app_role: str | None = None) -> None:
        if app_role is not None and not re.fullmatch(r"[a-z_][a-z0-9_]*", app_role):
            raise ValueError("invalid database role identifier")
        self._engine = engine
        self._app_role = app_role

    @asynccontextmanager
    async def transaction(self, context: WorkspaceContext) -> AsyncIterator[AsyncConnection]:
        async with self._engine.connect() as connection:
            async with connection.begin():
                if self._app_role is not None:
                    await connection.execute(text(f'SET LOCAL ROLE "{self._app_role}"'))
                await connection.execute(
                    text("SELECT set_config('app.workspace_id', :workspace_id, true)"),
                    {"workspace_id": str(context.workspace_id)},
                )
                yield connection

    @asynccontextmanager
    async def unscoped_transaction(self) -> AsyncIterator[AsyncConnection]:
        """Testing/admin helper; repositories never call this path."""
        async with self._engine.connect() as connection:
            async with connection.begin():
                if self._app_role is not None:
                    await connection.execute(text(f'SET LOCAL ROLE "{self._app_role}"'))
                yield connection
