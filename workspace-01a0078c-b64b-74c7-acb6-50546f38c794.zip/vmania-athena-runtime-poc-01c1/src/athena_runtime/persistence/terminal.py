from pydantic import BaseModel, ConfigDict, Field


class TerminalLiveActionPayload(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")
    text: str = Field(min_length=1, max_length=100)
    source_event_type: str = Field(pattern=r"^[a-z0-9][a-z0-9._-]{0,63}$")
    template_version: str = Field(min_length=1, max_length=32)
    progress_percent: int | None = Field(default=None, ge=0, le=100)
