import hashlib
import json
from datetime import datetime
from typing import Any
from uuid import UUID

from sqlalchemy import text

from athena_runtime.persistence.context import WorkspaceContext, WorkspaceTransactionManager
from athena_runtime.persistence.repositories import LiveEventReceipt
from athena_runtime.persistence.terminal import TerminalLiveActionPayload

TEMPLATE_VERSION = "01c.v2"
TEMPLATE_REGISTRY: dict[str, tuple[str, ...]] = {
    "brief.compiling": ("دارم درخواستت رو دقیق می‌کنم.",),
    "source.searching": ("دارم منابع تازه رو بررسی می‌کنم.",),
    "file.parsing": ("فایل خونده شد. دارم بخش‌های مهمش رو مرتب می‌کنم.",),
    "file.uploading": ("دارم فایل رو دریافت می‌کنم.",),
    "page.parsing": ("دارم صفحه‌ها رو بررسی می‌کنم.",),
    "content.drafting": ("دارم پیش‌نویس رو آماده می‌کنم.",),
    "image.generating": ("دارم تصویر رو می‌سازم.",),
    "image.editing": ("دارم تغییرها رو روی تصویر اعمال می‌کنم.",),
    "quality.checking": ("پیش‌نویس آماده‌ست. دارم جزئیاتش رو بررسی می‌کنم.",),
    "quality.repairing": ("دارم یک ایراد رو اصلاح می‌کنم.",),
    "provider.retrying": ("این مرحله درست پیش نرفت؛ دارم از مسیر جایگزین ادامه می‌دم.",),
    "approval.waiting": ("برای ادامه، تأییدت لازمه.",),
    "run.completed": ("آماده شد.",),
    "run.stopped": ("کار متوقف شد.",),
    "run.failed": ("این کار کامل نشد. می‌تونی دوباره تلاش کنی.",),
}
IMPORTANT_EVENTS = frozenset({"approval.waiting", "run.completed", "run.stopped", "run.failed"})
_COUNTABLE = frozenset({"file.uploading", "file.parsing", "page.parsing"})
_SENSITIVE_KEYS = frozenset(
    {"chain_of_thought", "reasoning_trace", "prompt", "secret", "api_key", "tool_args"}
)


UserStatus = TerminalLiveActionPayload
LiveActionPayload = TerminalLiveActionPayload


class LiveActionComposer:
    """Stateless deterministic mapping from a structured source event."""

    def compose(self, run_id: str, event_type: str, payload: dict[str, Any]) -> UserStatus | None:
        templates = TEMPLATE_REGISTRY.get(event_type)
        if templates is None or _contains_sensitive(payload):
            return None
        variant = _stable_variant(run_id, event_type, len(templates))
        return UserStatus(
            text=templates[variant],
            source_event_type=event_type,
            template_version=TEMPLATE_VERSION,
            progress_percent=_progress_percent(event_type, payload),
        )


class LiveActionService:
    def __init__(
        self,
        transactions: WorkspaceTransactionManager,
        composer: LiveActionComposer | None = None,
    ) -> None:
        self._transactions = transactions
        self._composer = composer or LiveActionComposer()

    async def publish(
        self,
        context: WorkspaceContext,
        run_id: UUID,
        *,
        source_event_type: str,
        source_payload: dict[str, Any],
        occurred_at: datetime,
    ) -> LiveEventReceipt | None:
        status = self._composer.compose(str(run_id), source_event_type, source_payload)
        if status is None:
            return None
        safe = LiveActionPayload.model_validate(status.model_dump())
        async with self._transactions.transaction(context) as connection:
            row = (
                await connection.execute(
                    text(
                        "SELECT event_id, event_sequence FROM athena.append_live_action("
                        ":run_id, CAST(:payload AS jsonb), :occurred_at, :bypass_throttle)"
                    ),
                    {
                        "run_id": run_id,
                        "payload": json.dumps(safe.model_dump(mode="json"), separators=(",", ":")),
                        "occurred_at": occurred_at,
                        "bypass_throttle": source_event_type in IMPORTANT_EVENTS,
                    },
                )
            ).one_or_none()
        if row is None or row.event_id is None:
            return None
        return LiveEventReceipt(row.event_id, row.event_sequence)


def _stable_variant(run_id: str, event_type: str, count: int) -> int:
    digest = hashlib.sha256(f"{run_id}:{event_type}".encode()).digest()
    return int.from_bytes(digest[:8], "big") % count


def _progress_percent(event_type: str, payload: dict[str, Any]) -> int | None:
    if event_type not in _COUNTABLE:
        return None
    current = payload.get("progress_current")
    total = payload.get("progress_total")
    if (
        not isinstance(current, int)
        or isinstance(current, bool)
        or not isinstance(total, int)
        or isinstance(total, bool)
        or total <= 0
        or current < 0
        or current > total
    ):
        return None
    return current * 100 // total


def _contains_sensitive(value: Any) -> bool:
    if isinstance(value, dict):
        return any(
            str(key).lower() in _SENSITIVE_KEYS or _contains_sensitive(item)
            for key, item in value.items()
        )
    if isinstance(value, list):
        return any(_contains_sensitive(item) for item in value)
    return False
