from datetime import UTC, datetime, timedelta
from pathlib import Path
from uuid import uuid4

import pytest

from athena_runtime.clocks import FakeClock
from athena_runtime.persistence.context import (
    TransactionIsolation,
    WorkspaceContext,
    WorkspaceContextFactory,
    WorkspaceTransactionManager,
)
from athena_runtime.persistence.limits import MAX_JSON_BYTES, validate_json_payload
from athena_runtime.persistence.repositories import rehydrate_run_from_event_rows
from athena_runtime.persistence.schema import metadata
from athena_runtime.runs import Run, RunState, RunTransitionEvent


def test_persistence_schema_has_exact_scoped_tables() -> None:
    assert {table.name for table in metadata.tables.values()} == {
        "runs",
        "run_events",
        "idempotency_records",
        "approvals",
        "outbox_events",
        "cost_reservations",
        "api_idempotency_records",
    }
    for table in metadata.tables.values():
        assert table.schema == "athena"
        assert not table.c.workspace_id.nullable


def test_payload_limit_is_enforced() -> None:
    assert validate_json_payload({"ok": True}) == {"ok": True}
    with pytest.raises(ValueError, match="payload"):
        validate_json_payload({"value": "x" * MAX_JSON_BYTES})


@pytest.mark.asyncio
async def test_workspace_context_requires_program_authorization() -> None:
    workspace_id = uuid4()

    class DenyAuthorizer:
        async def authorize_workspace(self, principal_id: str, requested: object) -> bool:
            return False

    factory = WorkspaceContextFactory(DenyAuthorizer())
    with pytest.raises(PermissionError):
        await factory.create("principal", workspace_id)


def test_run_rehydrate_validates_sequence_and_terminal_state() -> None:
    now = datetime(2026, 1, 1, tzinfo=UTC)
    events = (
        RunTransitionEvent("r", 1, RunState.CREATED, RunState.VALIDATING, now),
        RunTransitionEvent("r", 2, RunState.VALIDATING, RunState.EXPIRED, now),
    )
    run = Run.rehydrate("r", RunState.EXPIRED, events, clock=FakeClock(now))
    assert run.state is RunState.EXPIRED
    assert run.events == events
    with pytest.raises(ValueError, match="sequence"):
        Run.rehydrate("r", RunState.EXPIRED, (events[1],), clock=FakeClock(now))
    with pytest.raises(ValueError, match="final state"):
        Run.rehydrate("r", RunState.RUNNING, events, clock=FakeClock(now))


def test_p23_historical_revision_is_explicit_and_role_free() -> None:
    revision = Path("alembic/versions/20260816_01b_persistence_core.py").read_text(encoding="utf-8")
    assert "metadata.create_all" not in revision
    assert "metadata.drop_all" not in revision
    assert "CREATE ROLE" not in revision
    assert "DROP ROLE" not in revision
    assert "op.create_table" in revision
    assert "op.drop_table" in revision


def test_p24_mixed_live_events_rehydrate_only_transition_versions() -> None:
    run_id = uuid4()
    first_time = datetime(2026, 1, 1, tzinfo=UTC)
    second_time = first_time + timedelta(seconds=2)
    rows = (
        {
            "sequence": 1,
            "transition_version": 1,
            "event_type": "run.transitioned",
            "payload": {"from_state": "created", "to_state": "validating"},
            "occurred_at": first_time,
        },
        {
            "sequence": 2,
            "transition_version": None,
            "event_type": "tool.progress",
            "payload": {"percent": 50},
            "occurred_at": first_time + timedelta(seconds=1),
        },
        {
            "sequence": 3,
            "transition_version": 2,
            "event_type": "run.transitioned",
            "payload": {"from_state": "validating", "to_state": "expired"},
            "occurred_at": second_time,
        },
    )
    run = rehydrate_run_from_event_rows(run_id, RunState.EXPIRED, rows)
    assert run.state is RunState.EXPIRED
    assert [event.sequence for event in run.events] == [1, 2]
    assert [event.occurred_at for event in run.events] == [first_time, second_time]


@pytest.mark.asyncio
async def test_p31_transaction_isolation_is_strictly_allowlisted() -> None:
    class UnusedEngine:
        pass

    transactions = WorkspaceTransactionManager(UnusedEngine())  # type: ignore[arg-type]
    workspace = WorkspaceContext(uuid4(), "principal")
    assert {item.value for item in TransactionIsolation} == {
        "READ COMMITTED",
        "REPEATABLE READ",
    }
    with pytest.raises(ValueError, match="isolation"):
        async with transactions.transaction(
            workspace,
            isolation="SERIALIZABLE",  # type: ignore[arg-type]
        ):
            pytest.fail("unsupported isolation reached the engine")


@pytest.mark.asyncio
async def test_r09_terminal_payload_is_rejected_for_nonterminal_state() -> None:
    from athena_runtime.persistence.repositories import RunTransitionService
    from athena_runtime.persistence.terminal import TerminalLiveActionPayload

    class UnusedTransactions:
        pass

    service = RunTransitionService(UnusedTransactions())  # type: ignore[arg-type]
    payload = TerminalLiveActionPayload(
        text="کار متوقف شد.",
        source_event_type="run.stopped",
        template_version="01c.v2",
    )
    with pytest.raises(ValueError, match="terminal state"):
        await service.transition(
            WorkspaceContext(uuid4(), "p"),
            uuid4(),
            expected_version=0,
            to_state=RunState.RUNNING,
            terminal_live_action=payload,
        )
