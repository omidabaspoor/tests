"""Make terminal transition and live action atomic.

Revision ID: 20260816_01c2
Revises: 20260816_01c1
"""

from alembic import op

revision: str = "20260816_01c2"
down_revision: str | None = "20260816_01c1"
branch_labels: str | None = None
depends_on: str | None = None

OLD_SIGNATURE = "uuid,bigint,text,text,timestamptz,jsonb"
NEW_SIGNATURE = "uuid,bigint,text,text,timestamptz,jsonb,jsonb"


def upgrade() -> None:
    op.execute(
        f"ALTER FUNCTION athena.transition_run({OLD_SIGNATURE}) "
        "RENAME TO transition_run_legacy_01c2"
    )
    op.execute(
        f"REVOKE ALL ON FUNCTION athena.transition_run_legacy_01c2({OLD_SIGNATURE}) "
        "FROM PUBLIC, athena_app"
    )
    op.execute(
        """
        CREATE FUNCTION athena.transition_run(
          p_run_id uuid,
          p_expected_version bigint,
          p_from_state text,
          p_to_state text,
          p_occurred_at timestamptz,
          p_outbox_payload jsonb,
          p_terminal_live_action jsonb DEFAULT NULL
        ) RETURNS bigint
        LANGUAGE plpgsql
        SECURITY DEFINER
        SET search_path = pg_catalog, athena
        AS $$
        DECLARE
          v_workspace uuid;
          v_new_version bigint;
          v_sequence bigint;
          v_event_id uuid := gen_random_uuid();
        BEGIN
          v_workspace := NULLIF(current_setting('app.workspace_id', true), '')::uuid;
          IF v_workspace IS NULL OR p_occurred_at IS NULL OR p_outbox_payload IS NULL THEN
            RAISE EXCEPTION 'missing transition context' USING ERRCODE = '22023';
          END IF;
          IF p_terminal_live_action IS NOT NULL THEN
            IF p_to_state NOT IN ('completed','failed','stopped','expired','blocked') THEN
              RAISE EXCEPTION 'terminal live action requires terminal state'
                USING ERRCODE = '22023';
            END IF;
            IF p_terminal_live_action->>'source_event_type' <> ('run.' || p_to_state) THEN
              RAISE EXCEPTION 'terminal live action source mismatch'
                USING ERRCODE = '22023';
            END IF;
          END IF;
          UPDATE athena.runs
             SET state = p_to_state, version = version + 1, updated_at = now()
           WHERE id = p_run_id AND workspace_id = v_workspace
             AND version = p_expected_version AND state = p_from_state
           RETURNING version INTO v_new_version;
          IF NOT FOUND THEN
            RAISE EXCEPTION 'stale or invisible run' USING ERRCODE = '40001';
          END IF;
          SELECT COALESCE(MAX(sequence), 0) + 1 INTO v_sequence
            FROM athena.run_events WHERE run_id = p_run_id;
          INSERT INTO athena.run_events(
            id, workspace_id, run_id, sequence, transition_version,
            event_type, visibility, payload, occurred_at
          ) VALUES (
            v_event_id, v_workspace, p_run_id, v_sequence, v_new_version,
            'run.transitioned', 'internal',
            jsonb_build_object('from_state', p_from_state, 'to_state', p_to_state),
            p_occurred_at
          );
          INSERT INTO athena.outbox_events(
            id, workspace_id, aggregate_type, aggregate_id, event_type, payload
          ) VALUES (
            gen_random_uuid(), v_workspace, 'run', p_run_id, 'run.transitioned',
            p_outbox_payload || jsonb_build_object('event_id', v_event_id::text)
          );
          IF p_terminal_live_action IS NOT NULL THEN
            PERFORM * FROM athena.append_live_action(
              p_run_id, p_terminal_live_action, p_occurred_at, true
            );
          END IF;
          RETURN v_new_version;
        END $$;
        """
    )
    op.execute(f"ALTER FUNCTION athena.transition_run({NEW_SIGNATURE}) OWNER TO athena_migration")
    op.execute(f"REVOKE ALL ON FUNCTION athena.transition_run({NEW_SIGNATURE}) FROM PUBLIC")
    op.execute(f"GRANT EXECUTE ON FUNCTION athena.transition_run({NEW_SIGNATURE}) TO athena_app")


def downgrade() -> None:
    op.execute(f"DROP FUNCTION IF EXISTS athena.transition_run({NEW_SIGNATURE})")
    op.execute(
        f"ALTER FUNCTION athena.transition_run_legacy_01c2({OLD_SIGNATURE}) "
        "RENAME TO transition_run"
    )
    op.execute(f"GRANT EXECUTE ON FUNCTION athena.transition_run({OLD_SIGNATURE}) TO athena_app")
