# API 01C.2 — Terminal Atomicity and SSE Final Drain

## Atomic terminal transition

Revision `20260816_01c2` upgrades `athena.transition_run` from the six-argument signature to a seven-argument signature with optional `p_terminal_live_action jsonb DEFAULT NULL`.

The previous function is renamed to a non-executable legacy name during Up, preserving a safe Downgrade path. App/Public execute is revoked from the legacy signature. Down drops the new function, renames the legacy function back and restores the prior App grant.

The new function performs in one PostgreSQL statement/transaction:

1. validate workspace/version/from-state;
2. update Run state/version;
3. append `run.transitioned`;
4. append Outbox event;
5. when terminal payload exists, invoke locked `append_live_action` before returning.

`append_live_action` reuses the exact payload validation, deduplicate and lock logic from 01C.1. Terminal payload is accepted only for terminal states and its `source_event_type` must equal `run.<to_state>`. Transition sequence is allocated first and Live Action receives the immediately following global sequence.

Any payload/schema/function failure aborts the complete statement, leaving no terminal state, transition, outbox or Live Action.

SECURITY DEFINER، fixed `search_path=pg_catalog,athena`، owner `athena_migration`، PUBLIC revoke و App execute grant حفظ شده‌اند. هر DDL در `op.execute` تک‌فرمانی است.

## Structured service boundary

`RunTransitionService.transition()` accepts only `TerminalLiveActionPayload | None`; raw Dict is not accepted. A terminal payload on non-terminal state fails before opening a transaction.

`RunCompletionService` markerها را از PostgreSQL می‌خواند و `run.completed` payload را با Composer ثابت می‌سازد، سپس همان payload را داخل transition اتمیک می‌فرستد. انتشار دوم حذف شده است. Run از قبل completed بدون Event جدید برگردانده می‌شود.

`PostgresRunApiService.stop_run()` نیز `run.stopped` را داخل همان transition می‌فرستد. Conflict با reread stopped به 200 تبدیل می‌شود؛ تکرار یا دو Stop هم‌زمان Event دوم نمی‌سازد.

## SSE final drain

`stream_events` پس از batch خالی و مشاهده state نهایی، دقیقاً یک Final Drain query limitدار انجام می‌دهد:

- اگر Event یافته شد، ارسال و cursor جلو برده می‌شود و loop عادی ادامه می‌یابد.
- اگر Final Drain خالی بود، Stream بسته می‌شود.

هیچ sleep/grace period تصادفی یا retry نامحدود اضافه نشده است. این query Race مربوط به commit میان query event و query state را می‌بندد.

## Scenarios

- R01/R03/R06: Completion concurrent، یک transition و یک «آماده شد» با sequence متوالی.
- R02/R04/R06: Stop concurrent، یک transition و یک «کار متوقف شد» با sequence متوالی.
- R05/R10: payload نامعتبر بعد از update داخلی باعث rollback کامل statement می‌شود.
- R07: event ظاهرشده میان query اول و state read توسط Final Drain ارسال می‌شود.
- R08: Final Drain خالی Stream را می‌بندد.
- R09: terminal payload روی state غیرنهایی پیش از DB رد می‌شود.

## Risk remaining

PostgreSQL محلی موجود نیست. Function replacement، nested SECURITY DEFINER call، rollback و concurrency باید در CI PostgreSQL 17 روی Python 3.12/3.13 اجرا شوند. Integrationهای جدید صادقانه PASS اعلام نشده‌اند.
