# API 01C.2 — Test Results

## Local

```text
pytest -q -m "not integration"
93 passed, 37 deselected

ruff check .
All checks passed!

python -m compileall -q src tests alembic
PASS

alembic upgrade head --sql
PASS — revisions 01b, 01c1, 01c2

alembic downgrade 20260816_01c2:base --sql
PASS
```

PostgreSQL محلی موجود نبود:

- Integration تعریف‌شده: 37
- Integration اجراشده محلی: 0
- وضعیت PostgreSQL: `BLOCKED_NOT_RUN`
- CI 01C.2: `NOT_RUN_YET`

## R01–R10

| ID | Local status | PostgreSQL status |
|---|---|---|
| R01 completion transition + live action one commit | Static/contract PASS | Defined, pending CI |
| R02 stop transition + live action one commit | Static/contract PASS | Defined |
| R03 two completion one message | Unit conflict behavior + integration defined | Pending |
| R04 two stop one message | Unit idempotency + integration defined | Pending |
| R05 middle failure full rollback | Migration/function static PASS | Defined |
| R06 consecutive global sequence | Integration assertion defined | Pending |
| R07 terminal race final drain sends event | PASS_UNIT |
| R08 empty final drain closes | PASS_UNIT |
| R09 terminal payload on nonterminal rejected | PASS_UNIT |
| R10 invalid payload rollback | Pydantic/static PASS | Defined |

## Regression

- 89 baseline Unit/Security حفظ شد.
- 4 Unit/static race tests اضافه شد؛ مجموع 93 PASS.
- Packaging/runtime dependencies تغییر نکرد.
- RLS/FORCE RLS و direct table permissions تغییر نکرد.
- API Idempotency، SSE replay، body limit و Live Action tests قبلی PASS باقی ماندند.

## Result

- Terminal Event Atomic: IMPLEMENTED, PostgreSQL verification pending.
- Final Drain: PASS_UNIT.
- Random grace sleep: ندارد.
- Infinite retry: ندارد.
- Separate terminal text transaction: حذف شد.
