# بازبینی مستقل API 01C.1

## اصالت و تست

- Workspace SHA-256: `d5fd5d22bdacc946620f1075b5ee85eb23afddf56b1575a751f33a1c8be7bbb7`
- ۸۹ Unit/Security PASS
- Ruff و Compileall PASS
- ۳۶ Integration منتظر PostgreSQL CI

## وضعیت F01–F08

اصلاح‌های اصلی انجام شده‌اند:

- Live Action به Event پایدار تبدیل شده است.
- Deduplicate/Throttle داخل Function قفل‌شده PostgreSQL است.
- Markerهای Completion پایدار شده‌اند.
- occurred_at و recorded_at جدا هستند.
- Goal ذخیره می‌شود.
- API Idempotency اتمیک طراحی شده است.
- Concurrent Stop reread دارد.
- Chunked Body Limit پیش از Buffer کامل اجرا می‌شود.

## Blocker جدید — Race پایان SSE

Completion در دو Transaction انجام می‌شود:

1. Run به `completed` Transition می‌کند.
2. سپس `live_action.updated` با متن «آماده شد» Persist می‌شود.

SSE ممکن است بین این دو Transaction وضعیت Terminal را ببیند و Stream را ببندد. در نتیجه پیام نهایی Live Action از دست می‌رود.

همین مشکل برای Stop وجود دارد؛ Stop فعلی Transition را ثبت می‌کند اما Live Action `run.stopped` را اتمیک همراه آن ثبت نمی‌کند.

حتی اگر Transition و Live Action در یک Transaction باشند، SSE ابتدا Eventها و سپس State را در Queryهای جدا می‌خواند. اگر Commit میان این دو Query رخ دهد، SSE می‌تواند Terminal را ببیند ولی Event را در Query قبلی ندیده باشد.

## اصلاح لازم

1. Terminal Transition و Terminal Live Action در یک Transaction ثبت شوند.
2. CompletionService انتشار دوم جدا نداشته باشد.
3. Stop نیز `run.stopped` را اتمیک ثبت کند.
4. SSE پس از مشاهده Terminal، یک Final Drain Query انجام دهد و فقط بعد از خالی‌بودن آن بسته شود.
5. تست Race قطعی اضافه شود.

## حکم

`BLOCKED_TERMINAL_EVENT_RACE`

پیش از API CI، این Race باید بسته شود.
