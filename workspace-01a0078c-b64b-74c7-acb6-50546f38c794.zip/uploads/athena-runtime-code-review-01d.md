# بازبینی مستقل Requirement Compiler 01D

## اصالت و تست

- Workspace SHA-256: `facb4e7d8c3f0e891eff409c9128315a20a04de5dcbf08e98e79d432b9b26620`
- ۱۱۷ Unit/Security PASS
- Ruff و Compileall PASS
- ۳۶ Design Case اجرا شده است

## حکم

`BLOCKED_FOR_HOLDOUT_AND_CONTRACT_FIX`

امتیاز ۱.۰۰۰ در Dataset فعلی معیار تعمیم نیست. Ruleها روی همان Design Set ساخته و تست شده‌اند و بخشی از Memory Caseها مستقیماً از Expected Label به Fixture Provider تزریق می‌شوند.

## F01 — Missing Hard Slot می‌تواند DIRECT شود

اگر سؤال قبلاً پرسیده شده باشد یا سقف سه سؤال تمام شود، Clarifier مقدار None برمی‌گرداند؛ ولی Pipeline با وجود `missing_hard_slots=('subject',)` تصمیم `DIRECT` می‌دهد.

این رفتار مستقل بازتولید شد:

```text
question=None
 decision=DIRECT
 missing_hard_slots=('subject',)
 route=R2
```

### الزام

هیچ DIRECT، RESEARCH، TOOL یا COMPLEX_RUN با Hard Slot نامشخص/متناقض مجاز نیست.

## F02 — Golden Memory به Expected Label متصل است

`GoldenSetRunner` برای Domain حافظه، از ستون Expected استفاده می‌کند و Fixture دقیق Provider می‌سازد. بنابراین امتیاز Memory مستقل نیست.

### الزام

Expected Label فقط Scoring باشد؛ هرگز ورودی Provider یا Compiler نشود.

## F03 — Dataset فقط Design Set است

تمام ۳۶ Case داخل پرامپت دیده شده‌اند. Holdout واقعی وجود ندارد. Precision/Recall فعلی فقط Fixture Conformance است.

### الزام

یک Holdout جدید با عبارت‌ها، غلط‌ها و موضوع‌های دیده‌نشده اجرا شود. نتیجه Design و Holdout جدا گزارش شود.

## F04 — Context به‌شکل رشته‌ی دست‌ساز است

History و Memory به‌صورت `tuple[str]` و Prefixهایی مانند `subject:` و `memory:` منتقل می‌شوند. این روش مرز ساختاری قابل اعتماد نیست و Prompt Injection یا Parse اشتباه ایجاد می‌کند.

### الزام

Context مدل ساختاریافته داشته باشد:

- Known Slot
- Source Type
- Source ID
- Confidence
- Scope

Fake Provider نباید Prefix رشته‌ای را Parse کند.

## F05 — Attachment Manifest رشته‌ای است

Filename یا رشته‌ی آزاد جای Manifest تایپ‌شده استفاده شده است.

### الزام

Attachment Manifest شامل ID، Media Type، Purpose و Ready Status باشد. Path یا فایل واقعی وارد Compiler نشود.

## F06 — Required Capability برای DIRECT اشتباه است

تمام DIRECTها `required_capability=none` می‌گیرند، در حالی که Caption، Writing و Content به `text_generation` نیاز دارند.

### الزام

Capability مستقل از Decision Kind و بر اساس Task/Output تعیین شود.

## F07 — Risk Detection بسیار محدود است

فقط چند Keyword پزشکی HIGH می‌شوند. Legal و Financial حساس پوشش ندارند. Safety Patternها نیز بسیار Exact هستند.

### الزام

Rule Baseline باید دسته‌های پزشکی، حقوقی، مالی، کودک، جعل هویت، داده کاربر دیگر و Secret را با Reason Code پوشش دهد. این Ruleها هنوز جای Safety Model آینده نیستند.

## F08 — Slot.value از نوع Any است

در PoC قابل قبول است، اما پیش از Persist یا Model Prompt باید Valueهای Structured و محدود شوند.

### تصمیم

در این مرحله حداقل Value را JSON-safe و Size-limited کن. Schema تخصصی هر Slot در مرحله بعد قابل توسعه است.

## نقاط قوت

- Slot Provenance و Status طراحی مناسب دارند.
- Slot Packها Versionدار و Data-driven هستند.
- سؤال‌ها ۲ تا ۴ گزینه دارند.
- Fake Provider شبکه ندارد.
- Router نام مدل واقعی انتخاب نمی‌کند.
- ورودی، History و Attachment Count محدود شده‌اند.
- API و Persistence تغییر نکرده‌اند.

## Gate

قبل از Compiler CI، F01 تا F08 و Holdout مستقل باید اجرا شوند.

> امتیاز کامل روی داده‌ای که Ruleها با دیدن آن ساخته شده‌اند، نشان‌دهنده سازگاری است؛ نه کیفیت واقعی روی کاربر جدید.
