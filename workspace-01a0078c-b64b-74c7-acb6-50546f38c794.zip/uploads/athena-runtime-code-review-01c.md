# بازبینی مستقل API/SSE/Live Action 01C

## اصالت

- Workspace ZIP SHA-256: `bf504b24078313b03750203be28c826b453472f024ade862635041e04bdf2684`
- ZIP امن بود.
- Source نسخه `vmania-athena-runtime-poc-01c` بررسی شد.

## اجرای مستقل

- ۸۴ Unit/Security PASS
- Ruff PASS
- Compileall PASS
- ۳۲ Integration هنوز نیازمند PostgreSQL CI

## حکم

**BLOCKED_STATIC_BEFORE_API_CI**

API و SSE پایه مناسب‌اند، اما Live Action هنوز به Event Stream متصل نشده و Completion Gate حافظه‌ای است. قبل از CI باید Contract واقعی Live Action بسته شود.

---

## F01 — Live Action Projector به API/SSE متصل نیست

`LiveActionProjector` فقط در Unit Test استفاده می‌شود. `PostgresEventReadRepository` و `stream_events` Event خام را ارسال می‌کنند.

Client متن، Template Version و UserStatus دریافت نمی‌کند.

### اصلاح

- Composer باید قبل از Persist اجرا شود.
- نتیجه به‌عنوان Event واقعی `live_action.updated` با Visibility=user ذخیره شود.
- SSE فقط Event ذخیره‌شده را Replay کند.
- متن وضعیت هنگام Read دوباره تولید نشود.

---

## F02 — State مربوط به Deduplicate/Throttle حافظه‌ای است

`LiveActionProjector._states` process-local است. در Restart، چند Worker یا Reconnect رفتار تغییر می‌کند و Memory Leak نیز ممکن است.

### اصلاح

- Composer را Stateless کن.
- آخرین وضعیت نمایش‌داده‌شده از Event Store خوانده شود.
- تصمیم Deduplicate/Throttle قبل از Persist و زیر Lock Run انجام شود.
- Event نهایی Persist شود تا Replay دقیق باشد.

---

## F03 — Completion Gate حافظه‌ای است

Markerهای Quality، Artifact و Cost داخل Dict حافظه‌ای نگه‌داری می‌شوند. بعد از Restart یا روی Worker دیگر از بین می‌روند.

### اصلاح

- Markerها Eventهای داخلی Persistشده باشند.
- Completion Service آن‌ها را از PostgreSQL بررسی کند.
- فقط سپس Transition به completed انجام شود.
- Endpoint عمومی اجازه Completion نداشته باشد.

---

## F04 — PublicEvent زمان Ingest را جای زمان رخداد می‌فرستد

Repository مقدار `created_at` را در PublicEvent قرار می‌دهد. Live Action باید `occurred_at` واقعی را نمایش و Audit کند.

### اصلاح

- Contract هر دو زمان را در صورت نیاز جدا کند.
- زمان عمومی مرحله برابر `occurred_at` باشد.
- `created_at` فقط Metadata Ingest باشد.

---

## F05 — Goal پذیرفته ولی ذخیره نمی‌شود

`PostgresRunApiService.create_run` مقدار Goal را حذف می‌کند. Run ایجادشده ورودی اصلی کاربر را ندارد.

### اصلاح

- Goal با سقف و طبقه‌بندی مشخص در Run یا Request Table ذخیره شود.
- Log و Event عمومی Goal خام را نمایش ندهند.
- Goal از Client پذیرفته می‌شود، اما Workspace/Model/Tool/Budget نه.

---

## F06 — POST /runs Idempotency ندارد

Retry شبکه می‌تواند چند Run بسازد.

### اصلاح

- `Idempotency-Key` برای POST اجباری باشد.
- Key به Workspace، Endpoint و Request Hash متصل شود.
- Duplicate یکسان همان Response را Replay کند.
- Duplicate با Body متفاوت Conflict بدهد.
- Store پایدار PostgreSQL باشد.

---

## F07 — Stop هم‌زمان ممکن است 409 بدهد، نه نتیجه Idempotent

دو Stop هم‌زمان می‌توانند یکی را موفق و دیگری را Optimistic Conflict کنند.

### اصلاح

- بعد از Conflict، Run دوباره خوانده شود.
- اگر اکنون stopped است، همان وضعیت موفق برگردد.
- اگر State دیگری است، Conflict واقعی باقی بماند.

---

## F08 — Body Limit پس از خواندن کامل Body اعمال می‌شود

Middleware با `await request.body()` کل Chunked Body را در حافظه می‌خواند و سپس اندازه را بررسی می‌کند.

### اصلاح

- Hard Limit در Reverse Proxy الزامی مستند شود.
- در ASGI یک Receive Wrapper محدودکننده یا Middleware معتبر استفاده شود.
- تست Chunked/Oversize بدون Content-Length اضافه شود.

---

## نقاط قوت

- Production Default Auth برابر 401 است.
- Workspace از Client پذیرفته نمی‌شود.
- Cross-workspace برابر 404 است.
- Error Contract امن و Request ID دارد.
- SSE Cursor، Heartbeat، Terminal Drain و Visibility طراحی مناسب دارند.
- SSE از PostgreSQL Event واقعی می‌خواند.
- Templateها ثابت و بدون Model Call هستند.
- Event ناشناخته و Payload حساس در Unit رد می‌شوند.
- CORS ستاره‌ای و Public Docs پیش‌فرض وجود ندارند.

## Gate

پیش از API CI، F01 تا F08 باید اصلاح شوند. سپس Unit، PostgreSQL Integration و Replay Tests اجرا شوند.

> Live Action فقط وقتی واقعی است که متن نهایی وضعیت به‌عنوان Event پایدار ثبت و همان Event در Reconnect بازپخش شود.
