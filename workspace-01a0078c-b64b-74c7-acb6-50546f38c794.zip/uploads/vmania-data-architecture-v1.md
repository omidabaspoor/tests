# معماری داده vmania AI — نسخه ۱

**وضعیت:** طراحی منطقی پیش از SQL  
**تاریخ:** ۲۴ مرداد ۱۴۰۵ / ۱۵ اوت ۲۰۲۶  
**دامنه:** نسخه‌ی آزمایشی آتنا برای حدود ۱۰۰ کاربر

---

## ۱. اصول قطعی

1. PostgreSQL منبع حقیقت است.
2. هر کاربر از ابتدا یک Workspace شخصی دارد.
3. همه‌ی داده‌های کاربرمحور دارای `workspace_id` هستند.
4. تاریخچه، حافظه، پروژه و Analytics از هم جدا هستند.
5. پیام‌ها و Ledger بی‌صدا بازنویسی نمی‌شوند.
6. Redis منبع حقیقت نیست.
7. فایل پیش از اسکن قابل استفاده نیست.
8. داده‌ی حذف‌شده نباید از Cache، Embedding یا Queue برگردد.
9. مدل و هرمس به Database دسترسی مستقیم ندارند.
10. شماره کارت بانکی و CVV در vmania ذخیره نمی‌شوند.

---

# ۲. نقشه‌ی سطح بالا

```mermaid
flowchart LR
    UI[Web App] --> API[Application API]
    API --> PG[(PostgreSQL)]
    API --> REDIS[(Redis)]
    API --> OBJ[(Object Storage)]
    API --> OUTBOX[Transactional Outbox]
    OUTBOX --> WORKERS[Background Workers]
    WORKERS --> HERMES[Hermes Runtime]
    WORKERS --> SANDBOX[Sandbox Executor]
    WORKERS --> PROVIDERS[Model and Media Providers]
    WORKERS --> PG
    HERMES --> TOOL[Tool Broker]
    TOOL --> SANDBOX
    TOOL --> PROVIDERS
    TOOL --> WEB[Read-only Web Proxy]
```

## مرزها

- UI فقط API عمومی را می‌بیند.
- Hermes فقط از شبکه داخلی فراخوانی می‌شود.
- Tool Broker مجوز Intent Capsule را بررسی می‌کند.
- Provider Key فقط در Broker یا Provider Adapter است.
- فایل ابتدا وارد Quarantine می‌شود.

---

# ۳. ERD هویت و مالکیت

```mermaid
erDiagram
    USERS ||--|| WORKSPACES : owns_personal
    USERS ||--o{ WORKSPACE_MEMBERS : has
    WORKSPACES ||--o{ WORKSPACE_MEMBERS : includes
    USERS ||--o{ USER_IDENTITIES : authenticates_with
    USERS ||--o{ AUTH_SESSIONS : has
    USERS ||--o{ DEVICES : recognizes
    USERS ||--o{ CONSENTS : grants
    USERS ||--o{ OTP_CHALLENGES : requests
    GUEST_SESSIONS ||--o{ RUNS : starts

    USERS {
      uuid id PK
      string status
      string locale
      string age_band
      datetime created_at
      datetime deleted_at
    }

    USER_IDENTITIES {
      uuid id PK
      uuid user_id FK
      string identity_type
      bytes encrypted_value
      string lookup_hash
      boolean verified
    }

    WORKSPACES {
      uuid id PK
      string type
      uuid owner_user_id FK
      string status
    }

    WORKSPACE_MEMBERS {
      uuid workspace_id FK
      uuid user_id FK
      string role
      string status
    }

    AUTH_SESSIONS {
      uuid id PK
      uuid user_id FK
      string refresh_hash
      datetime expires_at
      datetime revoked_at
    }

    CONSENTS {
      uuid id PK
      uuid user_id FK
      string consent_type
      string policy_version
      datetime granted_at
      datetime revoked_at
    }

    GUEST_SESSIONS {
      uuid id PK
      string token_hash
      string risk_state
      integer budget_units
      datetime expires_at
    }
```

## قواعد

- `age_band` فقط `13_17` یا `18_plus` است.
- نسخه‌ی آزمایشی حساب زیر ۱۳ سال ایجاد نمی‌کند.
- شماره موبایل در `users` قرار نمی‌گیرد.
- مقدار Lookup شماره موبایل با Hash کنترل‌شده نگه‌داری می‌شود.
- OTP خام ذخیره نمی‌شود.
- Workspace شخصی بعداً می‌تواند بدون تغییر مالکیت داده به ساختار تیمی گسترش یابد.

---

# ۴. ERD پروژه، گفتگو و فایل

```mermaid
erDiagram
    WORKSPACES ||--o{ PROJECTS : owns
    PROJECTS ||--o{ PROJECT_PROFILES : describes
    PROJECTS ||--o{ CONVERSATIONS : groups
    WORKSPACES ||--o{ CONVERSATIONS : owns
    CONVERSATIONS ||--o{ MESSAGES : contains
    MESSAGES ||--o{ MESSAGE_PARTS : consists_of
    MESSAGES ||--o{ MESSAGE_REVISIONS : revised_by
    CONVERSATIONS ||--o{ CONVERSATION_SUMMARIES : summarized_by
    MESSAGE_PARTS }o--o| UPLOADS : references
    MESSAGE_PARTS }o--o| ARTIFACTS : references
    PROJECTS ||--o{ PROJECT_ASSETS : links
    UPLOADS ||--o{ UPLOAD_SCANS : checked_by
    ARTIFACTS ||--o{ ARTIFACT_VERSIONS : versioned_as
    ARTIFACTS ||--o{ ARTIFACT_DERIVATIVES : derives

    PROJECTS {
      uuid id PK
      uuid workspace_id FK
      string type
      string title
      string status
      datetime created_at
    }

    PROJECT_PROFILES {
      uuid id PK
      uuid project_id FK
      jsonb structured_profile
      integer version
    }

    CONVERSATIONS {
      uuid id PK
      uuid workspace_id FK
      uuid project_id FK
      string privacy_mode
      string recognition_level
      string status
      integer version
    }

    MESSAGES {
      uuid id PK
      uuid workspace_id FK
      uuid conversation_id FK
      string role
      string trust_level
      bigint sequence
      string status
      datetime created_at
    }

    MESSAGE_PARTS {
      uuid id PK
      uuid message_id FK
      string part_type
      text text_content
      uuid upload_id FK
      uuid artifact_id FK
      integer position
    }

    MESSAGE_REVISIONS {
      uuid id PK
      uuid message_id FK
      integer revision
      jsonb changed_parts
      datetime created_at
    }

    UPLOADS {
      uuid id PK
      uuid workspace_id FK
      string object_key
      string declared_mime
      string detected_mime
      bigint size_bytes
      string sha256
      string status
      string retention_class
    }

    ARTIFACTS {
      uuid id PK
      uuid workspace_id FK
      uuid project_id FK
      string artifact_type
      string status
      string retention_class
      datetime created_at
    }
```

## قواعد

- `project_id` اختیاری است؛ `workspace_id` اجباری است.
- Message Revision تاریخچه را حفظ می‌کند.
- Raw HTML در `text_content` قابل اجرا نیست.
- Upload تا وضعیت `ready` وارد Message پردازش‌شونده نمی‌شود.
- Blob بدون رکورد مجوز در PostgreSQL قابل دانلود نیست.
- نام اصلی فایل فقط Metadata است؛ Object Key تصادفی است.

---

# ۵. ERD Run و اجرای ایجنت

```mermaid
erDiagram
    CONVERSATIONS ||--o{ RUNS : executes
    RUNS ||--o{ RUN_ATTEMPTS : retries_as
    RUNS ||--o{ RUN_STEPS : contains
    RUNS ||--o{ RUN_EVENTS : emits
    RUNS ||--o{ APPROVALS : requests
    RUNS ||--o{ CLARIFICATIONS : asks
    RUNS ||--o{ INTERRUPTS : receives
    RUNS ||--o{ MODEL_CALLS : invokes
    RUNS ||--o{ TOOL_CALLS : invokes
    RUNS ||--o{ ARTIFACTS : creates
    RUNS ||--o{ QUALITY_EVALUATIONS : evaluated_by
    RUNS ||--|| INTENT_CAPSULES : constrained_by
    MODEL_REGISTRY ||--o{ MODEL_CALLS : serves
    TOOL_REGISTRY ||--o{ TOOL_CALLS : serves
    ROUTE_POLICIES ||--o{ RUNS : routes

    RUNS {
      uuid id PK
      uuid workspace_id FK
      uuid conversation_id FK
      uuid user_message_id FK
      string status
      string complexity
      string route_tier
      uuid route_policy_id FK
      bigint max_cost_microunits
      bigint reserved_cost_microunits
      integer max_steps
      datetime deadline_at
      string idempotency_key
    }

    RUN_ATTEMPTS {
      uuid id PK
      uuid run_id FK
      integer attempt_number
      string reason
      string status
      datetime started_at
      datetime ended_at
    }

    RUN_EVENTS {
      uuid id PK
      uuid run_id FK
      bigint sequence
      string event_type
      string visibility
      jsonb payload
      datetime created_at
    }

    MODEL_CALLS {
      uuid id PK
      uuid run_id FK
      uuid attempt_id FK
      uuid model_registry_id FK
      string provider_request_id
      bigint input_tokens
      bigint output_tokens
      bigint cost_microunits
      integer latency_ms
      string status
    }

    TOOL_CALLS {
      uuid id PK
      uuid run_id FK
      uuid attempt_id FK
      uuid tool_registry_id FK
      string operation
      string idempotency_key
      bigint cost_microunits
      integer duration_ms
      string status
    }

    INTENT_CAPSULES {
      uuid id PK
      uuid run_id FK
      jsonb permitted_scope
      string signature
      string nonce
      datetime expires_at
    }
```

## Run State Machine

```mermaid
stateDiagram-v2
    [*] --> created
    created --> validating
    validating --> needs_clarification
    validating --> needs_approval
    validating --> queued
    needs_clarification --> validating
    needs_approval --> queued
    queued --> running
    running --> quality_check
    quality_check --> completed
    quality_check --> running: repair
    running --> failed
    running --> stopped
    validating --> blocked
    queued --> expired
    needs_clarification --> expired
    needs_approval --> expired
    completed --> [*]
    failed --> [*]
    stopped --> [*]
    blocked --> [*]
    expired --> [*]
```

## قواعد

- هر Conversation فقط یک Run فعال دارد.
- Retry یک `run_attempt` جدید می‌سازد.
- Run با وضعیت نهایی دوباره Running نمی‌شود.
- `run_events` فقط Append می‌شود.
- `sequence` در محدوده Run یکتا است.
- Intent Capsule قابل تغییر نیست؛ تغییر هدف Run جدید می‌سازد.
- Chain-of-Thought در Event یا Database ذخیره نمی‌شود.

---

# ۶. ERD حافظه، تحقیق و کیفیت

```mermaid
erDiagram
    WORKSPACES ||--o{ MEMORIES : owns
    PROJECTS ||--o{ MEMORIES : scopes
    MEMORIES ||--o{ MEMORY_EVENTS : changes
    MEMORIES ||--o{ MEMORY_SOURCES : proves
    MEMORIES ||--o{ MEMORY_EMBEDDINGS : indexes
    MESSAGES ||--o{ MEMORY_SOURCES : originates
    RUNS ||--o{ RESEARCH_PACKS : uses
    RESEARCH_PACKS ||--o{ SOURCES : contains
    RESEARCH_PACKS ||--o{ CLAIMS : extracts
    CLAIMS ||--o{ CLAIM_SOURCES : supported_by
    SOURCES ||--o{ CLAIM_SOURCES : supports
    RUNS ||--o{ QUALITY_CHECKS : checks
    RUNS ||--o{ QUALITY_EVALUATIONS : grades
    RUBRIC_VERSIONS ||--o{ QUALITY_EVALUATIONS : defines
    ARTIFACTS ||--o{ OUTPUT_FEEDBACK : receives
    RUNS ||--o{ OUTPUT_REPAIRS : repairs

    MEMORIES {
      uuid id PK
      uuid workspace_id FK
      uuid project_id FK
      string memory_type
      string subject
      jsonb value
      string origin_type
      decimal confidence
      string sensitivity
      string status
      datetime valid_at
      datetime invalid_at
    }

    MEMORY_EVENTS {
      uuid id PK
      uuid memory_id FK
      string action
      string reason_code
      datetime created_at
    }

    MEMORY_SOURCES {
      uuid id PK
      uuid memory_id FK
      uuid message_id FK
      string source_type
      string source_pointer
    }

    RESEARCH_PACKS {
      uuid id PK
      uuid workspace_id FK
      uuid run_id FK
      string freshness_class
      datetime valid_until
      string status
    }

    SOURCES {
      uuid id PK
      uuid research_pack_id FK
      string canonical_url
      string publisher
      datetime published_at
      datetime retrieved_at
      string content_hash
      string trust_level
    }

    CLAIMS {
      uuid id PK
      uuid research_pack_id FK
      text claim_text
      string importance
      string verification_status
    }

    QUALITY_EVALUATIONS {
      uuid id PK
      uuid run_id FK
      uuid rubric_version_id FK
      string judge_model_version
      string verdict
      jsonb scores
      jsonb reason_codes
    }
```

## قواعد

- Memory Source اجباری است.
- استنباط بدون Confidence ذخیره نمی‌شود.
- حذف Memory، Embedding و Cache مشتق را حذف می‌کند.
- Source URL با Claim پشتیبانی‌شده یکی نیست؛ رابطه جدا است.
- Citation فقط از Claim تاییدشده ساخته می‌شود.
- Judge Reasoning ذخیره نمی‌شود.

---

# ۷. ERD مالی، حریم خصوصی و Audit

```mermaid
erDiagram
    WORKSPACES ||--o{ SUBSCRIPTIONS : has
    WORKSPACES ||--o{ WALLET_ACCOUNTS : owns
    WALLET_ACCOUNTS ||--o{ LEDGER_ENTRIES : records
    RUNS ||--o{ USAGE_RESERVATIONS : reserves
    RUNS ||--o{ USAGE_EVENTS : consumes
    USAGE_RESERVATIONS ||--o{ LEDGER_ENTRIES : settles
    USERS ||--o{ DATA_EXPORT_REQUESTS : requests
    USERS ||--o{ DELETION_REQUESTS : requests
    DELETION_REQUESTS ||--o{ DELETION_TASKS : expands
    USERS ||--o{ AUDIT_EVENTS : acts
    SECURITY_INCIDENTS ||--o{ AUDIT_EVENTS : contains
    OUTBOX_EVENTS }o--|| RUNS : publishes

    WALLET_ACCOUNTS {
      uuid id PK
      uuid workspace_id FK
      string account_type
      string currency
      string status
    }

    LEDGER_ENTRIES {
      uuid id PK
      uuid wallet_account_id FK
      string entry_type
      bigint amount_microunits
      string reference_type
      uuid reference_id
      string idempotency_key
      datetime created_at
    }

    USAGE_RESERVATIONS {
      uuid id PK
      uuid run_id FK
      bigint reserved_microunits
      bigint settled_microunits
      string status
    }

    DELETION_REQUESTS {
      uuid id PK
      uuid user_id FK
      string scope
      string status
      datetime verified_at
      datetime recovery_until
      datetime completed_at
    }

    DELETION_TASKS {
      uuid id PK
      uuid deletion_request_id FK
      string target_system
      string target_type
      string status
      integer retry_count
    }

    AUDIT_EVENTS {
      uuid id PK
      uuid actor_user_id FK
      string actor_type
      string action
      string resource_type
      uuid resource_id
      string result
      datetime created_at
    }
```

## قواعد Ledger

- Ledger Entry ویرایش یا حذف نمی‌شود.
- اصلاح با Entry معکوس انجام می‌شود.
- Balance از Ledger قابل بازسازی است.
- هر Run ابتدا Reserve و سپس Settle می‌شود.
- Card Number، CVV و رمز پویا وارد Database نمی‌شوند.
- Payment Gateway Reference ذخیره می‌شود.

---

# ۸. طبقه‌بندی داده

طبقه‌بندی اصلی با برچسب‌های تکمیلی استفاده می‌شود. یک رکورد می‌تواند مثلاً `D2 + PERSONAL + MINOR` باشد.

## سطح‌های اصلی

| سطح | نام | تعریف | مثال |
|---|---|---|---|
| D0 | عمومی | برای انتشار عمومی ساخته شده | صفحه قیمت، مقاله منتشرشده، وضعیت سرویس |
| D1 | داخلی | انتشار آن آسیب محدود عملیاتی دارد | شناسه نسخه Prompt، آمار تجمیعی، تنظیم Feature Flag غیرحساس |
| D2 | محرمانه | داده کاربر یا کسب‌وکار که افشایش زیان‌آور است | گفتگو، پروژه، خروجی، حافظه، Usage، فایل معمولی |
| D3 | محدودشده | افشا یا سوءاستفاده می‌تواند آسیب شدید ایجاد کند | شماره موبایل، Token، تصویر چهره خصوصی، داده نوجوان، اطلاعات بانکی/سلامت/حقوقی، Secret |

## برچسب‌های تکمیلی

- `PERSONAL`: قابل اتصال به یک فرد
- `MINOR`: مربوط به کاربر ۱۳ تا ۱۷ سال
- `AUTH`: مربوط به هویت یا Session
- `FINANCIAL`: مربوط به پرداخت یا اعتبار
- `HEALTH`: اطلاعات سلامت
- `LEGAL`: اطلاعات حقوقی حساس
- `BIOMETRIC_LIKE`: تصویر چهره یا صدای قابل شناسایی
- `SECRET`: Credential یا کلید
- `PUBLIC_SOURCE`: از منبع عمومی
- `USER_PROVIDED`: توسط کاربر ارائه شده
- `DERIVED`: استنباط یا مشتق‌شده

## قواعد برخورد

| کنترل | D0 | D1 | D2 | D3 |
|---|---:|---:|---:|---:|
| رمزنگاری انتقال | الزامی | الزامی | الزامی | الزامی |
| رمزنگاری ذخیره | استاندارد | استاندارد | الزامی | الزامی + مدیریت کلید سخت‌گیرانه |
| Workspace Scope | در صورت مالکیت | الزامی | الزامی | الزامی |
| ثبت محتوای خام در Log | مجاز با نیاز | محدود | ممنوع پیش‌فرض | ممنوع |
| ارسال به Provider رایگان | مجاز | فقط غیرشخصی | ممنوع Production | ممنوع |
| دسترسی ادمین | عادی | نیاز کاری | دلیل + Audit | دلیل + Audit + دسترسی محدودتر |
| استفاده در Dataset | مجاز طبق منبع | بازبینی | فقط رضایت و ناشناس‌سازی | پیش‌فرض ممنوع |
| Cache مشترک | مجاز | فقط غیرشخصی | ممنوع | ممنوع |
| لینک عمومی | مجاز | ممنوع | ممنوع | ممنوع |

## اصل High-Water Mark

اگر یک Artifact شامل چند سطح باشد، بالاترین سطح بر کل Artifact اعمال می‌شود. فایل دارای یک شماره موبایل، D3 محسوب می‌شود حتی اگر بقیه محتوا عمومی باشد.

---

# ۹. ماتریس نگه‌داری اولیه

این اعداد Policy نهایی قانونی نیستند. پیش از عرضه عمومی باید با مشاور حقوقی و حسابداری ایران بازبینی شوند.

| داده | طبقه | نگه‌داری اولیه | حذف یا انقضا |
|---|---|---|---|
| Guest Session | D2 | حداکثر ۲۴ ساعت | خودکار |
| فایل ورودی مهمان | D2/D3 | تا پایان Run؛ حداکثر ۲۴ ساعت | خودکار از Object Storage و Index |
| خروجی مهمان | D2 | حداکثر ۲۴ ساعت | خودکار مگر انتقال با رضایت |
| سیگنال ضدسوءاستفاده مهمان | D1/D2 | ۳۰ روز پیشنهادی | Pseudonymous و بازبینی‌شونده |
| OTP خام | D3 | ذخیره نمی‌شود | فقط Hash کوتاه‌عمر |
| OTP Challenge | D3 | انقضای چند دقیقه؛ Metadata امنیتی حداکثر ۳۰ روز | خودکار |
| Auth Session | D3 | تا Expiry یا Revocation | Token لغو؛ Metadata امنیتی محدود |
| Conversation | D2/D3 | طبق تنظیم کاربر | حذف انتخابی یا Account Deletion |
| Anonymous Conversation | D2/D3 | بدون تاریخچه پایدار؛ Buffer فنی کوتاه | حداکثر ۲۴ ساعت برای پاک‌سازی خطا، ترجیحاً کمتر |
| Upload حساب‌دار | D2/D3 | طبق تنظیم تاریخچه/کتابخانه | حذف کاربر یا سیاست فضا |
| Memory | D2/D3 | تا حذف، TTL یا خاموشی شناخت | حذف فعال و تمام مشتقات |
| Embedding | همان منبع | دقیقاً عمر منبع | هم‌زمان با منبع |
| Research Pack عمومی | D0/D1 | بر اساس Freshness؛ ۱ تا ۳۰ روز | Refresh یا Expire |
| Model Call Metadata | D1/D2 | ۹۰ روز پیشنهادی | بدون Prompt خام |
| Prompt/Response خام برای Debug | D2/D3 | پیش‌فرض ذخیره نمی‌شود | فقط Opt-in محدود |
| Quality Evaluation | D1/D2 | ۱ سال پیشنهادی | متن خام تابع منبع |
| Feedback | D2 | تا حذف حساب یا دوره تحلیل | Pseudonymize پس از حذف |
| Cost و Usage Ledger | D1/D2 | طبق الزام مالی | محتوای شخصی نگه ندارد |
| Invoice و تراکنش | D2/FINANCIAL | طبق الزام مالی و مالیاتی ایران | مدت دقیق با حسابدار |
| Audit ادمین | D2/D3 | ۱ تا ۲ سال پیشنهادی | Append-Only؛ بازبینی حقوقی |
| Security Incident | D3 | طبق شدت و الزام قانونی | Legal Hold در صورت نیاز |
| Backup | مطابق منبع | چرخه ۳۰ روز پیشنهادی | Age-out کنترل‌شده |
| Golden Dataset | D2 | فقط با رضایت؛ بازبینی سالانه | Withdrawal و حذف مشتقات |

## تمایز مهم

- **حذف حافظه:** بلافاصله از Context، Search، Cache و Embedding خارج می‌شود.
- **حذف حساب:** می‌تواند دوره بازیابی ۳۰ روزه داشته باشد؛ پس از آن Purge اجرا می‌شود.
- **رکورد مالی:** ممکن است به دلیل قانون باقی بماند، اما از محتوای گفتگو و حافظه جدا و Pseudonymized می‌شود.
- **Backup:** حذف فوری داخل نسخه پشتیبان همیشه ممکن نیست؛ داده با Age-out حذف و در Restore دوباره Purge می‌شود.

---

# ۱۰. Data Processing Inventory

برای هر نوع داده این فیلدها ثبت می‌شوند:

| فیلد | توضیح |
|---|---|
| Data Owner | مسئول سازمانی |
| Data Subject | کاربر، ادمین یا عموم |
| Purpose | چرا جمع می‌شود |
| Required | ضروری یا اختیاری |
| Classification | D0 تا D3 |
| Tags | PERSONAL، MINOR و غیره |
| Source | کاربر، سیستم، وب یا Provider |
| Storage | PostgreSQL، Object Storage، Redis یا Provider |
| Processors | سرویس‌ها و Providerها |
| Retention | مدت و Trigger حذف |
| User Control | مشاهده، اصلاح، دانلود، حذف |
| Legal Hold | امکان توقف حذف قانونی |
| Transfer Region | محل پردازش و انتقال |

هر Data Element بدون Purpose مشخص نباید وارد Schema شود.

---

# ۱۱. Data Flowهای حساس

## فایل کاربر

```mermaid
flowchart LR
    U[User] --> P[Upload Policy]
    P --> Q[Quarantine Bucket]
    Q --> S[Scan Sandbox]
    S -->|clean| R[Ready]
    S -->|unsafe| X[Rejected and Deleted]
    R --> M[Selected Provider]
    M --> A[Artifact]
    A --> O[User Library or Guest Expiry]
```

## حافظه

```mermaid
flowchart LR
    T[Completed Turn] --> C{Recognition On?}
    C -->|No| N[No long-term extraction]
    C -->|Yes| F[Sensitivity Filter]
    F --> E[Candidate Extraction]
    E --> D[Deduplicate and Resolve Conflict]
    D --> W[Write Memory Event]
    W --> R[Scoped Recall]
    R --> X[Context Budget]
```

## حذف

```mermaid
flowchart LR
    U[Verified User Request] --> D[Deletion Request]
    D --> G[Dependency Graph]
    G --> DB[Database]
    G --> OS[Object Storage]
    G --> CA[Cache]
    G --> IX[Index and Embedding]
    G --> Q[Queue]
    G --> DS[Datasets]
    DB --> V[Verification]
    OS --> V
    CA --> V
    IX --> V
    Q --> V
    DS --> V
    V --> C[Completion Receipt]
```

---

# ۱۲. فهرست داده‌هایی که نباید ذخیره شوند

- OTP خام
- CVV، رمز کارت و رمز پویا
- API Key داخل Prompt، Message یا Log
- Chain-of-Thought مدل
- Cookie یا Credential اینستاگرام
- Session مرورگر کاربر برای شبکه اجتماعی
- محتوای حالت ناشناس در حافظه بلندمدت
- داده حساس استخراج‌شده بدون هدف و رضایت
- Secret موجود در فایل یا کد، خارج از Vault
- Raw Provider Request در Analytics عمومی
- فایل ردشده پس از پایان بررسی امنیتی

---

# ۱۳. موارد لازم پیش از SQL Migration

- [ ] انتخاب UUIDv7 یا ULID
- [ ] ساخت Data Dictionary ستونی
- [ ] تعیین تمام Foreign Keyها و Delete Behavior
- [ ] طراحی Indexها و Unique Constraintها
- [ ] طراحی RLS Policy برای هر جدول Workspace
- [ ] تعریف App Role، Migration Role و Admin Break-glass Role
- [ ] تعیین Partition برای Run Event، Model Call و Audit در صورت نیاز
- [ ] تعیین Retention عددی با حقوقی و حسابداری
- [ ] انتخاب روش رمزنگاری فیلد شماره موبایل
- [ ] تعیین Object Storage و Quarantine Bucket
- [ ] تست Restore و Purge پس از Restore
- [ ] Threat Model Review برای Schema
- [ ] ساخت Migration Rollback Plan

---

# ۱۴. معیار پذیرش

- هیچ جدول کاربرمحور بدون `workspace_id` نباشد.
- هیچ فایل بدون وضعیت Scan قابل مصرف نباشد.
- هیچ Route مالی بدون Ledger و Idempotency نباشد.
- هیچ حافظه بدون Source و Scope نباشد.
- هیچ Citation بدون Claim Source نباشد.
- هیچ Event کاربر شامل Chain-of-Thought یا Secret نباشد.
- هیچ حذف تاییدشده‌ای مشتقات قابل بازیابی باقی نگذارد.
- App Runtime نتواند RLS را Bypass کند.
- همه‌ی Data Elementها Purpose و Retention داشته باشند.

> اصل نهایی: داده‌ای که هدف، مالک، طبقه‌بندی، محل، مدت نگه‌داری و روش حذف آن مشخص نیست، نباید جمع‌آوری شود.
