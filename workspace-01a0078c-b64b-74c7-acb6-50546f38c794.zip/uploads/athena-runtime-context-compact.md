# زمینه‌ی فشرده Athena Runtime برای MVP

## تصمیم

Hermes Agent از هسته MVP حذف شد. دلیل: سه Side Effect غیرمجاز در Tool Authorization و Patch امنیتی گسترده.

MVP از Runtime محدود و اختصاصی آتنا استفاده می‌کند.

## هدف Runtime

- اجرای کارهای چندمرحله‌ای محدود
- Policy قطعی خارج از مدل
- Tool Broker Fail-Closed
- Event و State قابل ذخیره
- Budget و Idempotency
- بدون Tool Discovery پویا

## محدوده MVP

Toolهای مجاز آینده:

- Search Read-only
- File Parse در Sandbox
- Image Generate/Edit Broker
- Artifact Builder
- Memory Recall/Commit

در مرحله‌ی فعلی فقط Canary Tool آزمایشی وجود دارد.

## موارد ممنوع

- Hermes
- Sub-agent
- MCP
- Plugin پویا
- Cron
- Host Terminal
- SSH
- Browser Login
- Database مستقیم توسط مدل
- Secret در Context
- افزایش Scope توسط Planner

## معماری

```text
Requirement Compiler
→ Athena Router
→ Planner JSON محدود
→ Policy Engine
→ Tool Broker
→ Quality Gate
```

## قانون Permission

```text
requested
∩ task_allowed
∩ server_maximum
∩ plan_scope
∩ remaining_budget
= effective_permission
```

نبود Policy، خطا، Timeout یا نتیجه مبهم برابر Deny است.

## Intent Capsule

Immutable و شامل:

- run_id
- workspace_id
- goal
- allowed operations
- budget
- max_steps
- expiry
- nonce
- policy_version

Client و مدل اجازه ساخت یا تغییر Capsule را ندارند.

## State Run

```text
created
→ validating
→ needs_clarification | needs_approval | queued
→ running
→ quality_check
→ completed | failed | stopped | expired | blocked
```

State نهایی دوباره Running نمی‌شود.

## اصل تست

- ابتدا تست شکست
- سپس کمترین پیاده‌سازی
- هیچ Side Effect خارج Temp Directory
- ۲۰ Run هم‌زمان با Policy متفاوت
- Tool غیرمجاز صفر بار
- Exception و Timeout برابر Deny
- Duplicate Key برابر یک Side Effect

## خارج از مرحله اول

- API وب
- PostgreSQL
- Redis
- SSE
- مدل واقعی
- حافظه واقعی
- فایل واقعی
- UI
- پرداخت
