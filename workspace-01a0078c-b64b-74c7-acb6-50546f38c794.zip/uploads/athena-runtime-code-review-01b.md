# بازبینی مستقل Persistence Core 01B

## اصالت

- Workspace ZIP SHA-256: `9a8a71a448aa085aa20a4567cce4e905a7c963546bc856ab0a60d60ca67c476c`
- ZIP بدون Path Traversal و Symlink بود.
- Source بدون پوشه `.git` بررسی شد.

## اجرای مستقل

- نصب Editable پروژه: **FAIL**
- علت: Hatchling مسیر Package را نمی‌شناسد.
- نصب مستقیم Dependencyها و اجرای Unit/Security:
  - `48 passed`
  - `22 deselected`
  - Ruff: PASS
  - Compileall: PASS
- PostgreSQL در محیط موجود نبود؛ Integration اجرا نشد.

## حکم

**BLOCKED — مطابق گزارش Agent.**

تعریف Integration Test خوب است، اما هیچ ادعای RLS، Concurrency، Migration یا Rollback هنوز اثبات نشده است.

---

# Blockerهای قبل از اجرای CI

## F01 — CI در مرحله نصب Package شکست می‌خورد

`pyproject.toml` تنظیم Package Selection برای Hatchling ندارد.

### شاهد

`pip install -e '.[dev]'` با خطای زیر متوقف شد:

```text
Unable to determine which files to ship inside the wheel
```

### اصلاح

```toml
[tool.hatch.build.targets.wheel]
packages = ["src/athena_runtime"]
```

ساخت Wheel و Editable Install باید هر دو تست شوند.

---

## F02 — تست RLS با اتصال Superuser انجام می‌شود

Workflow با کاربر `postgres` متصل می‌شود و سپس `SET LOCAL ROLE athena_app` اجرا می‌کند. این تست نشان نمی‌دهد Runtime واقعی بدون Superuser و بدون `BYPASSRLS` امن است؛ `session_user` همچنان postgres است.

### اصلاح

- Migration با Admin/Migration DSN اجرا شود.
- یک Login Role غیر‌Superuser و بدون `BYPASSRLS` خارج از Migration ساخته شود.
- Login Role فقط عضو `athena_app` باشد.
- Integration Engine با Login Role متصل شود.
- تست کند `session_user` Superuser نیست و `RESET ROLE` دسترسی اضافی ایجاد نمی‌کند.
- Application هرگز با postgres یا Table Owner متصل نشود.

---

## F03 — Roleهای Cluster داخل Schema Migration ساخته و حذف می‌شوند

ساخت و حذف Role در Migration جدول برای Database اشتراکی و Production مناسب نیست.

### اصلاح

- Role Bootstrap به فایل Infrastructure جدا منتقل شود.
- Migration فقط Table، Policy، Grant و Functionهای همان Schema را مدیریت کند.
- Downgrade Role مشترک را حذف نکند.
- CI ابتدا Bootstrap را با Admin اجرا کند.

---

## F04 — Migration تاریخی به Metadata زنده وابسته است

Revision از `metadata.create_all()` و `metadata.drop_all()` استفاده می‌کند. اگر Metadata در آینده تغییر کند، اجرای Migration قدیمی Schema متفاوتی می‌سازد.

### اصلاح

Revision باید از `op.create_table`، `op.create_index` و عملیات صریح همان نسخه استفاده کند. Migration قدیمی نباید رفتار خود را با تغییر کد آینده عوض کند.

---

## F05 — Event Model با Live Action آینده سازگار نیست

`RunStore` تمام `run_events` را می‌خواند و اگر Event Type غیر از `run.transitioned` باشد خطا می‌دهد. در آینده Live Action و Tool Progress نیز در همین Event Log خواهند بود.

همچنین Sequence فعلی هم نقش Transition Sequence و هم Global Event Sequence را دارد.

### اصلاح پیشنهادی

- `sequence`: ترتیب جهانی تمام Eventهای Run
- `transition_version`: فقط برای `run.transitioned`
- `occurred_at`: زمان رخداد Domain
- `created_at`: زمان ثبت Database
- Rehydrate فقط Eventهای Transition را بر اساس `transition_version` بخواند.
- Eventهای Live Action و Tool Progress بتوانند بین Transitionها قرار گیرند.
- Unique جهانی `(run_id, sequence)` حفظ شود.
- Unique انتقال `(run_id, transition_version)` برای Transitionها اضافه شود.

---

## F06 — زمان Domain Event از بین می‌رود

هنگام Insert، `RunTransitionEvent.occurred_at` ذخیره نمی‌شود. هنگام Load، `created_at` Database جای آن استفاده می‌شود.

### اصلاح

`occurred_at TIMESTAMPTZ NOT NULL` اضافه و همان مقدار Event ذخیره شود. `created_at` فقط زمان Ingest باشد.

---

## F07 — دو منبع برای Reserved Cost وجود دارد

`runs.reserved_cost_microunits` و `cost_reservations.reserved_microunits` هر دو وجود دارند، اما Store هزینه مقدار داخل Run را به‌روز نمی‌کند.

### اصلاح

در PoC، `cost_reservations` تنها منبع Reservation باشد و فیلد تکراری از `runs` حذف شود. اگر Snapshot سریع بعداً لازم شد، باید Transactional Projection باشد.

---

## F08 — چند Reservation برای یک Run ممکن است

Unique Constraint برای یک Reservation فعال در هر Run وجود ندارد.

### اصلاح

برای Scope فعلی یک Unique `(workspace_id, run_id)` اضافه شود یا سیاست چند Reservation به‌صورت صریح طراحی شود. برای PoC یک Reservation در هر Run ساده‌تر است.

---

## F09 — مسیر Transition فقط Terminal Reactivation را در DB می‌بندد

App Role می‌تواند با SQL مستقیم State غیرمجاز مانند `created → running` ثبت کند.

### اصلاح

- Repository تنها مسیر مجاز Runtime باقی بماند.
- برای Defense-in-depth، Trigger تمام Transitionهای مجاز را بررسی کند.
- تست مستقیم SQL برای Transition غیرمجاز اضافه شود.

---

# موارد مثبت

- PostgreSQL-only و بدون SQLite fallback
- RLS و FORCE RLS در طراحی
- Workspace Scope در تمام شش جدول
- Optimistic Lock
- Event + State + Outbox در Transaction مشترک
- Idempotency Lease منقضی به Reconciliation می‌رود
- Approval با UPDATE RETURNING اتمیک طراحی شده است
- Cost از Microunit استفاده می‌کند
- Outbox از SKIP LOCKED استفاده می‌کند
- ۲۲ Integration Test مناسب تعریف شده‌اند
- گزارش Agent صادقانه BLOCKED اعلام کرده است

## Gate

قبل از PostgreSQL Integration، F01 تا F09 باید اصلاح شوند. سپس GitHub Actions یا یک محیط دارای PostgreSQL 17 باید واقعاً اجرا شود.

> SQL تولیدشده و Test تعریف‌شده، جای اجرای واقعی PostgreSQL با Login Role غیر‌Superuser را نمی‌گیرد.
