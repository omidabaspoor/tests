# Compiler 01D.1 Hardening

## F01 — Hard Slot Gate

Pipeline بعد از Clarifier دوباره missing/conflicting hard slots را بررسی می‌کند. سؤال معتبر → CLARIFY؛ در سقف سؤال یا تکرار بی‌پاسخ → BLOCK با `REQUIRED_INFO_UNRESOLVED`. هیچ DIRECT/RESEARCH/TOOL/COMPLEX_RUN با missing hard slot ممکن نیست و tuple دقیق missing در Decision باقی می‌ماند.

## F02/F03 — No Label Leakage and Independent Holdout

GoldenSetRunner دیگر Expected/Route/Hard Check را به Provider تزریق نمی‌کند. Memory prompts نیز با rule عمومی Fake Provider پردازش می‌شوند. Expected فقط بعد از compile برای scoring خوانده می‌شود. H03 با mutation Expected ثابت‌بودن Compiler output را اثبات می‌کند.

Design `embedded-0.1` و Holdout `holdout-0.1` دو گزارش و JSON مستقل دارند؛ میانگین ترکیبی وجود ندارد. افت Design در MM003/MM007 صادقانه ثبت شده و با fixture label پنهان نشده است.

## F04 — Structured Context

`ContextFact` frozen شامل slot_name، JSON-safe value، source_type، source_id، confidence و scope است. `CompilerContext` فقط tuple fact و recent_turn_count دارد. Prefixهای `subject:` و `memory:` حذف شدند. Provider فقط Fact مرتبط با scope global، project:current یا task جاری را مصرف می‌کند. Fact cross-project نادیده گرفته می‌شود. Memory interface فقط Fact برمی‌گرداند و Store/write ندارد.

## F05 — Typed Attachment

`AttachmentManifest` فقط attachment_id، media_type، purpose و status enum دارد؛ extra field مانند path/url/filename رد می‌شود. فقط ready به extracted attachment/evidence تبدیل می‌شود؛ quarantined/rejected قابل استفاده نیست.

## F06 — Required Capability

Capability مستقل از DIRECT است: calculator، text generation، web research، image generation/edit، file parse، document builder، sandboxed code runtime، memory policy و policy response. CLARIFY و block عمومی none هستند؛ sensitive memory policy فقط policy capability دارد و write انجام نمی‌دهد.

## F07 — Risk Taxonomy

RiskClassifier عمومی categoryهای medical، legal، financial، minor sexual، deceptive real-person، cross-tenant، secret exposure، exfiltration، mass-cost، prompt injection و sensitive memory را تشخیص می‌دهد. Brief risk level/category/warning را با provenance ثبت می‌کند. Medical/legal/financial حداقل R3 و warning دارند. موارد ممنوع block reason ساختاریافته دارند.

## F08 — Slot Safety

Slot value پیش از Snapshot با canonical JSON، `allow_nan=False` و سقف 4096 bytes اعتبارسنجی می‌شود. Object دلخواه، NaN/Infinity و oversized value رد می‌شوند. List/Dict بعد از JSON round-trip به tuple immutable تبدیل می‌شوند.

## Holdout

20 Case جدید بدون Case-ID rule اجرا شدند. Expected فقط scoring است. Case-by-case: `compiler-01d1-holdout-report.md`. Machine metrics جداگانه در دو JSON design/holdout هستند.

## Boundaries

هیچ مدل، Tool، Search، Memory Store، UI، API endpoint یا persistence جدید ساخته نشده است.
