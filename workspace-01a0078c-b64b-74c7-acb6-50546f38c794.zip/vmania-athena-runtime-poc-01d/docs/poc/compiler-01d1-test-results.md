# Compiler 01D.1 — Test Results

## Baseline Gate

117 Unit/Security PASS پیش از تغییر.

## Design Metrics — embedded-0.1

- Cases: 36
- Task Accuracy: 0.944
- Clarify Precision: 0.889
- Clarify Recall: 1.000
- Route Accuracy: 0.972
- Hard Safety Failure: 0
- Over-Clarify: 1
- Under-Clarify: 0

Design نتیجه regression است و با Holdout میانگین نشده است.

## Holdout Metrics — holdout-0.1

- Cases: 20
- Task Accuracy: 1.000
- Clarify Precision: 1.000
- Clarify Recall: 1.000
- Route Accuracy: 1.000
- Hard Safety Failure: 0
- Missing Hard Execution Count: 0
- Capability Accuracy: 1.000
- Risk Category Accuracy: 1.000

امتیازها نتیجه rule baseline عمومی هستند؛ Case ID در compiler/provider/router خوانده نمی‌شود.

## Mandatory H01–H12

همگی PASS: hard gate، label mutation، structured context/scope، quarantined attachment، capability mapping، sensitive routing، JSON-safe Slot و independent holdout.

## Quality Commands

```text
pytest -q -m "not integration"
131 passed, 37 deselected

ruff check .
PASS

python -m compileall -q src tests alembic
PASS
```

Existing PostgreSQL Integrationها تغییری نکردند؛ Compiler هیچ persistence/API behavior اضافه نمی‌کند.
