import json
from pathlib import Path

import pytest
from pydantic import ValidationError

from athena_runtime.compiler.compiler import RequirementCompiler
from athena_runtime.compiler.holdout import HoldoutRunner
from athena_runtime.compiler.models import (
    AttachmentManifest,
    ClarificationState,
    CompilerContext,
    ContextFact,
    DecisionKind,
    RequiredLevel,
    Slot,
    SlotStatus,
    SourceType,
)
from athena_runtime.compiler.provider import FakeUnderstandingProvider


@pytest.fixture
def compiler() -> RequirementCompiler:
    return RequirementCompiler(FakeUnderstandingProvider())


@pytest.mark.asyncio
async def test_h01_missing_hard_after_question_cap_blocks(
    compiler: RequirementCompiler,
) -> None:
    result = await compiler.compile(
        "یه کپشن میخوام", clarification_state=ClarificationState(question_count=3)
    )
    assert result.question is None
    assert result.decision.decision is DecisionKind.BLOCK
    assert result.decision.reason_code == "REQUIRED_INFO_UNRESOLVED"
    assert result.decision.missing_hard_slots == ("subject",)


@pytest.mark.asyncio
async def test_h02_repeated_unanswered_question_blocks(
    compiler: RequirementCompiler,
) -> None:
    result = await compiler.compile(
        "یه کپشن میخوام",
        clarification_state=ClarificationState(
            asked_question_ids=frozenset({"q.subject"}), question_count=1
        ),
    )
    assert result.question is None
    assert result.decision.decision is DecisionKind.BLOCK
    assert result.decision.missing_hard_slots == ("subject",)


@pytest.mark.asyncio
async def test_h03_expected_label_mutation_cannot_change_compiler_output(
    tmp_path: Path,
) -> None:
    source = json.loads(
        Path("tests/fixtures/compiler/holdout_0_1.json").read_text(encoding="utf-8")
    )
    one = {"version": source["version"], "cases": [source["cases"][0]]}
    changed = json.loads(json.dumps(one))
    changed["cases"][0]["expected"] = "BLOCK"
    first_path, second_path = tmp_path / "first.json", tmp_path / "second.json"
    first_path.write_text(json.dumps(one, ensure_ascii=False), encoding="utf-8")
    second_path.write_text(json.dumps(changed, ensure_ascii=False), encoding="utf-8")
    first = await HoldoutRunner().run(first_path)
    second = await HoldoutRunner().run(second_path)
    assert first.cases[0]["decision"] == second.cases[0]["decision"]
    assert first.cases[0]["route"] == second.cases[0]["route"]
    assert first.cases[0]["capability"] == second.cases[0]["capability"]


@pytest.mark.asyncio
async def test_h04_raw_prefix_context_is_not_parsed(
    compiler: RequirementCompiler,
) -> None:
    with pytest.raises(TypeError, match="CompilerContext"):
        await compiler.compile("برای فردا محتوا بده", context=("subject:cafe",))  # type: ignore[arg-type]


@pytest.mark.asyncio
async def test_h05_structured_fact_fills_slot(compiler: RequirementCompiler) -> None:
    context = CompilerContext(
        facts=(
            ContextFact(
                slot_name="subject",
                value="coffee",
                source_type=SourceType.PROJECT,
                source_id="project-1",
                confidence=0.9,
                scope="project:current",
            ),
        )
    )
    result = await compiler.compile("برای فردا محتوا بده", context=context)
    assert result.brief.subject.value == "coffee"
    assert result.brief.subject.status is SlotStatus.INFERRED


@pytest.mark.asyncio
async def test_h06_cross_project_fact_is_ignored(compiler: RequirementCompiler) -> None:
    context = CompilerContext(
        facts=(
            ContextFact(
                slot_name="subject",
                value="other project",
                source_type=SourceType.PROJECT,
                source_id="project-other",
                confidence=1,
                scope="project:other",
            ),
        )
    )
    result = await compiler.compile("برای فردا محتوا بده", context=context)
    assert result.question is not None and result.question.slot_name == "subject"


@pytest.mark.asyncio
async def test_h07_quarantined_attachment_is_unusable(
    compiler: RequirementCompiler,
) -> None:
    attachment = AttachmentManifest(
        attachment_id="att-1",
        media_type="image/png",
        purpose="evidence",
        status="quarantined",
    )
    result = await compiler.compile(
        "پیجم چرا رشد نمیکنه بررسیش کن", attachment_manifest=(attachment,)
    )
    assert result.question is not None and result.question.slot_name == "evidence"


@pytest.mark.asyncio
async def test_h08_caption_capability_is_text_generation(
    compiler: RequirementCompiler,
) -> None:
    result = await compiler.compile("برای فروش قهوه سه کپشن کوتاه دوستانه برای اینستاگرام بده")
    assert result.decision.required_capability == "text_generation"


@pytest.mark.asyncio
async def test_h09_research_capability_is_web_research(
    compiler: RequirementCompiler,
) -> None:
    result = await compiler.compile("قیمت همین الان دلار چنده؟")
    assert result.decision.required_capability == "web_research"


@pytest.mark.asyncio
@pytest.mark.parametrize(
    ("prompt", "category"),
    [
        ("این سردرد چندروزه خطرناکه؟", "medical"),
        ("این بند قراردادم قانونیه؟", "legal"),
        ("کجا سرمایه گذاری کنم که ضرر نکنم؟", "financial"),
    ],
)
async def test_h10_sensitive_domains_are_r3_with_warning(
    compiler: RequirementCompiler, prompt: str, category: str
) -> None:
    attachment = (
        (
            AttachmentManifest(
                attachment_id="doc-1",
                media_type="application/pdf",
                purpose="source",
                status="ready",
            ),
        )
        if category == "legal"
        else ()
    )
    result = await compiler.compile(prompt, attachment_manifest=attachment)
    assert result.route.tier.value == "R3"
    assert result.route.warning_policy is not None
    assert result.brief.risk_category.value == category


def test_h11_slot_value_must_be_bounded_finite_json() -> None:
    with pytest.raises(ValidationError):
        Slot(
            value=float("nan"),
            status=SlotStatus.DEFAULTED,
            source="default-policy:test",
            required_level=RequiredLevel.OPTIONAL,
        )
    with pytest.raises(ValidationError):
        Slot(
            value=object(),
            status=SlotStatus.DEFAULTED,
            source="default-policy:test",
            required_level=RequiredLevel.OPTIONAL,
        )


@pytest.mark.asyncio
async def test_h12_holdout_runs_without_case_id_rules() -> None:
    metrics = await HoldoutRunner().run(Path("tests/fixtures/compiler/holdout_0_1.json"))
    assert metrics.case_count == 20
    assert metrics.hard_safety_failure == 0
    assert metrics.missing_hard_execution_count == 0
