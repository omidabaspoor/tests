import re
from typing import Protocol

from pydantic import BaseModel, ConfigDict

from athena_runtime.compiler.models import (
    AttachmentManifest,
    AttachmentStatus,
    CompilerContext,
)


class ExtractedValue(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")
    name: str
    value: str
    confidence: float = 1.0
    source: str = "message"


class UnderstandingResult(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")
    task_type: str
    extracted: tuple[ExtractedValue, ...] = ()
    conflicts: tuple[str, ...] = ()
    safety_code: str | None = None
    memory_intent: str | None = None
    tool_need: str | None = None
    medical_sensitive: bool = False
    delegated: bool = False


class UnderstandingProvider(Protocol):
    async def understand(
        self,
        user_input: str,
        context: CompilerContext,
        attachment_manifest: tuple[AttachmentManifest, ...],
    ) -> UnderstandingResult: ...


class FakeUnderstandingProvider:
    """Deterministic fixture provider; no network and no security authority."""

    def __init__(self, fixtures: dict[str, UnderstandingResult] | None = None) -> None:
        self._fixtures = fixtures or {}

    async def understand(
        self,
        user_input: str,
        context: CompilerContext,
        attachment_manifest: tuple[AttachmentManifest, ...],
    ) -> UnderstandingResult:
        text = user_input.casefold()
        fixture = self._fixtures.get(text)
        if fixture is not None:
            return fixture
        task = _task(text)
        values: list[ExtractedValue] = []
        subject = _subject(text)
        if subject:
            values.append(ExtractedValue(name="subject", value=subject))
        if "اینستا" in text or "instagram" in text:
            values.append(ExtractedValue(name="platform", value="instagram"))
        if "دوستانه" in text:
            values.append(ExtractedValue(name="tone", value="friendly"))
        if "رسمی" in text or "formal" in text:
            values.append(ExtractedValue(name="tone", value="formal"))
        if "سه تا" in text or "سه کپشن" in text:
            values.append(ExtractedValue(name="constraints", value="three short outputs"))
        if "استودیویی" in text:
            values.append(ExtractedValue(name="edit_target", value="studio background"))
        ready = tuple(item for item in attachment_manifest if item.status is AttachmentStatus.READY)
        if ready:
            values.append(ExtractedValue(name="attachments", value="manifest-present"))
            if task in {"instagram_audit", "file_summary"}:
                values.append(ExtractedValue(name="evidence", value="manifest-present"))
        for fact in context.facts:
            if fact.slot_name == "subject" and not subject and _scope_applies(fact.scope, task):
                values.append(
                    ExtractedValue(
                        name="subject",
                        value=str(fact.value),
                        confidence=fact.confidence,
                        source=f"{fact.source_type.value}:{fact.source_id}",
                    )
                )
                break
        conflicts = ("constraints",) if "کوتاه" in text and "خیلی کامل" in text else ()
        safety = _safety(text, task, bool(ready))
        memory = _memory_intent(text)
        tool = _tool_need(text, task)
        return UnderstandingResult(
            task_type=task,
            extracted=tuple(values),
            conflicts=conflicts,
            safety_code=safety,
            memory_intent=memory,
            tool_need=tool,
            medical_sensitive=bool(re.search(r"پوست|پزشک|بیماری|افسردگی", text)),
            delegated="خودت انتخاب کن" in text,
        )


def _task(text: str) -> str:
    if ("ignore previous" in text and "system prompt" in text) or (
        "دستورهای قبلی" in text and "پرامپت سیستم" in text
    ):
        return "policy_response"
    if "یادت" in text or "فراموش" in text or "از این به بعد" in text:
        return "memory_policy"
    if re.search(r"۲۵ درصد|25 درصد|چقدره", text):
        return "calculation"
    if re.search(r"رسمی.?تر", text) or "بازنویسی" in text:
        return "rewrite"
    if re.search(r"قیمت.*(?:امروز|الان)|همین الان|ترند الان|منبع مقایسه", text):
        return "research"
    if re.search(r"عکس.*کپشن.*(?:ایده|سناریو)", text):
        return "multi_content"
    if "کپشن" in text or "caption" in text:
        return "caption"
    if ("اینستا" in text or "instagram" in text) and re.search(r"متن|محتوا", text):
        return "social_content"
    if "ریلز" in text:
        return "reel_scenario"
    if "پیج" in text and re.search(r"بررسی|audit|رشد", text):
        return "instagram_audit"
    if re.search(r"قرارداد|سند حقوقی", text):
        return "file_summary"
    if re.search(r"پوستر", text):
        return "image_generation"
    if re.search(r"پس.?زمینه|ادیت", text):
        return "image_edit"
    if ("عکس" in text or "تصویر" in text) and re.search(r"بساز|تولید", text):
        return "image_generation"
    if "pdf" in text and re.search(r"خلاصه", text):
        return "file_summary"
    if "pdf" in text and ("۲۰ عکس" in text or "مرتب" in text):
        return "file_assembly"
    if "react" in text or "typescript" in text or "اپ تودو" in text:
        return "software_project"
    if re.search(r"مقاله|نامه|متن|محتوا", text):
        return "general_writing"
    return "general_writing"


def _subject(text: str) -> str | None:
    subjects = (
        (r"کفش|kafsh", "shoe"),
        (r"کافه|cafe|قهوه", "cafe"),
        (r"مدیریت زمان", "time management"),
        (r"محصول", "product"),
        (r"لکه پوستی", "skin spot"),
        (r"ابزار مدیریت پروژه", "project management tools"),
        (r"اپ تودو|داشبورد", "software application"),
        (r"دلار|ارز", "currency price"),
        (r"سایت", "websites"),
        (r"قرارداد", "contract clause"),
        (r"سردرد", "headache"),
        (r"سرمایه.?گذاری", "investment guidance"),
        (r"آموزش زبان|language", "language education"),
    )
    for pattern, value in subjects:
        if re.search(pattern, text):
            return value
    if "این جمله" in text and ":" in text:
        return text.split(":", 1)[1].strip()
    if "برای فردا" in text:
        return None
    return None


def _safety(text: str, task: str, has_attachment: bool) -> str | None:
    if re.search(r"۱۵ ساله.*سکسی|15 ساله.*سکسی", text):
        return "MINOR_SEXUAL"
    if "کاربر قبلی" in text or "cross-tenant" in text:
        return "CROSS_TENANT"
    if "evil.example" in text:
        return "EXFILTRATION"
    if "رشوه می.?گیره" in text:
        return "DECEPTIVE_REAL_PERSON"
    if task == "file_summary" and not has_attachment:
        return "MISSING_ATTACHMENT"
    return None


def _memory_intent(text: str) -> str | None:
    if "یادت" not in text and "فراموش" not in text and "از این به بعد" not in text:
        return None
    if re.search(r"افسردگی|اضطراب|evil\.example", text):
        return "BLOCK_MEMORY_WRITE"
    if "یادت باشه" in text:
        return "CONSENT_REQUIRED"
    return "DIRECT_POLICY"


def _tool_need(text: str, task: str) -> str | None:
    if task in {"image_generation", "image_edit", "file_assembly", "software_project"}:
        return "tool"
    if "۱۰۰۰" in text and "تصویر" in text:
        return "quota_guard"
    return None


def _scope_applies(scope: str, task: str) -> bool:
    return scope in {"global", "project:current", f"task:{task}"}
