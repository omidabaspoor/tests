from dataclasses import dataclass

from athena_runtime.compiler.models import FreshnessClass, RouteTier


@dataclass(frozen=True, slots=True)
class SlotPack:
    name: str
    version: str
    hard_slots: tuple[str, ...]
    quality_slots: tuple[str, ...]
    defaults: tuple[tuple[str, str], ...]
    allowed_questions: tuple[str, ...]
    output_type: str
    freshness: FreshnessClass
    baseline: RouteTier


PACKS: dict[str, SlotPack] = {
    "caption": SlotPack(
        "caption",
        "0.1",
        ("subject",),
        ("platform", "tone", "audience"),
        (("platform", "instagram"), ("tone", "friendly")),
        ("subject", "platform", "tone", "constraints"),
        "caption",
        FreshnessClass.STABLE,
        RouteTier.R2,
    ),
    "social_content": SlotPack(
        "social_content",
        "0.1",
        ("subject",),
        ("platform", "audience"),
        (("platform", "instagram"),),
        ("subject", "platform", "audience"),
        "social_content",
        FreshnessClass.STABLE,
        RouteTier.R2,
    ),
    "reel_scenario": SlotPack(
        "reel_scenario",
        "0.1",
        ("subject",),
        ("audience", "tone"),
        (("tone", "engaging"),),
        ("subject", "audience"),
        "reel_scenario",
        FreshnessClass.STABLE,
        RouteTier.R2,
    ),
    "ad_copy": SlotPack(
        "ad_copy",
        "0.1",
        ("subject", "audience"),
        ("platform", "constraints"),
        (),
        ("subject", "audience", "platform"),
        "ad_copy",
        FreshnessClass.PERIODIC,
        RouteTier.R2,
    ),
    "general_writing": SlotPack(
        "general_writing",
        "0.1",
        ("subject",),
        ("tone", "audience"),
        (("tone", "neutral"),),
        ("subject", "tone", "audience", "constraints"),
        "text",
        FreshnessClass.STABLE,
        RouteTier.R1,
    ),
    "instagram_audit": SlotPack(
        "instagram_audit",
        "0.1",
        ("evidence",),
        ("goal",),
        (),
        ("evidence", "goal"),
        "audit",
        FreshnessClass.DAILY,
        RouteTier.R3,
    ),
    "image_generation": SlotPack(
        "image_generation",
        "0.1",
        ("subject",),
        ("tone", "constraints"),
        (),
        ("subject", "tone"),
        "image",
        FreshnessClass.STABLE,
        RouteTier.R3,
    ),
    "image_edit": SlotPack(
        "image_edit",
        "0.1",
        ("edit_target",),
        ("constraints",),
        (),
        ("edit_target", "constraints"),
        "edited_image",
        FreshnessClass.STABLE,
        RouteTier.R3,
    ),
    "file_summary": SlotPack(
        "file_summary",
        "0.1",
        ("attachments",),
        ("output_type",),
        (("output_type", "summary"),),
        ("attachments", "output_type"),
        "summary",
        FreshnessClass.STABLE,
        RouteTier.R2,
    ),
    "research": SlotPack(
        "research",
        "0.1",
        ("subject",),
        ("success_criteria",),
        (),
        ("subject", "success_criteria"),
        "research_report",
        FreshnessClass.LIVE,
        RouteTier.R3,
    ),
    "calculation": SlotPack(
        "calculation", "0.1", (), (), (), (), "number", FreshnessClass.STABLE, RouteTier.R0
    ),
    "rewrite": SlotPack(
        "rewrite",
        "0.1",
        ("subject",),
        ("tone",),
        (),
        ("subject", "tone"),
        "rewritten_text",
        FreshnessClass.STABLE,
        RouteTier.R1,
    ),
    "file_assembly": SlotPack(
        "file_assembly",
        "0.1",
        (),
        ("attachments",),
        (),
        (),
        "pdf",
        FreshnessClass.STABLE,
        RouteTier.R2,
    ),
    "software_project": SlotPack(
        "software_project",
        "0.1",
        ("subject",),
        ("constraints",),
        (),
        ("subject", "constraints"),
        "software_project",
        FreshnessClass.STABLE,
        RouteTier.R3,
    ),
    "multi_content": SlotPack(
        "multi_content",
        "0.1",
        ("subject",),
        ("platform", "audience"),
        (("platform", "instagram"),),
        ("subject", "platform"),
        "content_plan",
        FreshnessClass.STABLE,
        RouteTier.R3,
    ),
    "memory_policy": SlotPack(
        "memory_policy",
        "0.1",
        (),
        (),
        (),
        (),
        "memory_policy_decision",
        FreshnessClass.STABLE,
        RouteTier.R1,
    ),
    "policy_response": SlotPack(
        "policy_response",
        "0.1",
        (),
        (),
        (),
        (),
        "safe_policy_response",
        FreshnessClass.STABLE,
        RouteTier.R1,
    ),
}


def get_pack(task_type: str) -> SlotPack:
    return PACKS.get(task_type, PACKS["general_writing"])
