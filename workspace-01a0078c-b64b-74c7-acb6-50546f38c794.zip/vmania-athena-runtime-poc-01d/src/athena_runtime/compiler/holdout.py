import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from athena_runtime.compiler.compiler import RequirementCompiler
from athena_runtime.compiler.models import (
    AttachmentManifest,
    CompilerContext,
    DecisionKind,
)
from athena_runtime.compiler.provider import FakeUnderstandingProvider


@dataclass(frozen=True, slots=True)
class HoldoutMetrics:
    case_count: int
    task_accuracy: float
    clarify_precision: float
    clarify_recall: float
    route_accuracy: float
    hard_safety_failure: int
    missing_hard_execution_count: int
    capability_accuracy: float
    risk_category_accuracy: float
    cases: tuple[dict[str, Any], ...]

    def as_dict(self) -> dict[str, Any]:
        return {
            "case_count": self.case_count,
            "task_accuracy": self.task_accuracy,
            "clarify_precision": self.clarify_precision,
            "clarify_recall": self.clarify_recall,
            "route_accuracy": self.route_accuracy,
            "hard_safety_failure": self.hard_safety_failure,
            "missing_hard_execution_count": self.missing_hard_execution_count,
            "capability_accuracy": self.capability_accuracy,
            "risk_category_accuracy": self.risk_category_accuracy,
            "cases": list(self.cases),
        }


class HoldoutRunner:
    async def run(self, path: Path) -> HoldoutMetrics:
        cases = json.loads(path.read_text(encoding="utf-8"))["cases"]
        compiler = RequirementCompiler(FakeUnderstandingProvider())
        reports: list[dict[str, Any]] = []
        task_ok = route_ok = cap_ok = risk_ok = safety_fail = missing_exec = 0
        tp = fp = fn = 0
        for case in cases:
            result = await compiler.compile(
                case["prompt"],
                context=CompilerContext.model_validate(case.get("context", {})),
                attachment_manifest=tuple(
                    AttachmentManifest.model_validate(item) for item in case.get("attachments", ())
                ),
            )
            expected_kind = _expected_kind(case["expected"])
            expected_clarify = expected_kind is DecisionKind.CLARIFY
            predicted_clarify = result.decision.decision is DecisionKind.CLARIFY
            tp += int(expected_clarify and predicted_clarify)
            fp += int(not expected_clarify and predicted_clarify)
            fn += int(expected_clarify and not predicted_clarify)
            task_match = result.brief.task_type.value == case["expected_task_type"]
            route_match = result.route.tier.value == case["route"]
            capability_match = result.decision.required_capability == case["capability"]
            risk_match = result.brief.risk_category.value == case["risk"]
            safety_expected = expected_kind is DecisionKind.BLOCK
            hard_failure = safety_expected and result.decision.decision is not DecisionKind.BLOCK
            illegal_execution = bool(
                result.decision.missing_hard_slots
            ) and result.decision.decision not in {
                DecisionKind.CLARIFY,
                DecisionKind.BLOCK,
            }
            task_ok += int(task_match)
            route_ok += int(route_match)
            cap_ok += int(capability_match)
            risk_ok += int(risk_match)
            safety_fail += int(hard_failure)
            missing_exec += int(illegal_execution)
            reports.append(
                {
                    "id": case["id"],
                    "expected_decision": case["expected"],
                    "decision": result.decision.decision.value,
                    "reason_code": result.decision.reason_code,
                    "expected_route": case["route"],
                    "route": result.route.tier.value,
                    "expected_capability": case["capability"],
                    "capability": result.decision.required_capability,
                    "expected_risk": case["risk"],
                    "risk": result.brief.risk_category.value,
                    "missing_hard_slots": list(result.decision.missing_hard_slots),
                    "hard_safety_failure": hard_failure,
                }
            )
        total = len(cases)
        return HoldoutMetrics(
            case_count=total,
            task_accuracy=task_ok / total,
            clarify_precision=tp / (tp + fp) if tp + fp else 1.0,
            clarify_recall=tp / (tp + fn) if tp + fn else 1.0,
            route_accuracy=route_ok / total,
            hard_safety_failure=safety_fail,
            missing_hard_execution_count=missing_exec,
            capability_accuracy=cap_ok / total,
            risk_category_accuracy=risk_ok / total,
            cases=tuple(reports),
        )


def _expected_kind(value: str) -> DecisionKind:
    if value.startswith("CLARIFY"):
        return DecisionKind.CLARIFY
    if value.startswith("BLOCK"):
        return DecisionKind.BLOCK
    if value == "RESEARCH":
        return DecisionKind.RESEARCH
    if value == "COMPLEX_RUN":
        return DecisionKind.COMPLEX_RUN
    return DecisionKind.DIRECT
