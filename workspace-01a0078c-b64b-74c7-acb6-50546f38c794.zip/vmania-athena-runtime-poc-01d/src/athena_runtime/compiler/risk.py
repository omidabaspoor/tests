import re
from dataclasses import dataclass

from athena_runtime.compiler.models import RiskLevel


@dataclass(frozen=True, slots=True)
class RiskAssessment:
    level: RiskLevel
    category: str
    warning_policy: str | None = None
    block_reason: str | None = None


class RiskClassifier:
    def assess(self, text: str) -> RiskAssessment:
        value = text.casefold()
        if _minor_sexual(value):
            return RiskAssessment(RiskLevel.HIGH, "minor_sexual", block_reason="BLOCK_MINOR_SEXUAL")
        if re.search(r"کاربر|نفر", value) and re.search(r"قبلی|دیگر|بقیه|tenant", value):
            return RiskAssessment(RiskLevel.HIGH, "cross_tenant", block_reason="BLOCK_CROSS_TENANT")
        if re.search(r"evil\.|ارسال.*فایل|pixel\?data|exfil", value):
            return RiskAssessment(RiskLevel.HIGH, "exfiltration", block_reason="BLOCK_EXFILTRATION")
        if re.search(r"رشوه|جرم.*انگار|جعل", value) and re.search(r"عکس|تصویر|ادیت", value):
            return RiskAssessment(
                RiskLevel.HIGH,
                "deceptive_real_person",
                block_reason="BLOCK_DECEPTIVE_EDIT",
            )
        if re.search(r"sk-live-|api[_ -]?key|رمز|secret", value):
            return RiskAssessment(
                RiskLevel.MEDIUM, "secret_exposure", "secret-rotation-and-redaction"
            )
        if re.search(r"پزشک|پزشکی|سردرد|پوست(?:ی|\s|$)|بیماری|علائم|دارو", value):
            return RiskAssessment(RiskLevel.HIGH, "medical", "medical-safety-warning")
        if re.search(r"قانونی|حقوقی|قرارداد|وکیل|دادگاه", value):
            return RiskAssessment(RiskLevel.HIGH, "legal", "legal-safety-warning")
        if re.search(r"سرمایه.?گذاری|ضرر نکن|سود تضمینی|سهام", value):
            return RiskAssessment(RiskLevel.HIGH, "financial", "financial-safety-warning")
        if re.search(r"قیمت.*(دلار|ارز|طلا).*(الان|امروز)|همین الان.*دلار", value):
            return RiskAssessment(RiskLevel.MEDIUM, "medium")
        if re.search(r"ignore previous|system prompt|پرامپت سیستم|دستورهای قبلی", value):
            return RiskAssessment(RiskLevel.MEDIUM, "prompt_injection")
        if re.search(r"۱۰۰۰|1000", value) and re.search(r"تصویر|عکس", value):
            return RiskAssessment(RiskLevel.MEDIUM, "mass_cost_abuse", "quota-warning")
        if re.search(r"افسردگی|اضطراب", value) and re.search(r"یادت|ذخیره", value):
            return RiskAssessment(
                RiskLevel.HIGH,
                "sensitive_memory",
                block_reason="BLOCK_SENSITIVE_MEMORY",
            )
        return RiskAssessment(RiskLevel.LOW, "low")


def _minor_sexual(text: str) -> bool:
    sexual = re.search(r"سکسی|تحریک.?آمیز|برهنه|جنسی", text)
    age = re.search(r"(?:1[0-7]|[۰۱][۰-۷]|۱۵|۱۶|۱۷)\s*ساله", text)
    minor_word = re.search(r"دختر|پسر|کودک|نوجوان", text)
    return bool(sexual and (age or minor_word))
