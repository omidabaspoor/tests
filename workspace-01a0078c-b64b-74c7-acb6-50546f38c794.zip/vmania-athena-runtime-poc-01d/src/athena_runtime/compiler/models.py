import json
from enum import StrEnum
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator


class SlotStatus(StrEnum):
    EXPLICIT = "explicit"
    INFERRED = "inferred"
    DEFAULTED = "defaulted"
    UNKNOWN = "unknown"
    CONFLICTING = "conflicting"


class RequiredLevel(StrEnum):
    HARD = "hard"
    QUALITY = "quality"
    INFERABLE = "inferable"
    OPTIONAL = "optional"


class Slot(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")
    value: Any = None
    status: SlotStatus
    source: str | None = None
    confidence: float | None = Field(default=None, ge=0, le=1)
    required_level: RequiredLevel

    @field_validator("value", mode="before")
    @classmethod
    def json_safe_value(cls, value: Any) -> Any:
        if value is None:
            return None
        try:
            encoded = json.dumps(
                value,
                allow_nan=False,
                ensure_ascii=False,
                sort_keys=True,
                separators=(",", ":"),
            ).encode()
        except (TypeError, ValueError) as exc:
            raise ValueError("slot value must be finite JSON") from exc
        if len(encoded) > 4096:
            raise ValueError("slot value exceeds 4096 bytes")
        return _freeze_json(json.loads(encoded))

    @model_validator(mode="after")
    def validate_provenance(self) -> "Slot":
        if self.status is SlotStatus.EXPLICIT and self.source != "message":
            raise ValueError("explicit slots require message source")
        if self.status is SlotStatus.INFERRED and (not self.source or self.confidence is None):
            raise ValueError("inferred slots require source and confidence")
        if self.status is SlotStatus.DEFAULTED and not self.source:
            raise ValueError("defaults require policy source")
        return self


def _freeze_json(value: Any) -> Any:
    if isinstance(value, dict):
        return tuple((key, _freeze_json(item)) for key, item in sorted(value.items()))
    if isinstance(value, list):
        return tuple(_freeze_json(item) for item in value)
    return value


class SourceType(StrEnum):
    HISTORY = "history"
    MEMORY = "memory"
    PROJECT = "project"


class ContextFact(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")
    slot_name: str = Field(pattern=r"^[a-z][a-z0-9_]{0,63}$")
    value: Any
    source_type: SourceType
    source_id: str = Field(min_length=1, max_length=128)
    confidence: float = Field(ge=0, le=1)
    scope: str = Field(min_length=1, max_length=128)

    @field_validator("value", mode="before")
    @classmethod
    def fact_value_is_json(cls, value: Any) -> Any:
        return Slot.json_safe_value(value)


class CompilerContext(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")
    facts: tuple[ContextFact, ...] = ()
    recent_turn_count: int = Field(default=0, ge=0, le=8)


class AttachmentStatus(StrEnum):
    READY = "ready"
    QUARANTINED = "quarantined"
    REJECTED = "rejected"


class AttachmentManifest(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")
    attachment_id: str = Field(pattern=r"^[A-Za-z0-9_-]{1,128}$")
    media_type: str = Field(pattern=r"^[a-z0-9.+-]+/[a-z0-9.+-]+$")
    purpose: str = Field(pattern=r"^[a-z][a-z0-9_-]{0,63}$")
    status: AttachmentStatus


class FreshnessClass(StrEnum):
    STABLE = "stable"
    PERIODIC = "periodic"
    DAILY = "daily"
    LIVE = "live"


class RiskLevel(StrEnum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


class DecisionKind(StrEnum):
    DIRECT = "DIRECT"
    CLARIFY = "CLARIFY"
    RESEARCH = "RESEARCH"
    TOOL = "TOOL"
    COMPLEX_RUN = "COMPLEX_RUN"
    BLOCK = "BLOCK"


class RouteTier(StrEnum):
    R0 = "R0"
    R1 = "R1"
    R2 = "R2"
    R3 = "R3"
    R4 = "R4"


class NamedSlot(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")
    name: str
    slot: Slot


class Brief(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")
    version: str = "brief-0.1"
    task_type: Slot
    goal: Slot
    output_type: Slot
    audience: Slot
    subject: Slot
    platform: Slot
    tone: Slot
    constraints: Slot
    attachments: Slot
    freshness_requirement: Slot
    risk_level: Slot
    risk_category: Slot
    warning_policy: Slot
    success_criteria: Slot
    forbidden_items: Slot
    additional_slots: tuple[NamedSlot, ...] = ()


class Question(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")
    question_id: str
    slot_name: str
    text: str
    options: tuple[str, ...] = Field(min_length=2, max_length=4)
    recommended_option: str
    allow_other: bool = True
    allow_delegate: bool = True

    @model_validator(mode="after")
    def recommended_is_real(self) -> "Question":
        if self.recommended_option not in self.options:
            raise ValueError("recommended option must exist")
        return self


class ClarificationState(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")
    asked_question_ids: frozenset[str] = frozenset()
    question_count: int = Field(default=0, ge=0, le=3)
    delegated: bool = False


class PipelineDecision(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")
    decision: DecisionKind
    reason_code: str
    brief_version: str
    missing_hard_slots: tuple[str, ...]
    required_capability: str
    quality_floor: Literal["deterministic", "draft", "standard", "high"]


class RouteDecision(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")
    tier: RouteTier
    reason_code: str
    warning_policy: str | None = None


class CompileResult(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")
    brief: Brief
    question: Question | None
    decision: PipelineDecision
    route: RouteDecision
