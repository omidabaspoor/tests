# Persistence Hardening 01B.1

## Decision target

این تغییرات فقط Blockerهای static پیش از PostgreSQL CI را رفع می‌کنند. در محیط محلی PostgreSQL/Docker موجود نیست؛ بنابراین هیچ ادعای PASS برای RLS، Role، Migration اجرایی یا Concurrency مطرح نمی‌شود.

## F01 — Packaging

- Hatchling wheel selection صریح شد:

```toml
[tool.hatch.build.targets.wheel]
packages = ["src/athena_runtime"]
```

- `build` فقط به Development dependencyها اضافه شد؛ دلیل آن تست استاندارد PEP 517 wheel است و Runtime dependency نیست.
- Editable install، wheel build، نصب wheel در venv موقت و import smoke موفق شدند.

## F02/F03 — Role model و lifecycle

Role bootstrap از Alembic جدا و در `scripts/bootstrap_test_roles.sql` قرار گرفت:

- `athena_migration`: `NOLOGIN`, `NOSUPERUSER`, `NOBYPASSRLS` و مالک schema/table.
- `athena_app`: `NOLOGIN`, policy role و تنها دریافت‌کننده Grantهای Runtime.
- `athena_runtime_login`: `LOGIN`, `NOINHERIT`, `NOSUPERUSER`, `NOBYPASSRLS` و عضو `athena_app`.

Runtime Login مستقیماً هیچ Schema/Table privilege ندارد. Repository transaction با `SET LOCAL ROLE athena_app` کار می‌کند. `RESET ROLE` باید current user را به Runtime Login فاقد privilege برگرداند؛ P26 این invariant را روی PostgreSQL واقعی تست خواهد کرد.

Password ثابت وجود ندارد. psql با `\getenv` مقدار `ATHENA_RUNTIME_DB_PASSWORD` را از Environment می‌گیرد و `format(... %L)` آن را به‌صورت literal امن quote می‌کند. CI password تصادفی ephemeral تولید می‌کند.

دو DSN مستقل هستند:

- `ATHENA_MIGRATION_DATABASE_URL`: اتصال bootstrap/admin برای Alembic.
- `ATHENA_TEST_DATABASE_URL`: اتصال `athena_runtime_login` برای Integration.

Alembic فقط Migration DSN را می‌خواند. Integration engine فقط Runtime DSN را مصرف می‌کند.

## F04 — Historical migration صریح

Revision دیگر `metadata.create_all/drop_all` ندارد و Role ایجاد/حذف نمی‌کند. تمام شش table، column، FK، unique/check constraint، index، partial index، RLS policy، trigger، function، owner و grant با `op.create_table`, `op.create_index` و SQL صریح همان Revision تعریف شده‌اند. Down فقط function/trigger/index/tableهای همین Revision را حذف می‌کند؛ schema و roleهای bootstrap باقی می‌مانند.

P23 به‌صورت static این محدودیت را enforce می‌کند. Offline Up/Down SQL generation نیز موفق است، ولی جای اجرای PostgreSQL را نمی‌گیرد.

## F05/F06 — Event model

`run_events` اکنون دو ترتیب مستقل دارد:

- `sequence`: global sequence تمام eventهای Run؛ Repository زیر lock روی Run آن را تخصیص می‌دهد و Caller مقدار آزاد نمی‌دهد.
- `transition_version`: فقط برای `run.transitioned`؛ transitionهای Domain را از 1 مرتب می‌کند.

Schema همچنین `occurred_at TIMESTAMPTZ NOT NULL` را جدا از `created_at` زمان ingest دارد. Constraintها:

- unique `(run_id, sequence)`
- partial unique `(run_id, transition_version) WHERE transition_version IS NOT NULL`
- binding اجباری event type و transition version

`RunStore` تمام rowها را می‌خواند، ولی mapper فقط transitionها را بر اساس `transition_version` برای Rehydrate مصرف می‌کند. Live Action حذف یا خطا تلقی نمی‌شود و در log باقی می‌ماند. `occurred_at` اصلی به Domain Event برمی‌گردد. P24 بدون PostgreSQL mapping مخلوط transition/live/transition را اثبات می‌کند؛ P27 معادل Integration آن است.

## F07/F08 — Cost source

`runs.reserved_cost_microunits` حذف شد. تنها منبع reservation جدول `cost_reservations` است. Unique `(workspace_id, run_id)` یک Reservation برای هر Run در Scope PoC را enforce می‌کند. P28 ایجاد دوم را روی PostgreSQL رد می‌کند.

## F09 — Transition boundary و trigger

Runtime App Role دیگر `UPDATE` روی `runs` ندارد. مسیر transition فقط function زیر است:

```text
athena.transition_run(...)
```

Function:

- `SECURITY DEFINER` با owner برابر `athena_migration`
- `SET search_path = pg_catalog, athena` ثابت
- workspace را فقط از transaction-local GUC می‌گیرد
- run ID، workspace، expected version و from-state را در UPDATE بررسی می‌کند
- state/version، transition event و outbox را در یک statement/transaction می‌نویسد
- فقط `EXECUTE` به `athena_app` داده شده و `PUBLIC` revoke شده است

Threat model: function هیچ identifier یا SQL پویا نمی‌پذیرد، caller workspace مستقیم ندارد و owner نیز تحت FORCE RLS و policy workspace است. Runtime Login پس از RESET ROLE نه schema usage دارد و نه function/table grant.

Trigger مستقل تمام edgeهای `_TRANSITIONS` Domain را تکرار می‌کند. این duplication آگاهانه و defense-in-depth است؛ هر تغییر graph باید هم تست Domain و هم trigger review را طی کند. App direct update، چه مجاز چه نامجاز، به دلیل نبود Grant رد می‌شود؛ P29 این مرز را تست می‌کند. P30 invalid update توسط Migration Owner را برای اثبات خود trigger رد می‌کند.

## CI

Workflow تعریف‌شده برای Python 3.12/3.13 و PostgreSQL 17:

1. password ephemeral و دو DSN را می‌سازد.
2. role bootstrap را با admin اجرا می‌کند.
3. Alembic را با Migration DSN اجرا می‌کند.
4. Integration را با Runtime Login DSN اجرا می‌کند.
5. downgrade/upgrade را با Migration DSN تست می‌کند.
6. editable install، wheel build، wheel install/import، Ruff و compileall را اجرا می‌کند.

CI در GitHub Actions اجرا نشده و فقط **DEFINED_NOT_RUN** است.

## Risk remaining

- تمام 28 Integration test همچنان به PostgreSQL 17 واقعی نیاز دارند و Blocked هستند.
- SECURITY DEFINER، RLS/FORCE RLS، role membership/RESET ROLE و trigger SQL فقط پس از CI واقعی اثبات می‌شوند.
- Role/schema bootstrap lifecycle برای cluster مشترک Production نیازمند Infrastructure ownership و change management جداست.
- Event retention/partitioning، reconciliation worker، outbox dispatcher و Wallet/Ledger نهایی خارج Scope هستند.
