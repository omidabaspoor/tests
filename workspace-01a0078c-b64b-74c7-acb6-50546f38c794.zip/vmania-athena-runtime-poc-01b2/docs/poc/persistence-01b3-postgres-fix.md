# Persistence 01B.3 — PostgreSQL Race and Live Event Fix

## Decision

`READY_TO_RERUN_POSTGRES_CI`

GitHub Actions قبلی PostgreSQL را واقعاً اجرا کرد: 26 Integration PASS و P05/P27 FAIL شدند. این سند اصلاح همان دو failure را ثبت می‌کند. Initial Revision فقط در Job ephemeral ناموفق استفاده شده و در Production پایدار Apply نشده است؛ بنابراین همان Revision اصلاح شد.

## P05 — Consistent Run Snapshot

### علت

در isolation پیش‌فرض `READ COMMITTED`، `RunStore.load_in_transaction()` row مربوط به Run و Eventها را در دو statement می‌خواند. Commit هم‌زمان می‌توانست میان دو SELECT قرار گیرد و State جدید را با Event snapshot قدیمی یا برعکس ترکیب کند.

### اصلاح

`WorkspaceTransactionManager.transaction()` اکنون فقط enum زیر را می‌پذیرد:

- `READ COMMITTED`
- `REPEATABLE READ`

رشته آزاد پذیرفته نمی‌شود. Isolation با SQLAlchemy execution option پیش از BEGIN تنظیم می‌شود و SQL interpolation ندارد.

`RunTransitionService.transition()` فقط برای مسیر transition از `REPEATABLE READ` استفاده می‌کند. Load مربوط به Run و Eventها بنابراین یک snapshot پایدار دارد. Transactionهای عادی روی `READ COMMITTED` باقی مانده‌اند.

`athena.transition_run` همچنان expected version/state/workspace را مرز نهایی concurrency می‌داند. SQLSTATE `40001` فقط به `OptimisticLockError` تبدیل می‌شود و سایر DB errorها بدون پنهان‌سازی propagate می‌شوند. Retry کور اضافه نشده است.

P05 اکنون سه دور مستقل از 20 transition هم‌زمان را تعریف می‌کند: در هر دور دقیقاً یک success و 19 rejection کنترل‌شده انتظار می‌رود؛ `ValueError` مربوط به snapshot ناسازگار پذیرفته نمی‌شود.

## P27 — Controlled Live Event Function

Function جدید Initial Revision:

```text
athena.append_run_event(
  run_id,
  event_type,
  visibility,
  payload,
  occurred_at
) -> (event_id, event_sequence)
```

Invariantها:

- `SECURITY DEFINER`
- owner برابر `athena_migration`
- `SET search_path = pg_catalog, athena`
- workspace فقط از transaction-local `app.workspace_id`
- Run باید در همان workspace visible باشد و داخل Function `FOR UPDATE` lock می‌شود
- global sequence زیر همان lock تخصیص می‌یابد
- `run.transitioned` رد می‌شود
- live event همیشه `transition_version=NULL` دارد
- visibility فقط `internal|user|audit`
- payload و occurred_at اجباری‌اند
- payload size توسط Table Check Constraint enforce می‌شود
- event ID و sequence برگردانده می‌شوند
- PUBLIC execute revoke و فقط `athena_app` مجاز به execute است

`EventStore.append_live_event()` فقط این Function را فراخوانی می‌کند و دیگر `SELECT ... FOR UPDATE` یا `INSERT run_events` مستقیم ندارد.

## Final permissions

| Object | athena_app permission |
|---|---|
| `athena.runs` | `SELECT, INSERT`؛ بدون `UPDATE/DELETE` |
| `athena.run_events` | فقط `SELECT`؛ بدون `INSERT/UPDATE/DELETE` |
| `athena.transition_run(...)` | `EXECUTE` |
| `athena.append_run_event(...)` | `EXECUTE` |
| `athena.idempotency_records` | `SELECT, INSERT, UPDATE, DELETE` |
| `athena.approvals` | `SELECT, INSERT, UPDATE` |
| `athena.outbox_events` | `SELECT, INSERT, UPDATE` |
| `athena.cost_reservations` | `SELECT, INSERT, UPDATE` |

State transition فقط از `transition_run` و live event فقط از `append_run_event` عبور می‌کند. RLS و FORCE RLS بدون تغییر حفظ شده‌اند.

## Migration discipline

`CREATE FUNCTION athena.append_run_event(...)` در یک `op.execute()` مستقل قرار دارد. Function، Trigger و DDLهای دیگر همچنان هرکدام فقط یک فرمان سطح بالای SQL در هر `op.execute()` دارند. Owner/REVOKE/GRANT نیز جدا هستند. Downgrade Function جدید را پیش از Tableها حذف می‌کند.

`alembic.ini` اکنون `path_separator = os` دارد تا warning Alembic حذف شود.

## Tests added/changed

- P05: سه دور concurrency بیست‌تایی با rejection کنترل‌شده.
- P27: transition/live/transition از Function و حفظ global/transition sequence و occurred_at.
- P31: isolation فقط enum allowlisted را می‌پذیرد.
- P32: App Role روی `run_events` فقط SELECT دارد و INSERT مستقیم رد می‌شود.
- P33: workspace دیگر نمی‌تواند برای Run قربانی live event بسازد و event type انتقال از live function رد می‌شود.
- Migration statement-boundary test اکنون شش CREATE FUNCTION/TRIGGER مستقل را بررسی می‌کند.

## Remaining risk

محیط محلی PostgreSQL ندارد. Function جدید، isolation behavior، privileges و tests P05/P27/P32/P33 باید در rerun واقعی GitHub Actions اثبات شوند. CI در این مرحله اجرا نشده است.
