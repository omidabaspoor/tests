# تصمیم‌ها و Trade-offها

## تصمیم‌ها

1. **کتابخانه‌ها محدود ماندند**: تنها Dependency اجرایی Pydantic 2 است. pytest، pytest-asyncio و Ruff فقط Development dependency هستند. pytest-asyncio به دلیل تست مستقیم cancellation، timeout و raceهای async لازم است. Hatchling فقط build backend استاندارد بسته‌بندی `src` است و در Runtime وارد نمی‌شود. Hypothesis اضافه نشد چون سناریوهای قطعی برای Scope این PoC کافی بودند.
2. **ساختار پیشنهادی حفظ شد** و فقط `authorization.py` اضافه شد تا Trust boundary مجوز از Tool Broker و Handler جدا و قابل تست باشد.
3. **Operation registry ثابت است**: فقط `allowed_canary` و `forbidden_canary` قابل ثبت‌اند. Dynamic import، plugin discovery و registry خارجی وجود ندارد.
4. **Policy ناشناخته/ناقص کل Permission را خالی می‌کند**. Unknown operation حتی اگر در بخشی از مجموعه‌ها ظاهر شود، Fail-closed است.
5. **Approval پس از Scope و Authorization بررسی می‌شود**؛ پس Approval هرگز Scope را افزایش نمی‌دهد. Digest با JSON canonical و SHA-256 محاسبه می‌شود؛ این Digest امضا یا primitive احراز اصالت نیست.
6. **Idempotency failure مبهم Replay می‌شود**: اگر Handler Exception بدهد ممکن است Side Effect جزئی رخ داده باشد؛ Outcome `FAILED` ذخیره می‌شود و درخواست تکراری Handler را کور اجرا نمی‌کند. Failureهای قبل از Reservation/Side Effect قابل Retry هستند.
7. **Sequence داخل Aggregate است**: برای PoC حافظه‌ای کافی است؛ تخصیص Sequence توزیع‌شده عمداً حل نشده است.
8. **Plan arguments** فقط JSON تا 4096 بایت است و کلیدهای حامل Prompt/Code اجرایی رد می‌شوند. این یک Schema boundary محدود است، نه تحلیل semantic کامل محتوا.

## Trade-offها

- Storeهای حافظه‌ای crash-safe یا multi-process نیستند؛ هدف فقط اثبات رفتار Domain و atomicity داخل یک event loop است.
- Outcome در همان Idempotency record نگهداری می‌شود؛ audit log پایدار در این مرحله وجود ندارد.
- `asyncio.Lock` isolation داخل Process را فراهم می‌کند، نه هماهنگی بین Processها.
- Verifier صرفاً Protocol است. Fake Verifier تستی نشان می‌دهد Broker آن را قبل از مجوز فراخوانی می‌کند، ولی Signature واقعی عمداً اختراع نشده است.
- Marker handler از فایل کوچک synchronous در Temp Directory استفاده می‌کند؛ هیچ network یا filesystem واقعی محصول را لمس نمی‌کند.

## عمداً ساخته‌نشده

API، FastAPI، Database/PostgreSQL، Redis، SSE، Worker، Model/Planner واقعی، Memory، UI، Tool واقعی، network call، secret management، crypto/signature، durable queue، telemetry و plugin system.

## ریسک‌های باقی‌مانده

- پیش از Production باید Verifier رمزنگاری‌شده استاندارد، persistent event store و idempotency durable با recovery state machine طراحی شوند.
- Crash دقیقاً هنگام Side Effect همچنان outcome مبهم تولید می‌کند؛ اجرای دوباره باید فقط با reconciliation اختصاصی Tool انجام شود.
- Budget در Capsule validate می‌شود، اما ledger مصرف و reservation هزینه خارج از Scope این مرحله است.
- Clock فعلاً local UTC system clock است؛ سیاست clock skew و trusted time نیازمند طراحی Production است.
- اجرای CI دقیق روی Python 3.12 لازم است؛ محیط ساخت حاضر Python 3.13 داشت، هرچند `requires-python >=3.12` و Ruff target روی 3.12 تنظیم شد.
