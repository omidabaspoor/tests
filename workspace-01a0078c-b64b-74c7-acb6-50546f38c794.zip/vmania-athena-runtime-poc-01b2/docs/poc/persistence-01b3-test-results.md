# Persistence 01B.3 — Test Results

## Local environment

PostgreSQL و Docker محلی در دسترس نبودند. Integration محلی اجرا یا PASS اعلام نشد.

## Unit, static and packaging

```text
pip install -e '.[dev]'
PASS

pytest -q -m "not integration"
53 passed, 30 deselected

ruff check .
All checks passed!

python -m compileall -q src tests alembic
PASS

python -m build --wheel
PASS

install wheel in temporary venv + import smoke
PASS
```

52 تست قبلی Unit/Security حفظ شدند و P31 یک تست Unit جدید برای isolation allowlist است.

## Migration offline

```text
ATHENA_MIGRATION_DATABASE_URL=<nonconnecting-placeholder> alembic upgrade head --sql
PASS

ATHENA_MIGRATION_DATABASE_URL=<nonconnecting-placeholder> \
  alembic downgrade 20260816_01b:base --sql
PASS
```

Offline SQL generation اجرای PostgreSQL یا privilege/function semantics را اثبات نمی‌کند.

## Integration status

- Integration تعریف‌شده: 30
- Integration محلی اجراشده: 0
- وضعیت محلی: `BLOCKED_NOT_RUN`
- GitHub Actions قبلی: 26 PASS، 2 FAIL در P05/P27
- GitHub Actions پس از اصلاح 01B.3: `NOT_RERUN_YET`

سناریوهای جدید/تقویت‌شده که منتظر CI هستند:

- P05: سه دور 20 transition هم‌زمان؛ یک winner در هر دور و بدون inconsistent-snapshot ValueError
- P27: transition/live/transition و global sequence 1,2,3
- P32: SELECT-only permission و رد INSERT مستقیم روی `run_events`
- P33: cross-workspace و reserved transition event type rejection

## Final status

- P05 fix: PASS_STATIC/UNIT، PostgreSQL verification pending
- P27 fix: PASS_STATIC/UNIT، PostgreSQL verification pending
- Direct `UPDATE runs` grant: وجود ندارد
- Direct `INSERT run_events` grant: وجود ندارد
- RLS/FORCE RLS: حفظ شده، rerun pending
- CI: فقط آماده اجرا؛ در این Workspace اجرا نشده است
