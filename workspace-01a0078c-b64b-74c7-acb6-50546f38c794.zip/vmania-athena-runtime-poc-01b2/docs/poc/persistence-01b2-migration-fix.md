# Persistence 01B.2 — asyncpg Migration Fix

## Decision

`READY_TO_RERUN_POSTGRES_CI`

Revision `20260816_01b` هنوز در هیچ محیط تأییدشده‌ای با موفقیت Apply نشده بود؛ بنابراین همان Initial Revision اصلاح شد و Revision جدیدی ساخته نشد.

## Root cause

یک `op.execute()` شامل پنج فرمان مستقل سطح بالای PostgreSQL بود. asyncpg هر `op.execute()` را به‌صورت یک prepared statement ارسال می‌کند و چند فرمان سطح بالا را با خطای زیر رد می‌کند:

```text
cannot insert multiple commands into a prepared statement
```

Semicolonهای داخل بدنه dollar-quoted توابع PL/pgSQL مشکل نیستند؛ هر بدنه بخشی از یک فرمان `CREATE FUNCTION` است.

## Split دقیق

بلوک واحد قبلی به پنج `op.execute()` مستقل و با همین ترتیب تقسیم شد:

1. `CREATE FUNCTION athena.enforce_run_state_transition()`
2. `CREATE TRIGGER trg_run_state_transition`
3. `CREATE FUNCTION athena.enforce_run_event_sequence()`
4. `CREATE TRIGGER trg_run_event_sequence`
5. `CREATE FUNCTION athena.transition_run(...)`

هیچ Function و Trigger در یک call مشترک باقی نمانده است. بدنه Functionها، `SECURITY DEFINER`، `SET search_path = pg_catalog, athena`، owner، REVOKE و GRANTها تغییر معنایی نکردند. Downgrade همچنان Triggerها و Functionها را با `op.execute()`های جدا حذف می‌کند.

## Static verification

`tests/unit/test_migration_statement_boundaries.py` با AST تمام callهای `op.execute()` Revision را پیدا می‌کند. SQL dollar-quoted function body پیش از شمارش mask می‌شود؛ بنابراین semicolonهای PL/pgSQL به‌اشتباه statement سطح بالا شمرده نمی‌شوند.

دو invariant تست می‌شوند:

- هر `op.execute()` دقیقاً یک فرمان SQL سطح بالا دارد.
- پنج فرمان Function/Trigger دقیقاً در پنج call مستقل و با ترتیب مورد انتظار وجود دارند.

## Local results

```text
pip install -e '.[dev]'
PASS

pytest -q -m "not integration"
52 passed, 28 deselected

python -m build --wheel
PASS

install wheel in temporary venv + import smoke
PASS

ruff check .
All checks passed!

python -m compileall -q src tests alembic
PASS

ATHENA_MIGRATION_DATABASE_URL=<nonconnecting-placeholder> alembic upgrade head --sql
PASS — 339 lines generated

ATHENA_MIGRATION_DATABASE_URL=<nonconnecting-placeholder> \
  alembic downgrade 20260816_01b:base --sql
PASS — 44 lines generated
```

در حالت offline، Alembic برای downgrade به range صریح `<fromrev>:<torev>` نیاز دارد؛ به همین دلیل معادل معتبر `20260816_01b:base` استفاده شد. `alembic downgrade base --sql` بدون from revision با پیام خود Alembic رد می‌شود.

## Integration and CI

PostgreSQL محلی در این محیط موجود نیست. هیچ Integration test اجرا یا PASS اعلام نشد. 28 Integration test همچنان برای PostgreSQL 17 تعریف‌شده و `BLOCKED_NOT_RUN` هستند.

Workflow موجود تغییر نکرد، چون رفع خطا فقط به split کردن DDL در Migration مربوط بود. GitHub Actions هنوز اجرا نشده و Workspace جدید فقط برای rerun همان CI آماده شده است.
