# Athena Runtime Hardening 01A.1

## Scope

این مرحله فقط invariantهای هسته Domain و امنیت Runtime را سخت‌سازی می‌کند. API، Database، Network، Worker، Model، Memory و Tool واقعی اضافه نشده‌اند. Dependency اجرایی جدیدی نیز اضافه نشده است.

## اصلاح‌ها

### Run aggregate و Clock

- State و Event storage خصوصی شدند؛ `state` فقط property خواندنی و `events` یک tuple snapshot است.
- Event storage نیز tuple است تا حتی reference داخلی Collection قابلیت append نداشته باشد.
- تنها `transition()` State/Event را هم‌زمان تغییر می‌دهد.
- `Clock` protocol، `SystemClock` و `FakeClock` اضافه شدند. Run، Policy و Approval از Clock تزریق‌شده استفاده می‌کنند.

### Plan proposal و validated plan

- `PlanProposal` و `PlanStepProposal` فقط ورودی غیرقابل‌اعتماد و محدودیت ساختاری JSON را نمایش می‌دهند.
- `PlanValidator` از Policy Engine قابل‌اعتماد Permission مؤثر را می‌گیرد و max steps، شناسه تکراری، dependency ناشناخته، cycle، operation شناخته‌شده، effective permission، schema اختصاصی Arguments و مجموع cost microunits را بررسی می‌کند.
- `ValidatedPlan` فقط با seal خصوصی Module توسط Validator ساخته می‌شود و Stepها snapshotهای immutable با canonical JSON bytes هستند.
- `PlanExecutionBoundary` Policy را دوباره محاسبه و integrity hash وابسته به Capsule، Policy و تمام Stepها را بررسی می‌کند؛ بنابراین constructor جعلی یا تغییر Plan در مرز اجرا رد می‌شود.
- جلوگیری مطلق از دست‌کاری با reflection/`object.__setattr__` در Python یک security boundary کامل نیست. به همین دلیل seal به‌تنهایی معیار اعتماد نیست و integrity/policy hash در مرز اجرا دوباره بررسی می‌شود. Caller هم‌فرآیند که عمداً private module state را می‌شکند خارج از threat model این PoC است.

### Tool request snapshot و schema اختصاصی

- `ToolRequest` frozen/slots است. Arguments با JSON استاندارد canonical، `allow_nan=False`، سقف 4096 بایت و round-trip snapshot می‌شوند.
- NaN، Infinity، object غیر JSON و key غیر string رد می‌شوند. Digest از canonical bytes ساخته می‌شود.
- Authorizer فقط `AuthorizationRequest` frozen شامل run/workspace/tool call/operation/digest/policy version را دریافت می‌کند و هیچ Dict اجرایی نمی‌بیند.
- Broker پیش از Authorization مدل ورودی ثابت Tool را validate می‌کند و بعد از ALLOW یک copy جدید از JSON validate‌شده به Handler می‌دهد.
- Registry همچنان فقط دو Canary ثابت دارد و هر دو اجباراً از `CanaryInput(extra="forbid", strict=True)` استفاده می‌کنند. Generic key blacklist حذف شد؛ چنین blacklistی مرز امنیت معتبر نیست.

### Idempotency و Cancellation

- Record اتمیک fingerprint شامل `args_digest` و `policy_version` را نگه می‌دارد.
- key یکسان و fingerprint یکسان Replay می‌شود؛ fingerprint متفاوت outcome ساختاریافته `IDEMPOTENCY_CONFLICT` می‌دهد و Handler اجرا نمی‌شود.
- timeout و Exception معمولی Authorizer برابر DENY هستند، ولی external `CancelledError` دوباره raise می‌شود.
- هیچ Thread ساخته نشده است.

### Money

- `budget: float` با `max_cost_microunits: int` جایگزین شد.
- `estimated_cost: float` با `estimated_cost_microunits: int` جایگزین شد.
- هر دو strict integer و نامنفی‌اند؛ مجموع cost Plan نمی‌تواند از Capsule بیشتر شود.

## Diff summary نسبت به بسته 01A

- تغییر: `approvals.py`, `authorization.py`, `capsule.py`, `errors.py`, `idempotency.py`, `plans.py`, `policy.py`, `runs.py`, `tools.py`
- جدید: `clocks.py`, `json_snapshot.py`
- Regression: `tests/security/test_hardening_h01_h16.py`
- به‌روزرسانی تست‌های S و Unit برای نام‌های microunits، Plan boundary، Tool Definition و fingerprint
- جدید: `.github/workflows/ci.yml` با matrix تعریف‌شده 3.12 و 3.13؛ این CI در این محیط اجرا نشده و هیچ سرویس خارجی فعال نشده است.

## TDD evidence

ابتدا تست‌های H01–H16 اضافه شدند. اجرای اولیه پیش از Implementation در collection با `ModuleNotFoundError: athena_runtime.clocks` شکست خورد. خلاصه در `docs/poc/tdd-hardening-initial-fail.log` ثبت شده است. پس از حداقل تغییرها Suite کامل اجرا شد.

## Risk remaining

- Verifier رمزنگاری‌شده، durable idempotency، crash reconciliation و persistent event store همچنان خارج Scope هستند.
- Authorizer جزء داخلی و بدون plugin است. اگر implementation داخلی cancellation ناشی از `asyncio.wait_for` را عمداً suppress کند، timeout ممکن است دیر برگردد؛ این PoC sandbox/process isolation برای authorizer ندارد.
- Python privacy مطلق نیست؛ boundary checkهای Plan و snapshot/digest check در Broker ریسک mutation عادی و accidental را می‌بندند، نه hostile code دارای دسترسی کامل به memory/reflection.
- Clock از wall clock استفاده می‌کند و trusted time/clock skew Production هنوز طراحی نشده است.
- static type checker اضافه نشد: Dependency جدید برای Scope فعلی ضروری نبود. Type hints، Ruff، compileall و import smoke اجرا می‌شوند، اما جای static type proof کامل را نمی‌گیرند.
- Python 3.12 محلی موجود نبود؛ matrix CI ساخته شد اما اجراشده اعلام نمی‌شود.
