# Persistence 01B — Decisions, Migration Notes, Risks

## Decisions

1. **PostgreSQL-only**: از `JSONB`, PostgreSQL UUID, RLS، advisory transaction lock، `ON CONFLICT` و `SKIP LOCKED` استفاده شده است. SQLite fallback وجود ندارد.
2. **Dependencyهای اجرایی**: SQLAlchemy 2 async برای repository/transaction abstraction، asyncpg برای driver PostgreSQL و Alembic برای migration up/down اضافه شدند. Dependency اجرایی دیگری اضافه نشد.
3. **Core tables only**: فقط `runs`, `run_events`, `idempotency_records`, `approvals`, `outbox_events`, `cost_reservations` ساخته شدند.
4. **RLS defense in depth**: Policy پایگاه داده و predicate صریح Repository هم‌زمان اعمال می‌شوند. Authorization برنامه قبل از ساخت `WorkspaceContext` است؛ RLS جایگزین Authorization principal-to-workspace نیست.
5. **App role cannot mutate history**: `athena_app` روی `run_events` فقط SELECT/INSERT دارد؛ UPDATE/DELETE/TRUNCATE داده نشده است.
6. **Sequence enforcement**: Repository run row را lock و next sequence را بررسی می‌کند. Trigger با advisory xact lock همان invariant را برای insert مستقیم App Role نیز enforce می‌کند.
7. **Optimistic run version**: State transition با `UPDATE ... WHERE version=:expected` است. Event و Outbox فقط پس از یک update موفق و در همان Transaction درج می‌شوند.
8. **Expired idempotency lease is ambiguous**: Record به `unknown_reconciliation_required` می‌رود و خودکار delete/re-reserve نمی‌شود.
9. **Outbox delivery**: Claim lease از تحویل هم‌زمان جلوگیری می‌کند، اما exactly-once transport ادعا نمی‌شود. Consumer آینده باید `outbox_events.id` را dedupe کند.
10. **Cost semantics**: `settle_to` مقدار کل settled را می‌گیرد، نه delta؛ این انتخاب retry را idempotent می‌کند.
11. **No static type checker dependency**: Type hints، Ruff، compileall و import smoke استفاده می‌شوند. Type checker جدید برای این PoC ضروری تشخیص داده نشد تا dependency غیرضروری اضافه نشود.

## Diff Summary

- Runtime Domain: `Run.rehydrate` و durable reconciliation status اضافه شد.
- Persistence package جدید: context، schema، limits، errors و repositoryها.
- Alembic environment و revision اولیه Persistence اضافه شد.
- PostgreSQL 17 Compose و CI service definition اضافه شد.
- 4 unit contract test و 22 integration scenario P01–P22 اضافه شد.
- README و pyproject برای dependencyها و فرمان‌های PostgreSQL به‌روزرسانی شدند.

## Migration Notes

- Revision: `20260816_01b`
- PostgreSQL target: 17
- Up:
  1. Roleهای منطقی بدون Login/Bypass ساخته یا harden می‌شوند.
  2. شش جدول، FK/index/check/uniqueها ساخته می‌شوند.
  3. مالکیت به Migration Role منتقل می‌شود.
  4. RLS و FORCE RLS و policy workspace ساخته می‌شوند.
  5. triggerهای event sequence و terminal state ساخته می‌شوند.
  6. least-privilege grantهای App Role اعمال می‌شوند.
- Down: trigger/functionها، جدول‌ها، schema grant و Roleهای منطقی حذف می‌شوند.
- Password یا connection string واقعی در Repository نیست. `ATHENA_MIGRATION_DATABASE_URL` و `ATHENA_TEST_DATABASE_URL` از Environment خوانده می‌شوند؛ Role bootstrap جداست.
- `compose.yaml` نیازمند `ATHENA_POSTGRES_PASSWORD` محلی است و هیچ مقدار پیش‌فرض ذخیره‌شده ندارد.
- Offline SQL generation برای Up و Down در محیط حاضر موفق بود؛ اجرای واقعی Transactional DDL بدون PostgreSQL ادعا نشده است.

## CI

`.github/workflows/ci.yml` برای Python 3.12 و 3.13 و PostgreSQL 17 service تعریف شده است و unit، migration، integration، downgrade/upgrade، Ruff و compileall را اجرا می‌کند. این CI در این محیط **اجرا نشده** است.

## Risk Remaining

- Docker، PostgreSQL server و `psql` در محیط حاضر موجود نبودند؛ بنابراین RLS، role grants، concurrency، transaction rollback و migration واقعی هنوز `BLOCKED_NOT_RUN` هستند.
- Role provisioning در Production به bootstrap/admin process جدا نیاز دارد. Roleهای Migration/App در این PoC `NOLOGIN` هستند.
- App SQL session از نظر فنی می‌تواند GUC سفارشی را تنظیم کند؛ جلوگیری از انتخاب Workspace دیگر بر عهده factory/authorization برنامه و محدود کردن raw DB access است. User/Auth کامل خارج Scope است.
- Durable idempotency هنوز reconciliation worker ندارد؛ Record مبهم فقط متوقف و علامت‌گذاری می‌شود.
- Outbox dispatcher، publish acknowledgement، dead-letter policy و retention ساخته نشده‌اند.
- Cost reservation Wallet، double-entry Ledger یا Billing نیست.
- Partitioning/retention، backup/restore، break-glass role، observability و schema performance benchmark خارج Scope هستند.
- Migration role creation/drop به دسترسی bootstrap کافی و Database/cluster اختصاصی نیاز دارد؛ در محیط shared باید lifecycle Roleها از migration جدول جدا شود.
