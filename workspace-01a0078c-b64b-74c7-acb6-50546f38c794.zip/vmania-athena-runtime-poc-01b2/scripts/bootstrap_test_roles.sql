\set ON_ERROR_STOP on

-- Local/CI bootstrap only. Run with an administrative psql connection.
-- The runtime password is read from ATHENA_RUNTIME_DB_PASSWORD and safely quoted with format(%L).
\getenv runtime_password ATHENA_RUNTIME_DB_PASSWORD
SELECT length(:'runtime_password') > 0 AS runtime_password_present \gset
\if :runtime_password_present
\else
  \echo 'ATHENA_RUNTIME_DB_PASSWORD must be set in the environment'
  \quit 1
\endif

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'athena_migration') THEN
    CREATE ROLE athena_migration NOLOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE
      NOINHERIT NOBYPASSRLS;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'athena_app') THEN
    CREATE ROLE athena_app NOLOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE
      NOINHERIT NOBYPASSRLS;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'athena_runtime_login') THEN
    CREATE ROLE athena_runtime_login LOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE
      NOINHERIT NOBYPASSRLS;
  END IF;
END $$;

ALTER ROLE athena_migration NOLOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOINHERIT NOBYPASSRLS;
ALTER ROLE athena_app NOLOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOINHERIT NOBYPASSRLS;
ALTER ROLE athena_runtime_login LOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOINHERIT NOBYPASSRLS;
GRANT athena_app TO athena_runtime_login;

SELECT format('ALTER ROLE athena_runtime_login PASSWORD %L', :'runtime_password') \gexec

CREATE SCHEMA IF NOT EXISTS athena AUTHORIZATION athena_migration;
ALTER SCHEMA athena OWNER TO athena_migration;
REVOKE ALL ON SCHEMA athena FROM PUBLIC;
REVOKE ALL ON SCHEMA athena FROM athena_runtime_login;
GRANT USAGE ON SCHEMA athena TO athena_app;
