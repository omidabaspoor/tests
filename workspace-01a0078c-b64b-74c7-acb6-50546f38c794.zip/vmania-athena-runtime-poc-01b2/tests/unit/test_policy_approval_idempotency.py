from datetime import UTC, datetime, timedelta

import pytest

from athena_runtime.approvals import Approval, ApprovalStore, args_digest
from athena_runtime.capsule import IntentCapsule
from athena_runtime.idempotency import (
    IdempotencyKey,
    InMemoryIdempotencyStore,
    RequestFingerprint,
    ReservationState,
)
from athena_runtime.policy import PolicyEngine


def cap(**kw: object) -> IntentCapsule:
    d = dict(
        run_id="r",
        workspace_id="w",
        goal="g",
        requested_operations={"allowed_canary"},
        task_allowed_operations={"allowed_canary"},
        server_maximum_operations={"allowed_canary"},
        plan_scope_operations={"allowed_canary"},
        max_cost_microunits=1,
        max_steps=1,
        expires_at=datetime.now(UTC) + timedelta(minutes=1),
        nonce="n",
        policy_version="v1",
    )
    d.update(kw)
    return IntentCapsule(**d)


def test_policy_is_strict_intersection_and_fail_closed() -> None:
    engine = PolicyEngine({"v1"}, {"allowed_canary", "forbidden_canary"})
    assert engine.effective_permissions(cap()) == frozenset({"allowed_canary"})
    assert not engine.effective_permissions(cap(server_maximum_operations=set()))
    assert not engine.effective_permissions(cap(requested_operations={"unknown"}))
    assert not engine.effective_permissions(cap(policy_version="missing"))
    assert not engine.effective_permissions(
        cap(expires_at=datetime.now(UTC) - timedelta(seconds=1))
    )


@pytest.mark.asyncio
async def test_approval_is_bound_expiring_and_single_use() -> None:
    store = ApprovalStore()
    digest = args_digest({"x": 1})
    approval = Approval(
        run_id="r",
        tool_call_id="c",
        operation="allowed_canary",
        args_digest=digest,
        expires_at=datetime.now(UTC) + timedelta(minutes=1),
        decision="once",
    )
    await store.add(approval)
    assert not await store.consume("other", "c", "allowed_canary", digest)
    assert not await store.consume("r", "c", "allowed_canary", args_digest({"x": 2}))
    assert await store.consume("r", "c", "allowed_canary", digest)
    assert not await store.consume("r", "c", "allowed_canary", digest)


@pytest.mark.asyncio
async def test_idempotency_reservation_is_atomic_and_replays() -> None:
    store = InMemoryIdempotencyStore()
    key = IdempotencyKey("w", "r", "c", "op")
    fingerprint = RequestFingerprint("digest", "v1")
    first = await store.reserve(key, fingerprint)
    second = await store.reserve(key, fingerprint)
    assert first.state is ReservationState.RESERVED
    assert second.state is ReservationState.IN_PROGRESS
    await store.complete(key, {"ok": True})
    replay = await store.reserve(key, fingerprint)
    assert replay.state is ReservationState.REPLAY and replay.outcome == {"ok": True}
