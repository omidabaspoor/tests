import asyncio
import os
from datetime import UTC, datetime, timedelta
from uuid import UUID, uuid4

import pytest
import pytest_asyncio
from alembic.config import Config
from sqlalchemy import delete, func, insert, select, text, update
from sqlalchemy.exc import DBAPIError
from sqlalchemy.ext.asyncio import AsyncEngine, create_async_engine

from alembic import command
from athena_runtime.approvals import Approval, args_digest
from athena_runtime.errors import InvalidTransition
from athena_runtime.idempotency import IdempotencyKey, RequestFingerprint, ReservationState
from athena_runtime.persistence.context import WorkspaceContext, WorkspaceTransactionManager
from athena_runtime.persistence.errors import CostReservationError, OptimisticLockError
from athena_runtime.persistence.limits import MAX_PAYLOAD_BYTES
from athena_runtime.persistence.repositories import (
    CostReservationStore,
    EventStore,
    OutboxStore,
    PostgresApprovalStore,
    PostgresIdempotencyStore,
    RunStore,
    RunTransitionService,
)
from athena_runtime.persistence.schema import outbox_events, run_events, runs
from athena_runtime.runs import RunState
from athena_runtime.tools import BrokerOutcome, BrokerOutcomeStatus

pytestmark = pytest.mark.integration
MIGRATION_DATABASE_URL = os.getenv("ATHENA_MIGRATION_DATABASE_URL")
RUNTIME_DATABASE_URL = os.getenv("ATHENA_TEST_DATABASE_URL")


@pytest.fixture(scope="session", autouse=True)
def migrated_database() -> None:
    if not MIGRATION_DATABASE_URL or not RUNTIME_DATABASE_URL:
        pytest.skip("BLOCKED_NOT_RUN: PostgreSQL test URL is unavailable")
    config = Config("alembic.ini")
    config.set_main_option("sqlalchemy.url", MIGRATION_DATABASE_URL)
    command.downgrade(config, "base")
    command.upgrade(config, "head")


@pytest_asyncio.fixture
async def engine() -> AsyncEngine:
    assert RUNTIME_DATABASE_URL is not None
    value = create_async_engine(RUNTIME_DATABASE_URL, pool_size=10, max_overflow=20)
    yield value
    await value.dispose()


def context(workspace_id: UUID | None = None) -> WorkspaceContext:
    return WorkspaceContext(workspace_id or uuid4(), "integration-principal")


def manager(engine: AsyncEngine) -> WorkspaceTransactionManager:
    return WorkspaceTransactionManager(engine, app_role="athena_app")


async def create_run(engine: AsyncEngine, ctx: WorkspaceContext) -> UUID:
    return await RunStore(manager(engine)).create(
        ctx,
        max_cost_microunits=1_000,
        max_steps=10,
        deadline_at=datetime.now(UTC) + timedelta(hours=1),
    )


@pytest.mark.asyncio
async def test_p01_workspaces_cannot_read_each_others_runs(engine: AsyncEngine) -> None:
    first, second = context(), context()
    run_id = await create_run(engine, first)
    assert await RunStore(manager(engine)).load(second, run_id) is None


@pytest.mark.asyncio
async def test_p02_workspaces_cannot_read_each_others_events(engine: AsyncEngine) -> None:
    first, second = context(), context()
    run_id = await create_run(engine, first)
    await RunTransitionService(manager(engine)).transition(
        first, run_id, expected_version=0, to_state=RunState.VALIDATING
    )
    async with manager(engine).transaction(second) as connection:
        count = await connection.scalar(select(func.count()).select_from(run_events))
    assert count == 0


@pytest.mark.asyncio
async def test_p03_app_role_without_context_sees_nothing(engine: AsyncEngine) -> None:
    ctx = context()
    await create_run(engine, ctx)
    async with manager(engine).unscoped_transaction() as connection:
        count = await connection.scalar(select(func.count()).select_from(runs))
    assert count == 0


@pytest.mark.asyncio
async def test_p04_app_role_cannot_bypass_rls(engine: AsyncEngine) -> None:
    async with manager(engine).unscoped_transaction() as connection:
        role = (
            await connection.execute(
                text("SELECT rolbypassrls, rolsuper FROM pg_roles WHERE rolname=current_user")
            )
        ).one()
        table_security = (
            await connection.execute(
                text(
                    "SELECT bool_and(relrowsecurity AND relforcerowsecurity), "
                    "bool_and(pg_get_userbyid(relowner) <> 'athena_app') "
                    "FROM pg_class WHERE relname = ANY(CAST(:tables AS text[]))"
                ),
                {
                    "tables": [
                        "runs",
                        "run_events",
                        "idempotency_records",
                        "approvals",
                        "outbox_events",
                        "cost_reservations",
                    ]
                },
            )
        ).one()
    assert role == (False, False)
    assert table_security == (True, True)


@pytest.mark.asyncio
async def test_p05_stale_and_twenty_concurrent_versions_lose(engine: AsyncEngine) -> None:
    ctx = context()
    service = RunTransitionService(manager(engine))

    for _round in range(3):
        run_id = await create_run(engine, ctx)

        async def attempt(target_run_id: UUID = run_id) -> str:
            try:
                await service.transition(
                    ctx, target_run_id, expected_version=0, to_state=RunState.VALIDATING
                )
                return "success"
            except OptimisticLockError:
                return "optimistic_lock"
            except InvalidTransition:
                return "domain_rejection"

        results = await asyncio.gather(*(attempt() for _ in range(20)))
        assert results.count("success") == 1
        assert len(results) == 20
        assert set(results) <= {"success", "optimistic_lock", "domain_rejection"}
        with pytest.raises(OptimisticLockError):
            await service.transition(ctx, run_id, expected_version=0, to_state=RunState.VALIDATING)


@pytest.mark.asyncio
async def test_p06_transition_event_and_outbox_commit_together(engine: AsyncEngine) -> None:
    ctx = context()
    run_id = await create_run(engine, ctx)
    await RunTransitionService(manager(engine)).transition(
        ctx, run_id, expected_version=0, to_state=RunState.VALIDATING
    )
    async with manager(engine).transaction(ctx) as connection:
        state = await connection.scalar(select(runs.c.state).where(runs.c.id == run_id))
        event_count = await connection.scalar(
            select(func.count()).select_from(run_events).where(run_events.c.run_id == run_id)
        )
        outbox_count = await connection.scalar(
            select(func.count())
            .select_from(outbox_events)
            .where(outbox_events.c.aggregate_id == run_id)
        )
    assert (state, event_count, outbox_count) == ("validating", 1, 1)


@pytest.mark.asyncio
async def test_p07_middle_failure_rolls_back_all_writes(engine: AsyncEngine) -> None:
    ctx = context()
    run_id = await create_run(engine, ctx)
    with pytest.raises(ValueError, match="payload"):
        await RunTransitionService(manager(engine)).transition(
            ctx,
            run_id,
            expected_version=0,
            to_state=RunState.VALIDATING,
            outbox_payload={"value": "x" * MAX_PAYLOAD_BYTES},
        )
    snapshot = await RunStore(manager(engine)).load(ctx, run_id)
    assert snapshot is not None and snapshot.version == 0 and not snapshot.run.events
    async with manager(engine).transaction(ctx) as connection:
        assert (
            await connection.scalar(
                select(func.count())
                .select_from(outbox_events)
                .where(outbox_events.c.aggregate_id == run_id)
            )
            == 0
        )


@pytest.mark.asyncio
async def test_p08_duplicate_event_sequence_is_rejected(engine: AsyncEngine) -> None:
    ctx = context()
    run_id = await create_run(engine, ctx)
    service = RunTransitionService(manager(engine))
    await service.transition(ctx, run_id, expected_version=0, to_state=RunState.VALIDATING)
    with pytest.raises(DBAPIError):
        async with manager(engine).transaction(ctx) as connection:
            await connection.execute(
                insert(run_events).values(
                    id=uuid4(),
                    workspace_id=ctx.workspace_id,
                    run_id=run_id,
                    sequence=1,
                    transition_version=None,
                    event_type="tool.progress",
                    visibility="internal",
                    payload={"percent": 50},
                    occurred_at=datetime.now(UTC),
                )
            )


@pytest.mark.asyncio
async def test_p09_app_role_cannot_update_or_delete_events(engine: AsyncEngine) -> None:
    ctx = context()
    run_id = await create_run(engine, ctx)
    await RunTransitionService(manager(engine)).transition(
        ctx, run_id, expected_version=0, to_state=RunState.VALIDATING
    )
    with pytest.raises(DBAPIError):
        async with manager(engine).transaction(ctx) as connection:
            await connection.execute(
                update(run_events).where(run_events.c.run_id == run_id).values(sequence=2)
            )
    with pytest.raises(DBAPIError):
        async with manager(engine).transaction(ctx) as connection:
            await connection.execute(delete(run_events).where(run_events.c.run_id == run_id))


@pytest.mark.asyncio
async def test_p10_twenty_idempotency_reserves_have_one_winner(engine: AsyncEngine) -> None:
    ctx = context()
    run_id = await create_run(engine, ctx)
    key = IdempotencyKey(str(ctx.workspace_id), str(run_id), "call", "allowed_canary")
    fingerprint = RequestFingerprint("a" * 64, "v1")

    async def reserve(index: int) -> ReservationState:
        store = PostgresIdempotencyStore(manager(engine), ctx, lease_owner=str(index))
        return (await store.reserve(key, fingerprint)).state

    states = await asyncio.gather(*(reserve(index) for index in range(20)))
    assert states.count(ReservationState.RESERVED) == 1
    assert states.count(ReservationState.IN_PROGRESS) == 19


@pytest.mark.asyncio
async def test_p11_idempotency_fingerprint_conflicts(engine: AsyncEngine) -> None:
    ctx = context()
    run_id = await create_run(engine, ctx)
    store = PostgresIdempotencyStore(manager(engine), ctx, lease_owner="one")
    key = IdempotencyKey(str(ctx.workspace_id), str(run_id), "call", "allowed_canary")
    assert (
        await store.reserve(key, RequestFingerprint("a" * 64, "v1"))
    ).state is ReservationState.RESERVED
    assert (
        await store.reserve(key, RequestFingerprint("b" * 64, "v1"))
    ).state is ReservationState.CONFLICT


@pytest.mark.asyncio
async def test_p12_completed_idempotency_outcome_replays(engine: AsyncEngine) -> None:
    ctx = context()
    run_id = await create_run(engine, ctx)
    key = IdempotencyKey(str(ctx.workspace_id), str(run_id), "call", "allowed_canary")
    fingerprint = RequestFingerprint("a" * 64, "v1")
    store = PostgresIdempotencyStore(manager(engine), ctx, lease_owner="one")
    await store.reserve(key, fingerprint)
    await store.complete(key, BrokerOutcome(BrokerOutcomeStatus.SUCCEEDED, "ok", {"x": 1}))
    replay = await PostgresIdempotencyStore(manager(engine), ctx, lease_owner="two").reserve(
        key, fingerprint
    )
    assert replay.state is ReservationState.REPLAY
    assert replay.outcome.result == {"x": 1}


@pytest.mark.asyncio
async def test_p13_expired_lease_requires_reconciliation(engine: AsyncEngine) -> None:
    ctx = context()
    run_id = await create_run(engine, ctx)
    key = IdempotencyKey(str(ctx.workspace_id), str(run_id), "call", "allowed_canary")
    fingerprint = RequestFingerprint("a" * 64, "v1")
    first = PostgresIdempotencyStore(
        manager(engine), ctx, lease_owner="one", lease_duration=timedelta(seconds=-1)
    )
    assert (await first.reserve(key, fingerprint)).state is ReservationState.RESERVED
    second = PostgresIdempotencyStore(manager(engine), ctx, lease_owner="two")
    assert (
        await second.reserve(key, fingerprint)
    ).state is ReservationState.UNKNOWN_RECONCILIATION_REQUIRED


@pytest.mark.asyncio
async def test_p14_twenty_approval_consumers_have_one_winner(engine: AsyncEngine) -> None:
    ctx = context()
    run_id = await create_run(engine, ctx)
    store = PostgresApprovalStore(manager(engine), ctx)
    digest = args_digest({})
    await store.add(
        Approval(
            run_id=str(run_id),
            tool_call_id="call",
            operation="allowed_canary",
            args_digest=digest,
            decision="once",
            expires_at=datetime.now(UTC) + timedelta(minutes=1),
        )
    )
    results = await asyncio.gather(
        *(store.consume(str(run_id), "call", "allowed_canary", digest) for _ in range(20))
    )
    assert sum(results) == 1


@pytest.mark.asyncio
async def test_p15_other_workspace_cannot_consume_approval(engine: AsyncEngine) -> None:
    first, second = context(), context()
    run_id = await create_run(engine, first)
    digest = args_digest({})
    await PostgresApprovalStore(manager(engine), first).add(
        Approval(
            run_id=str(run_id),
            tool_call_id="call",
            operation="allowed_canary",
            args_digest=digest,
            decision="once",
            expires_at=datetime.now(UTC) + timedelta(minutes=1),
        )
    )
    assert not await PostgresApprovalStore(manager(engine), second).consume(
        str(run_id), "call", "allowed_canary", digest
    )


@pytest.mark.asyncio
async def test_p16_cost_double_settle_is_idempotent(engine: AsyncEngine) -> None:
    ctx = context()
    run_id = await create_run(engine, ctx)
    store = CostReservationStore(manager(engine))
    reservation_id = await store.create(ctx, run_id, 10)
    first = await store.settle_to(ctx, reservation_id, 5)
    second = await store.settle_to(ctx, reservation_id, 5)
    assert first.settled_microunits == second.settled_microunits == 5
    assert first.version == second.version


@pytest.mark.asyncio
async def test_p17_cost_cannot_settle_over_reserved(engine: AsyncEngine) -> None:
    ctx = context()
    run_id = await create_run(engine, ctx)
    store = CostReservationStore(manager(engine))
    reservation_id = await store.create(ctx, run_id, 10)
    with pytest.raises(CostReservationError):
        await store.settle_to(ctx, reservation_id, 11)


@pytest.mark.asyncio
async def test_p18_cost_release_is_idempotent(engine: AsyncEngine) -> None:
    ctx = context()
    run_id = await create_run(engine, ctx)
    store = CostReservationStore(manager(engine))
    reservation_id = await store.create(ctx, run_id, 10)
    first = await store.release(ctx, reservation_id)
    second = await store.release(ctx, reservation_id)
    assert first.status == second.status == "released"
    assert first.version == second.version


@pytest.mark.asyncio
async def test_p19_concurrent_outbox_claim_does_not_duplicate(engine: AsyncEngine) -> None:
    ctx = context()
    run_id = await create_run(engine, ctx)
    store = OutboxStore()
    async with manager(engine).transaction(ctx) as connection:
        await store.append(
            connection,
            ctx,
            aggregate_type="run",
            aggregate_id=run_id,
            event_type="test",
            payload={"run_id": str(run_id)},
        )

    async def claim(owner: str):
        async with manager(engine).transaction(ctx) as connection:
            return await store.claim_batch(
                connection, ctx, owner=owner, limit=1, lease=timedelta(minutes=1)
            )

    first, second = await asyncio.gather(claim("a"), claim("b"))
    assert len(first) + len(second) == 1


@pytest.mark.asyncio
async def test_p20_workspace_context_does_not_leak_through_pool(engine: AsyncEngine) -> None:
    first, second = context(), context()
    await create_run(engine, first)
    shared = manager(engine)
    async with shared.transaction(first) as connection:
        assert await connection.scalar(select(func.count()).select_from(runs)) == 1
    async with shared.unscoped_transaction() as connection:
        setting = await connection.scalar(text("SELECT current_setting('app.workspace_id', true)"))
        assert setting in {None, ""}
        assert await connection.scalar(select(func.count()).select_from(runs)) == 0
    async with shared.transaction(second) as connection:
        assert await connection.scalar(select(func.count()).select_from(runs)) == 0


@pytest.mark.asyncio
async def test_p21_oversized_payload_is_rejected(engine: AsyncEngine) -> None:
    ctx = context()
    run_id = await create_run(engine, ctx)
    with pytest.raises(ValueError, match="payload"):
        async with manager(engine).transaction(ctx) as connection:
            await OutboxStore().append(
                connection,
                ctx,
                aggregate_type="run",
                aggregate_id=run_id,
                event_type="large",
                payload={"value": "x" * MAX_PAYLOAD_BYTES},
            )


def test_p22_migration_up_and_down_on_empty_database() -> None:
    assert MIGRATION_DATABASE_URL is not None
    config = Config("alembic.ini")
    config.set_main_option("sqlalchemy.url", MIGRATION_DATABASE_URL)
    command.downgrade(config, "base")
    command.upgrade(config, "head")


@pytest.mark.asyncio
async def test_p25_runtime_and_policy_role_identity(engine: AsyncEngine) -> None:
    ctx = context()
    async with manager(engine).transaction(ctx) as connection:
        identity = (await connection.execute(text("SELECT session_user, current_user"))).one()
        role_flags = (
            await connection.execute(
                text(
                    "SELECT rolname, rolsuper, rolbypassrls FROM pg_roles "
                    "WHERE rolname IN ('athena_runtime_login','athena_app') ORDER BY rolname"
                )
            )
        ).all()
        runtime_owns_table = await connection.scalar(
            text(
                "SELECT EXISTS (SELECT 1 FROM pg_class c JOIN pg_roles r ON r.oid=c.relowner "
                "WHERE c.relnamespace='athena'::regnamespace "
                "AND r.rolname='athena_runtime_login')"
            )
        )
    assert identity == ("athena_runtime_login", "athena_app")
    assert role_flags == [
        ("athena_app", False, False),
        ("athena_runtime_login", False, False),
    ]
    assert runtime_owns_table is False


@pytest.mark.asyncio
async def test_p26_reset_role_has_no_table_access(engine: AsyncEngine) -> None:
    async with engine.connect() as connection:
        async with connection.begin():
            await connection.execute(text("RESET ROLE"))
            await connection.execute(
                text("SELECT set_config('app.workspace_id', :workspace_id, true)"),
                {"workspace_id": str(uuid4())},
            )
            with pytest.raises(DBAPIError):
                await connection.scalar(select(func.count()).select_from(runs))


@pytest.mark.asyncio
async def test_p27_live_event_global_sequence_and_transition_rehydrate(
    engine: AsyncEngine,
) -> None:
    ctx = context()
    run_id = await create_run(engine, ctx)
    service = RunTransitionService(manager(engine))
    await service.transition(ctx, run_id, expected_version=0, to_state=RunState.VALIDATING)
    async with manager(engine).transaction(ctx) as connection:
        await EventStore().append_live_event(
            connection,
            ctx,
            run_id,
            event_type="tool.progress",
            payload={"percent": 50},
            occurred_at=datetime.now(UTC),
        )
    await service.transition(ctx, run_id, expected_version=1, to_state=RunState.EXPIRED)
    async with manager(engine).transaction(ctx) as connection:
        rows = (
            (
                await connection.execute(
                    select(run_events)
                    .where(run_events.c.run_id == run_id)
                    .order_by(run_events.c.sequence)
                )
            )
            .mappings()
            .all()
        )
    snapshot = await RunStore(manager(engine)).load(ctx, run_id)
    assert [row["sequence"] for row in rows] == [1, 2, 3]
    assert [row["transition_version"] for row in rows] == [1, None, 2]
    assert snapshot is not None and snapshot.run.state is RunState.EXPIRED
    transition_times = [
        row["occurred_at"] for row in rows if row["event_type"] == "run.transitioned"
    ]
    assert [event.occurred_at for event in snapshot.run.events] == transition_times


@pytest.mark.asyncio
async def test_p28_second_cost_reservation_for_run_is_rejected(engine: AsyncEngine) -> None:
    ctx = context()
    run_id = await create_run(engine, ctx)
    store = CostReservationStore(manager(engine))
    await store.create(ctx, run_id, 10)
    with pytest.raises(DBAPIError):
        await store.create(ctx, run_id, 20)


@pytest.mark.asyncio
async def test_p29_runtime_direct_state_update_is_denied(engine: AsyncEngine) -> None:
    ctx = context()
    run_id = await create_run(engine, ctx)
    for target in (RunState.RUNNING, RunState.VALIDATING):
        with pytest.raises(DBAPIError):
            async with manager(engine).transaction(ctx) as connection:
                await connection.execute(
                    update(runs).where(runs.c.id == run_id).values(state=target.value)
                )
    assert (
        await RunTransitionService(manager(engine)).transition(
            ctx, run_id, expected_version=0, to_state=RunState.VALIDATING
        )
        == 1
    )


@pytest.mark.asyncio
async def test_p30_migration_owner_trigger_rejects_invalid_transition(
    engine: AsyncEngine,
) -> None:
    assert MIGRATION_DATABASE_URL is not None
    ctx = context()
    run_id = await create_run(engine, ctx)
    migration_engine = create_async_engine(MIGRATION_DATABASE_URL)
    try:
        with pytest.raises(DBAPIError):
            async with migration_engine.connect() as connection:
                async with connection.begin():
                    await connection.execute(text("SET LOCAL ROLE athena_migration"))
                    await connection.execute(
                        text("SELECT set_config('app.workspace_id', :workspace_id, true)"),
                        {"workspace_id": str(ctx.workspace_id)},
                    )
                    await connection.execute(
                        update(runs).where(runs.c.id == run_id).values(state=RunState.RUNNING.value)
                    )
    finally:
        await migration_engine.dispose()


@pytest.mark.asyncio
async def test_p32_run_event_permission_is_select_only(engine: AsyncEngine) -> None:
    ctx = context()
    run_id = await create_run(engine, ctx)
    async with manager(engine).transaction(ctx) as connection:
        privileges = set(
            await connection.scalars(
                text(
                    "SELECT privilege_type FROM information_schema.role_table_grants "
                    "WHERE grantee='athena_app' AND table_schema='athena' "
                    "AND table_name='run_events'"
                )
            )
        )
    assert privileges == {"SELECT"}
    with pytest.raises(DBAPIError):
        async with manager(engine).transaction(ctx) as connection:
            await connection.execute(
                insert(run_events).values(
                    id=uuid4(),
                    workspace_id=ctx.workspace_id,
                    run_id=run_id,
                    sequence=1,
                    transition_version=None,
                    event_type="tool.progress",
                    visibility="internal",
                    payload={"percent": 1},
                    occurred_at=datetime.now(UTC),
                )
            )


@pytest.mark.asyncio
async def test_p33_live_event_function_is_scoped_and_reserves_transition_type(
    engine: AsyncEngine,
) -> None:
    victim = context()
    attacker = context()
    run_id = await create_run(engine, victim)
    with pytest.raises(DBAPIError):
        async with manager(engine).transaction(attacker) as connection:
            await EventStore().append_live_event(
                connection,
                attacker,
                run_id,
                event_type="tool.progress",
                payload={"percent": 1},
                occurred_at=datetime.now(UTC),
            )
    with pytest.raises(DBAPIError):
        async with manager(engine).transaction(victim) as connection:
            await EventStore().append_live_event(
                connection,
                victim,
                run_id,
                event_type="run.transitioned",
                payload={"from_state": "created", "to_state": "validating"},
                occurred_at=datetime.now(UTC),
            )
