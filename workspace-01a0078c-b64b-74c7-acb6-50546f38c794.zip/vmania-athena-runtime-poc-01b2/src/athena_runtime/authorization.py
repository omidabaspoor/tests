import asyncio
from enum import StrEnum
from typing import Any, Protocol


class AuthorizationDecision(StrEnum):
    ALLOW = "ALLOW"
    DENY = "DENY"
    REQUIRE_APPROVAL = "REQUIRE_APPROVAL"


class AuthorizationWorker(Protocol):
    async def authorize(self, request: object) -> Any: ...


async def authorize_fail_closed(
    worker: AuthorizationWorker, request: object, timeout: float
) -> AuthorizationDecision:
    try:
        result = await asyncio.wait_for(worker.authorize(request), timeout)
    except TimeoutError:
        return AuthorizationDecision.DENY
    except asyncio.CancelledError:
        raise
    except Exception:
        return AuthorizationDecision.DENY
    return result if isinstance(result, AuthorizationDecision) else AuthorizationDecision.DENY
