import hashlib
import json
from typing import Any

MAX_JSON_BYTES = 4096


def canonical_json_bytes(value: dict[str, Any], *, max_bytes: int = MAX_JSON_BYTES) -> bytes:
    if not isinstance(value, dict) or any(not isinstance(key, str) for key in value):
        raise TypeError("arguments must be an object with string keys")
    try:
        encoded = json.dumps(
            value,
            allow_nan=False,
            ensure_ascii=False,
            separators=(",", ":"),
            sort_keys=True,
        ).encode("utf-8")
    except (TypeError, ValueError) as exc:
        raise ValueError("arguments must be finite strict JSON") from exc
    if len(encoded) > max_bytes:
        raise ValueError("arguments too large")
    # A round trip removes aliases and proves that the retained representation is JSON-only.
    decoded = json.loads(encoded)
    if not isinstance(decoded, dict):
        raise TypeError("arguments must be a JSON object")
    return encoded


def fresh_json_object(snapshot: bytes) -> dict[str, Any]:
    value = json.loads(snapshot)
    if not isinstance(value, dict):
        raise TypeError("snapshot is not a JSON object")
    return value


def snapshot_digest(snapshot: bytes) -> str:
    return hashlib.sha256(snapshot).hexdigest()
