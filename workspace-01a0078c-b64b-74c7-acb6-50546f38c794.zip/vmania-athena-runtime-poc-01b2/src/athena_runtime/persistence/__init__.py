"""PostgreSQL-only persistence core for Athena Runtime."""
