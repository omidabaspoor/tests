import json
from typing import Any

from athena_runtime.persistence.schema import MAX_OUTCOME_BYTES, MAX_PAYLOAD_BYTES

MAX_JSON_BYTES = MAX_PAYLOAD_BYTES


def validate_json_payload(
    payload: dict[str, Any], *, maximum_bytes: int = MAX_PAYLOAD_BYTES
) -> dict[str, Any]:
    if not isinstance(payload, dict):
        raise TypeError("payload must be a JSON object")
    try:
        encoded = json.dumps(
            payload,
            allow_nan=False,
            ensure_ascii=False,
            separators=(",", ":"),
            sort_keys=True,
        ).encode("utf-8")
    except (TypeError, ValueError) as exc:
        raise ValueError("payload must contain finite JSON values") from exc
    if len(encoded) > maximum_bytes:
        raise ValueError("payload exceeds maximum size")
    decoded = json.loads(encoded)
    if _contains_sensitive_key(decoded):
        raise ValueError("payload contains forbidden reasoning or secret field")
    return decoded


def validate_outcome(payload: dict[str, Any] | None) -> dict[str, Any] | None:
    if payload is None:
        return None
    return validate_json_payload(payload, maximum_bytes=MAX_OUTCOME_BYTES)


def _contains_sensitive_key(value: Any) -> bool:
    forbidden = {
        "chain_of_thought",
        "chain-of-thought",
        "reasoning_trace",
        "secret",
        "api_key",
        "password",
        "token",
    }
    if isinstance(value, dict):
        return any(
            str(key).lower() in forbidden or _contains_sensitive_key(item)
            for key, item in value.items()
        )
    if isinstance(value, list):
        return any(_contains_sensitive_key(item) for item in value)
    return False
