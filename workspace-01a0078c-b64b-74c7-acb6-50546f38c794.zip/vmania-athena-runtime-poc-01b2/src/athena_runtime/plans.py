import hashlib
import json
from dataclasses import dataclass
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, field_validator

from athena_runtime.capsule import IntentCapsule
from athena_runtime.json_snapshot import canonical_json_bytes, fresh_json_object
from athena_runtime.policy import PolicyEngine


class PlanStepProposal(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")
    step_id: str = Field(min_length=1, max_length=64)
    operation: str = Field(min_length=1, max_length=64)
    arguments: dict[str, Any]
    depends_on: tuple[str, ...] = ()
    estimated_cost_microunits: int = Field(ge=0, strict=True)

    @field_validator("arguments")
    @classmethod
    def structurally_valid_arguments(cls, value: dict[str, Any]) -> dict[str, Any]:
        canonical_json_bytes(value)
        return value


class PlanProposal(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")
    steps: tuple[PlanStepProposal, ...]


@dataclass(frozen=True, slots=True)
class ValidatedStep:
    step_id: str
    operation: str
    arguments_json: bytes
    depends_on: tuple[str, ...]
    estimated_cost_microunits: int

    def fresh_arguments(self) -> dict[str, Any]:
        return fresh_json_object(self.arguments_json)


_PLAN_SEAL = object()


class ValidatedPlan:
    __slots__ = ("_integrity_hash", "_steps")

    def __init__(
        self,
        steps: tuple[ValidatedStep, ...],
        integrity_hash: str,
        seal: object,
    ) -> None:
        if seal is not _PLAN_SEAL:
            raise TypeError("ValidatedPlan can only be created by PlanValidator")
        self._steps = steps
        self._integrity_hash = integrity_hash

    @property
    def steps(self) -> tuple[ValidatedStep, ...]:
        return self._steps

    @classmethod
    def _create(
        cls,
        steps: tuple[ValidatedStep, ...],
        capsule: IntentCapsule,
        permissions: frozenset[str],
    ) -> "ValidatedPlan":
        return cls(steps, _integrity_hash(steps, capsule, permissions), _PLAN_SEAL)

    def _valid_for(self, capsule: IntentCapsule, permissions: frozenset[str]) -> bool:
        return self._integrity_hash == _integrity_hash(self._steps, capsule, permissions)


class PlanValidator:
    def __init__(
        self,
        argument_schemas: dict[str, type[BaseModel]],
        policy: PolicyEngine,
    ) -> None:
        self._schemas = dict(argument_schemas)
        self._policy = policy

    def validate(self, proposal: PlanProposal, capsule: IntentCapsule) -> ValidatedPlan:
        effective_permissions = self._policy.effective_permissions(capsule)
        if len(proposal.steps) > capsule.max_steps:
            raise ValueError("too many steps")
        ids = [step.step_id for step in proposal.steps]
        if len(ids) != len(set(ids)):
            raise ValueError("duplicate step id")
        known_ids = set(ids)
        if any(not set(step.depends_on) <= known_ids for step in proposal.steps):
            raise ValueError("unknown dependency")
        if (
            sum(step.estimated_cost_microunits for step in proposal.steps)
            > capsule.max_cost_microunits
        ):
            raise ValueError("plan cost exceeds capsule maximum")

        graph = {step.step_id: set(step.depends_on) for step in proposal.steps}
        visiting: set[str] = set()
        done: set[str] = set()

        def visit(node: str) -> None:
            if node in visiting:
                raise ValueError("dependency cycle")
            if node in done:
                return
            visiting.add(node)
            for dependency in graph[node]:
                visit(dependency)
            visiting.remove(node)
            done.add(node)

        for node in graph:
            visit(node)

        validated: list[ValidatedStep] = []
        for step in proposal.steps:
            schema = self._schemas.get(step.operation)
            if schema is None:
                raise ValueError("unknown operation")
            if step.operation not in effective_permissions:
                raise ValueError("operation outside effective permission")
            try:
                parsed = schema.model_validate(step.arguments)
            except ValueError as exc:
                raise ValueError("arguments schema invalid") from exc
            arguments_json = canonical_json_bytes(parsed.model_dump(mode="json", exclude_none=True))
            validated.append(
                ValidatedStep(
                    step.step_id,
                    step.operation,
                    arguments_json,
                    step.depends_on,
                    step.estimated_cost_microunits,
                )
            )
        return ValidatedPlan._create(tuple(validated), capsule, effective_permissions)


class PlanExecutionBoundary:
    def __init__(self, policy: PolicyEngine) -> None:
        self._policy = policy

    def accept(
        self,
        plan: ValidatedPlan,
        capsule: IntentCapsule,
    ) -> tuple[ValidatedStep, ...]:
        effective_permissions = self._policy.effective_permissions(capsule)
        if not isinstance(plan, ValidatedPlan) or not plan._valid_for(
            capsule, effective_permissions
        ):
            raise ValueError("plan validation token or policy hash is invalid")
        return plan.steps


def _integrity_hash(
    steps: tuple[ValidatedStep, ...],
    capsule: IntentCapsule,
    permissions: frozenset[str],
) -> str:
    value = {
        "run_id": capsule.run_id,
        "workspace_id": capsule.workspace_id,
        "policy_version": capsule.policy_version,
        "max_steps": capsule.max_steps,
        "max_cost_microunits": capsule.max_cost_microunits,
        "permissions": sorted(permissions),
        "steps": [
            {
                "step_id": step.step_id,
                "operation": step.operation,
                "arguments": json.loads(step.arguments_json),
                "depends_on": list(step.depends_on),
                "estimated_cost_microunits": step.estimated_cost_microunits,
            }
            for step in steps
        ],
    }
    encoded = json.dumps(value, sort_keys=True, separators=(",", ":")).encode()
    return hashlib.sha256(encoded).hexdigest()
