import asyncio
from dataclasses import dataclass
from enum import StrEnum
from typing import Any, Protocol


@dataclass(frozen=True, slots=True)
class IdempotencyKey:
    workspace_id: str
    run_id: str
    tool_call_id: str
    operation: str


@dataclass(frozen=True, slots=True)
class RequestFingerprint:
    args_digest: str
    policy_version: str


class ReservationState(StrEnum):
    RESERVED = "reserved"
    IN_PROGRESS = "in_progress"
    REPLAY = "replay"
    CONFLICT = "conflict"
    UNKNOWN_RECONCILIATION_REQUIRED = "unknown_reconciliation_required"


class RecordStatus(StrEnum):
    PENDING = "pending"
    COMPLETED = "completed"


@dataclass(frozen=True, slots=True)
class IdempotencyRecord:
    fingerprint: RequestFingerprint
    status: RecordStatus
    outcome: Any = None


@dataclass(frozen=True, slots=True)
class Reservation:
    state: ReservationState
    outcome: Any = None


class IdempotencyStore(Protocol):
    async def reserve(
        self, key: IdempotencyKey, fingerprint: RequestFingerprint
    ) -> Reservation: ...

    async def complete(self, key: IdempotencyKey, outcome: Any) -> None: ...

    async def release(self, key: IdempotencyKey) -> None: ...


class InMemoryIdempotencyStore:
    def __init__(self) -> None:
        self._records: dict[IdempotencyKey, IdempotencyRecord] = {}
        self._lock = asyncio.Lock()

    async def reserve(self, key: IdempotencyKey, fingerprint: RequestFingerprint) -> Reservation:
        async with self._lock:
            record = self._records.get(key)
            if record is None:
                self._records[key] = IdempotencyRecord(fingerprint, RecordStatus.PENDING)
                return Reservation(ReservationState.RESERVED)
            if record.fingerprint != fingerprint:
                return Reservation(ReservationState.CONFLICT)
            if record.status is RecordStatus.PENDING:
                return Reservation(ReservationState.IN_PROGRESS)
            return Reservation(ReservationState.REPLAY, record.outcome)

    async def complete(self, key: IdempotencyKey, outcome: Any) -> None:
        async with self._lock:
            record = self._records[key]
            self._records[key] = IdempotencyRecord(
                record.fingerprint, RecordStatus.COMPLETED, outcome
            )

    async def release(self, key: IdempotencyKey) -> None:
        async with self._lock:
            record = self._records.get(key)
            if record is not None and record.status is RecordStatus.PENDING:
                del self._records[key]
