import asyncio
from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, field_validator

from athena_runtime.clocks import Clock, SystemClock
from athena_runtime.json_snapshot import canonical_json_bytes, snapshot_digest


def args_digest(arguments: dict[str, Any]) -> str:
    return snapshot_digest(canonical_json_bytes(arguments))


class Approval(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")
    run_id: str
    tool_call_id: str
    operation: str
    args_digest: str
    expires_at: datetime
    decision: Literal["once", "deny"]

    @field_validator("expires_at")
    @classmethod
    def timezone_required(cls, value: datetime) -> datetime:
        if value.tzinfo is None:
            raise ValueError("expires_at must be timezone-aware")
        return value


class ApprovalStore:
    def __init__(self, clock: Clock | None = None) -> None:
        self._items: dict[tuple[str, str, str, str], Approval] = {}
        self._lock = asyncio.Lock()
        self._clock = clock or SystemClock()

    async def add(self, item: Approval) -> None:
        async with self._lock:
            self._items[(item.run_id, item.tool_call_id, item.operation, item.args_digest)] = item

    async def consume(self, run_id: str, tool_call_id: str, operation: str, digest: str) -> bool:
        key = (run_id, tool_call_id, operation, digest)
        async with self._lock:
            item = self._items.get(key)
            if item is None or item.decision != "once" or item.expires_at <= self._clock.now():
                return False
            del self._items[key]
            return True
