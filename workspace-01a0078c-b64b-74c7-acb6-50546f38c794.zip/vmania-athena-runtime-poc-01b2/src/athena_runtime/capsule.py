from datetime import datetime
from typing import Protocol

from pydantic import BaseModel, ConfigDict, Field, field_validator


class IntentCapsule(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")
    run_id: str = Field(min_length=1)
    workspace_id: str = Field(min_length=1)
    goal: str = Field(min_length=1)
    requested_operations: frozenset[str] = frozenset()
    task_allowed_operations: frozenset[str] = frozenset()
    server_maximum_operations: frozenset[str] = frozenset()
    plan_scope_operations: frozenset[str] = frozenset()
    max_cost_microunits: int = Field(ge=0, strict=True)
    max_steps: int = Field(gt=0, le=100, strict=True)
    expires_at: datetime
    nonce: str = Field(min_length=1)
    policy_version: str = Field(min_length=1)

    @field_validator("expires_at")
    @classmethod
    def timezone_required(cls, value: datetime) -> datetime:
        if value.tzinfo is None:
            raise ValueError("expires_at must be timezone-aware")
        return value


class CapsuleVerifier(Protocol):
    def verify(self, capsule: IntentCapsule) -> bool: ...
