class AthenaRuntimeError(Exception):
    """Base domain error."""


class InvalidTransition(AthenaRuntimeError):
    """A run state transition is not in the explicit graph."""


class IdempotencyConflict(AthenaRuntimeError):
    """An idempotency key was reused with a different request fingerprint."""
