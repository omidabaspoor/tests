from athena_runtime.compiler.models import (
    Brief,
    ClarificationState,
    Question,
    RequiredLevel,
    SlotStatus,
)

_PRIORITY = (
    "goal",
    "output_type",
    "subject",
    "edit_target",
    "evidence",
    "audience",
    "platform",
    "constraints",
    "tone",
)

_QUESTIONS: dict[str, Question] = {
    "goal": Question(
        question_id="q.goal",
        slot_name="goal",
        text="هدفت از این خروجی چیه؟",
        options=("اطلاع‌رسانی", "فروش", "تعامل"),
        recommended_option="تعامل",
    ),
    "output_type": Question(
        question_id="q.output",
        slot_name="output_type",
        text="خروجی رو در چه قالبی می‌خوای؟",
        options=("متن کوتاه", "متن کامل", "فهرست"),
        recommended_option="متن کوتاه",
    ),
    "subject": Question(
        question_id="q.subject",
        slot_name="subject",
        text="موضوع اصلی چی باشه؟",
        options=("محصول یا خدمت", "آموزشی", "معرفی برند"),
        recommended_option="محصول یا خدمت",
    ),
    "edit_target": Question(
        question_id="q.edit_target",
        slot_name="edit_target",
        text="پس‌زمینه به چه فضایی تغییر کنه؟",
        options=("استودیویی", "فضای باز", "مینیمال"),
        recommended_option="استودیویی",
    ),
    "evidence": Question(
        question_id="q.evidence",
        slot_name="evidence",
        text="برای بررسی پیج کدوم مدرک رو می‌فرستی؟",
        options=("لینک پیج", "اسکرین‌شات آمار", "هر دو"),
        recommended_option="هر دو",
        allow_delegate=False,
    ),
    "audience": Question(
        question_id="q.audience",
        slot_name="audience",
        text="مخاطب اصلی کیه؟",
        options=("عمومی", "مشتری فعلی", "مشتری جدید"),
        recommended_option="عمومی",
    ),
    "platform": Question(
        question_id="q.platform",
        slot_name="platform",
        text="برای کدوم پلتفرم می‌خوای؟",
        options=("اینستاگرام", "لینکدین", "وب‌سایت"),
        recommended_option="اینستاگرام",
    ),
    "constraints": Question(
        question_id="q.constraints",
        slot_name="constraints",
        text="کدام محدودیت مهم‌تره؟",
        options=("خیلی کوتاه", "کامل و توضیحی", "متعادل"),
        recommended_option="متعادل",
    ),
    "tone": Question(
        question_id="q.tone",
        slot_name="tone",
        text="چه لحنی مناسب‌تره؟",
        options=("دوستانه", "رسمی", "خنثی"),
        recommended_option="دوستانه",
    ),
}


class ClarificationPolicy:
    def choose(self, brief: Brief, state: ClarificationState) -> Question | None:
        if state.delegated or state.question_count >= 3:
            return None
        slots = _slots(brief)
        conflicts: list[str] = []
        missing: list[str] = []
        for name, slot in slots.items():
            if slot.status is SlotStatus.CONFLICTING:
                conflicts.append(name)
            elif slot.required_level is RequiredLevel.HARD and slot.status is SlotStatus.UNKNOWN:
                missing.append(name)

        def order(name: str) -> int:
            return _PRIORITY.index(name) if name in _PRIORITY else 99

        candidates = sorted(conflicts, key=order) + sorted(missing, key=order)
        for name in candidates:
            question = _QUESTIONS.get(name)
            if question and question.question_id not in state.asked_question_ids:
                return question
        return None


def _slots(brief: Brief) -> dict[str, object]:
    values = {
        "goal": brief.goal,
        "output_type": brief.output_type,
        "subject": brief.subject,
        "audience": brief.audience,
        "platform": brief.platform,
        "tone": brief.tone,
        "constraints": brief.constraints,
        "attachments": brief.attachments,
    }
    values.update({item.name: item.slot for item in brief.additional_slots})
    return values
