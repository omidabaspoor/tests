from athena_runtime.compiler.models import (
    Brief,
    FreshnessClass,
    RiskLevel,
    RouteDecision,
    RouteTier,
)


class FreshnessDetector:
    def detect(self, text: str, task_type: str) -> FreshnessClass:
        normalized = text.casefold()
        if any(token in normalized for token in ("امروز", "الان", "ترند", "قیمت")):
            return FreshnessClass.LIVE
        if any(token in normalized for token in ("فردا", "این هفته")):
            return FreshnessClass.DAILY
        if any(token in normalized for token in ("مناسبت", "ماهانه", "فصل")):
            return FreshnessClass.PERIODIC
        if task_type == "research":
            return FreshnessClass.LIVE
        return FreshnessClass.STABLE


class ComplexityClassifier:
    def classify(self, task_type: str, text: str, context_size: int) -> str:
        if task_type in {"software_project", "multi_content", "research"}:
            return "complex"
        if task_type in {"image_edit", "image_generation"} or context_size > 8_000:
            return "tool"
        if task_type in {"calculation", "rewrite"}:
            return "simple"
        return "standard"


class AthenaRouter:
    def route(
        self,
        brief: Brief,
        *,
        complexity: str,
        tool_need: str | None,
        quality_floor: str,
    ) -> RouteDecision:
        task = str(brief.task_type.value)
        freshness = FreshnessClass(str(brief.freshness_requirement.value))
        risk = RiskLevel(str(brief.risk_level.value))
        if task == "calculation":
            return RouteDecision(tier=RouteTier.R0, reason_code="DETERMINISTIC_MATH")
        if risk is RiskLevel.HIGH:
            return RouteDecision(
                tier=RouteTier.R3,
                reason_code="SENSITIVE_DOMAIN",
                warning_policy="professional-safety-warning",
            )
        if freshness is FreshnessClass.LIVE or task == "research":
            return RouteDecision(tier=RouteTier.R3, reason_code="LIVE_RESEARCH_REQUIRED")
        if task == "rewrite":
            return RouteDecision(tier=RouteTier.R1, reason_code="SIMPLE_TRANSFORM")
        if task == "file_assembly":
            return RouteDecision(tier=RouteTier.R2, reason_code="DETERMINISTIC_FILE_ASSEMBLY")
        if complexity in {"complex", "tool"} or tool_need:
            return RouteDecision(tier=RouteTier.R3, reason_code="COMPLEX_OR_TOOL")
        if quality_floor == "draft":
            return RouteDecision(tier=RouteTier.R1, reason_code="LIGHTWEIGHT_DRAFT")
        return RouteDecision(tier=RouteTier.R2, reason_code="BALANCED_OUTPUT")
