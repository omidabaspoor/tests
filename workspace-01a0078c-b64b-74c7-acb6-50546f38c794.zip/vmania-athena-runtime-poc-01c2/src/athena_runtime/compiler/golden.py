import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from athena_runtime.compiler.compiler import RequirementCompiler
from athena_runtime.compiler.models import ClarificationState, DecisionKind
from athena_runtime.compiler.provider import (
    FakeUnderstandingProvider,
    UnderstandingResult,
)


@dataclass(frozen=True, slots=True)
class GoldenMetrics:
    case_count: int
    task_type_accuracy: float
    clarify_precision: float
    clarify_recall: float
    over_clarify_count: int
    under_clarify_count: int
    route_accuracy: float
    hard_safety_failure: int
    average_questions: float
    cases: tuple[dict[str, Any], ...]

    def as_dict(self) -> dict[str, Any]:
        return {
            "case_count": self.case_count,
            "task_type_accuracy": self.task_type_accuracy,
            "clarify_precision": self.clarify_precision,
            "clarify_recall": self.clarify_recall,
            "over_clarify_count": self.over_clarify_count,
            "under_clarify_count": self.under_clarify_count,
            "route_accuracy": self.route_accuracy,
            "hard_safety_failure": self.hard_safety_failure,
            "average_questions": self.average_questions,
            "cases": list(self.cases),
        }


class GoldenSetRunner:
    async def run(self, fixture_path: Path) -> GoldenMetrics:
        dataset = json.loads(fixture_path.read_text(encoding="utf-8"))
        cases = dataset["cases"]
        fixtures: dict[str, UnderstandingResult] = {}
        for case in cases:
            if case["domain"] == "memory":
                expected = case["expected"]
                intent = (
                    "BLOCK_MEMORY_WRITE"
                    if expected == "BLOCK_MEMORY_WRITE"
                    else "CONSENT_REQUIRED"
                    if expected == "CLARIFY_CONSENT"
                    else "DIRECT_POLICY"
                )
                fixtures[case["prompt"].casefold()] = UnderstandingResult(
                    task_type="memory_policy", memory_intent=intent
                )
        compiler = RequirementCompiler(FakeUnderstandingProvider(fixtures))
        reports: list[dict[str, Any]] = []
        task_correct = route_correct = hard_failure = 0
        tp = fp = fn = questions = 0
        for case in cases:
            result = await compiler.compile(
                case["prompt"],
                history=tuple(case.get("history", ())),
                attachment_manifest=tuple(case.get("attachments", ())),
                clarification_state=ClarificationState(),
            )
            expected_clarify = case["expected"].startswith("CLARIFY")
            predicted_clarify = result.decision.decision is DecisionKind.CLARIFY
            tp += int(expected_clarify and predicted_clarify)
            fp += int(not expected_clarify and predicted_clarify)
            fn += int(expected_clarify and not predicted_clarify)
            questions += int(result.question is not None)
            task_ok = result.brief.task_type.value == case["expected_task_type"]
            route_ok = result.route.tier.value == case["route"]
            task_correct += int(task_ok)
            route_correct += int(route_ok)
            safety_expected = case["expected"] in {"BLOCK", "BLOCK_MEMORY_WRITE"}
            safety_failed = safety_expected and result.decision.decision is not DecisionKind.BLOCK
            hard_failure += int(safety_failed)
            reports.append(
                {
                    "id": case["id"],
                    "expected": case["expected"],
                    "decision": result.decision.decision.value,
                    "reason_code": result.decision.reason_code,
                    "expected_route": case["route"],
                    "route": result.route.tier.value,
                    "task_type": result.brief.task_type.value,
                    "question_slot": result.question.slot_name if result.question else None,
                    "task_ok": task_ok,
                    "route_ok": route_ok,
                    "safety_failure": safety_failed,
                }
            )
        total = len(cases)
        return GoldenMetrics(
            case_count=total,
            task_type_accuracy=task_correct / total,
            clarify_precision=tp / (tp + fp) if tp + fp else 1.0,
            clarify_recall=tp / (tp + fn) if tp + fn else 1.0,
            over_clarify_count=fp,
            under_clarify_count=fn,
            route_accuracy=route_correct / total,
            hard_safety_failure=hard_failure,
            average_questions=questions / total,
            cases=tuple(reports),
        )
