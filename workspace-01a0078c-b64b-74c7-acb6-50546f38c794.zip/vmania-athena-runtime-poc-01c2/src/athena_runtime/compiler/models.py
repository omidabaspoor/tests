from enum import StrEnum
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator


class SlotStatus(StrEnum):
    EXPLICIT = "explicit"
    INFERRED = "inferred"
    DEFAULTED = "defaulted"
    UNKNOWN = "unknown"
    CONFLICTING = "conflicting"


class RequiredLevel(StrEnum):
    HARD = "hard"
    QUALITY = "quality"
    INFERABLE = "inferable"
    OPTIONAL = "optional"


class Slot(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")
    value: Any = None
    status: SlotStatus
    source: str | None = None
    confidence: float | None = Field(default=None, ge=0, le=1)
    required_level: RequiredLevel

    @model_validator(mode="after")
    def validate_provenance(self) -> "Slot":
        if self.status is SlotStatus.EXPLICIT and self.source != "message":
            raise ValueError("explicit slots require message source")
        if self.status is SlotStatus.INFERRED and (not self.source or self.confidence is None):
            raise ValueError("inferred slots require source and confidence")
        if self.status is SlotStatus.DEFAULTED and not self.source:
            raise ValueError("defaults require policy source")
        return self


class FreshnessClass(StrEnum):
    STABLE = "stable"
    PERIODIC = "periodic"
    DAILY = "daily"
    LIVE = "live"


class RiskLevel(StrEnum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


class DecisionKind(StrEnum):
    DIRECT = "DIRECT"
    CLARIFY = "CLARIFY"
    RESEARCH = "RESEARCH"
    TOOL = "TOOL"
    COMPLEX_RUN = "COMPLEX_RUN"
    BLOCK = "BLOCK"


class RouteTier(StrEnum):
    R0 = "R0"
    R1 = "R1"
    R2 = "R2"
    R3 = "R3"
    R4 = "R4"


class NamedSlot(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")
    name: str
    slot: Slot


class Brief(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")
    version: str = "brief-0.1"
    task_type: Slot
    goal: Slot
    output_type: Slot
    audience: Slot
    subject: Slot
    platform: Slot
    tone: Slot
    constraints: Slot
    attachments: Slot
    freshness_requirement: Slot
    risk_level: Slot
    success_criteria: Slot
    forbidden_items: Slot
    additional_slots: tuple[NamedSlot, ...] = ()


class Question(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")
    question_id: str
    slot_name: str
    text: str
    options: tuple[str, ...] = Field(min_length=2, max_length=4)
    recommended_option: str
    allow_other: bool = True
    allow_delegate: bool = True

    @model_validator(mode="after")
    def recommended_is_real(self) -> "Question":
        if self.recommended_option not in self.options:
            raise ValueError("recommended option must exist")
        return self


class ClarificationState(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")
    asked_question_ids: frozenset[str] = frozenset()
    question_count: int = Field(default=0, ge=0, le=3)
    delegated: bool = False


class PipelineDecision(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")
    decision: DecisionKind
    reason_code: str
    brief_version: str
    missing_hard_slots: tuple[str, ...]
    required_capability: str
    quality_floor: Literal["deterministic", "draft", "standard", "high"]


class RouteDecision(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")
    tier: RouteTier
    reason_code: str
    warning_policy: str | None = None


class CompileResult(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")
    brief: Brief
    question: Question | None
    decision: PipelineDecision
    route: RouteDecision
