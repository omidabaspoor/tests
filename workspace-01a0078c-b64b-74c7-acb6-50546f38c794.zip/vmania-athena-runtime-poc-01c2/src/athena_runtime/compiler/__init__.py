"""Deterministic requirement compiler, clarifier, router, and fake provider."""
