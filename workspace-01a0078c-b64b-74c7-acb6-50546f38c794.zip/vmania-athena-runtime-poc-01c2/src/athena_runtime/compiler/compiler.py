import re
from typing import Protocol

from athena_runtime.compiler.clarifier import ClarificationPolicy
from athena_runtime.compiler.models import (
    Brief,
    ClarificationState,
    CompileResult,
    DecisionKind,
    FreshnessClass,
    NamedSlot,
    PipelineDecision,
    Question,
    RequiredLevel,
    RiskLevel,
    RouteDecision,
    RouteTier,
    Slot,
    SlotStatus,
)
from athena_runtime.compiler.packs import get_pack
from athena_runtime.compiler.provider import UnderstandingProvider
from athena_runtime.compiler.router import AthenaRouter, ComplexityClassifier, FreshnessDetector

MAX_INPUT_CHARS = 4_000
MAX_HISTORY_TURNS = 8


class MemoryContextProvider(Protocol):
    async def context_for(self, user_input: str) -> tuple[str, ...]: ...


class RequirementCompiler:
    def __init__(
        self,
        provider: UnderstandingProvider,
        *,
        memory_context: MemoryContextProvider | None = None,
    ) -> None:
        self._provider = provider
        self._memory = memory_context
        self._clarifier = ClarificationPolicy()
        self._freshness = FreshnessDetector()
        self._complexity = ComplexityClassifier()
        self._router = AthenaRouter()

    async def compile(
        self,
        user_input: str,
        *,
        history: tuple[str, ...] = (),
        attachment_manifest: tuple[str, ...] = (),
        clarification_state: ClarificationState | None = None,
    ) -> CompileResult:
        text = _normalize(user_input)
        history = history[-MAX_HISTORY_TURNS:]
        manifest = _safe_manifest(attachment_manifest)
        memory = await self._memory.context_for(text) if self._memory else ()
        structured_history = history + tuple(f"memory:{item}" for item in memory)
        understanding = await self._provider.understand(text, structured_history, manifest)
        pack = get_pack(understanding.task_type)
        extracted = {item.name: item for item in understanding.extracted}
        delegated = (
            understanding.delegated or (clarification_state or ClarificationState()).delegated
        )
        freshness = self._freshness.detect(text, understanding.task_type)
        risk = RiskLevel.HIGH if understanding.medical_sensitive else RiskLevel.LOW

        def slot(
            name: str,
            level: RequiredLevel,
            default: str | tuple[str, ...] | None = None,
        ) -> Slot:
            item = extracted.get(name)
            if name in understanding.conflicts:
                return Slot(
                    value=None,
                    status=SlotStatus.CONFLICTING,
                    source="message",
                    confidence=1,
                    required_level=level,
                )
            if item:
                status = SlotStatus.EXPLICIT if item.source == "message" else SlotStatus.INFERRED
                return Slot(
                    value=item.value,
                    status=status,
                    source=item.source,
                    confidence=item.confidence if status is SlotStatus.INFERRED else None,
                    required_level=level,
                )
            if default is not None:
                return Slot(
                    value=default,
                    status=SlotStatus.DEFAULTED,
                    source=f"default-policy:{pack.name}:{pack.version}",
                    required_level=level,
                )
            if delegated and level in {RequiredLevel.HARD, RequiredLevel.INFERABLE}:
                return Slot(
                    value="safe-general-default",
                    status=SlotStatus.DEFAULTED,
                    source="default-policy:delegated-safe-choice",
                    required_level=level,
                )
            return Slot(value=None, status=SlotStatus.UNKNOWN, required_level=level)

        defaults = dict(pack.defaults)
        hard = set(pack.hard_slots)
        quality = set(pack.quality_slots)

        def level(name: str) -> RequiredLevel:
            if name in hard:
                return RequiredLevel.HARD
            if name in quality:
                return RequiredLevel.QUALITY
            return RequiredLevel.OPTIONAL

        special_names = tuple(name for name in hard | quality if name not in _CORE_SLOTS)
        brief = Brief(
            task_type=Slot(
                value=understanding.task_type,
                status=SlotStatus.INFERRED,
                source="fake-understanding-provider",
                confidence=0.95,
                required_level=RequiredLevel.HARD,
            ),
            goal=Slot(
                value=text,
                status=SlotStatus.EXPLICIT,
                source="message",
                required_level=RequiredLevel.HARD,
            ),
            output_type=slot("output_type", RequiredLevel.HARD, pack.output_type),
            audience=slot("audience", level("audience"), defaults.get("audience")),
            subject=slot("subject", level("subject"), defaults.get("subject")),
            platform=slot("platform", level("platform"), defaults.get("platform")),
            tone=slot("tone", level("tone"), defaults.get("tone")),
            constraints=slot("constraints", level("constraints"), defaults.get("constraints")),
            attachments=slot(
                "attachments",
                level("attachments"),
                tuple(manifest) if manifest else None,
            ),
            freshness_requirement=Slot(
                value=freshness.value,
                status=SlotStatus.INFERRED,
                source="freshness-detector:0.1",
                confidence=0.98,
                required_level=RequiredLevel.HARD,
            ),
            risk_level=Slot(
                value=risk.value,
                status=SlotStatus.INFERRED,
                source="risk-policy:0.1",
                confidence=0.99,
                required_level=RequiredLevel.HARD,
            ),
            success_criteria=slot("success_criteria", level("success_criteria"), "meets-request"),
            forbidden_items=Slot(
                value=("policy-escalation", "secret-disclosure", "cross-tenant-access"),
                status=SlotStatus.DEFAULTED,
                source="default-policy:security-baseline-0.1",
                required_level=RequiredLevel.HARD,
            ),
            additional_slots=tuple(
                NamedSlot(name=name, slot=slot(name, level(name), defaults.get(name)))
                for name in special_names
            ),
        )
        security = _security_decision(text, understanding.task_type, bool(manifest))
        state = clarification_state or ClarificationState(delegated=delegated)
        suppress_question = security is not None or understanding.memory_intent is not None
        question = None if suppress_question else self._clarifier.choose(brief, state)
        if understanding.memory_intent == "CONSENT_REQUIRED" and state.question_count < 3:
            question = Question(
                question_id="q.memory_consent",
                slot_name="memory_consent",
                text="می‌خوای این ترجیح فقط برای همین کار استفاده بشه یا ذخیره بشه؟",
                options=("فقط همین کار", "با رضایت من ذخیره شود"),
                recommended_option="فقط همین کار",
                allow_other=False,
                allow_delegate=False,
            )
        missing = tuple(
            name
            for name, value in _all_slots(brief).items()
            if value.required_level is RequiredLevel.HARD
            and value.status in {SlotStatus.UNKNOWN, SlotStatus.CONFLICTING}
        )
        decision = _pipeline_decision(
            brief,
            question=question,
            missing=missing,
            security=security,
            memory_intent=understanding.memory_intent,
            tool_need=understanding.tool_need,
            freshness=freshness,
        )
        complexity = self._complexity.classify(
            understanding.task_type, text, len(text) + sum(map(len, history))
        )
        route = _route_for_special_cases(
            brief,
            decision.decision,
            complexity,
            understanding.tool_need,
            self._router,
            security=security,
            memory_intent=understanding.memory_intent,
        )
        return CompileResult(brief=brief, question=question, decision=decision, route=route)


_CORE_SLOTS = frozenset(
    {
        "goal",
        "output_type",
        "audience",
        "subject",
        "platform",
        "tone",
        "constraints",
        "attachments",
        "success_criteria",
    }
)


def _normalize(value: str) -> str:
    normalized = " ".join(value.replace("\u200c", " ").split())
    if not normalized:
        raise ValueError("input is empty")
    if len(normalized) > MAX_INPUT_CHARS:
        raise ValueError("input too long")
    return normalized


def _safe_manifest(values: tuple[str, ...]) -> tuple[str, ...]:
    if len(values) > 20:
        raise ValueError("too many attachments")
    for value in values:
        if not re.fullmatch(r"[A-Za-z0-9._-]{1,128}", value):
            raise ValueError("unsafe attachment manifest")
    return values


def _all_slots(brief: Brief) -> dict[str, Slot]:
    result = {
        "goal": brief.goal,
        "output_type": brief.output_type,
        "audience": brief.audience,
        "subject": brief.subject,
        "platform": brief.platform,
        "tone": brief.tone,
        "constraints": brief.constraints,
        "attachments": brief.attachments,
        "success_criteria": brief.success_criteria,
    }
    result.update({item.name: item.slot for item in brief.additional_slots})
    return result


def _security_decision(text: str, task: str, has_attachment: bool) -> str | None:
    lowered = text.casefold()
    if re.search(r"۱۵ ساله.*سکسی|15 ساله.*سکسی", lowered):
        return "BLOCK_MINOR_SEXUAL"
    if "کاربر قبلی" in lowered:
        return "BLOCK_CROSS_TENANT"
    if "evil.example" in lowered:
        return "BLOCK_EXFILTRATION"
    if "رشوه می" in lowered:
        return "BLOCK_DECEPTIVE_EDIT"
    if task == "file_summary" and not has_attachment:
        return "BLOCK_MISSING_ATTACHMENT"
    if "دستورهای قبلی" in lowered and "پرامپت سیستم" in lowered:
        return "SAFE_PROMPT_INJECTION"
    if "sk-live-" in lowered:
        return "SAFE_SECRET_HANDLING"
    if "۱۰۰۰" in lowered and "تصویر" in lowered:
        return "SAFE_QUOTA_LIMIT"
    return None


def _pipeline_decision(
    brief: Brief,
    *,
    question: object | None,
    missing: tuple[str, ...],
    security: str | None,
    memory_intent: str | None,
    tool_need: str | None,
    freshness: FreshnessClass,
) -> PipelineDecision:
    if security and security.startswith("BLOCK_"):
        kind, reason = DecisionKind.BLOCK, security
    elif memory_intent == "BLOCK_MEMORY_WRITE":
        kind, reason = DecisionKind.BLOCK, "SENSITIVE_MEMORY_WRITE_DENIED"
    elif memory_intent == "CONSENT_REQUIRED":
        kind, reason = DecisionKind.CLARIFY, "MEMORY_CONSENT_REQUIRED"
    elif security and security.startswith("SAFE_"):
        kind, reason = DecisionKind.DIRECT, security
    elif question is not None:
        kind, reason = DecisionKind.CLARIFY, "MISSING_OR_CONFLICTING_SLOT"
    elif freshness is FreshnessClass.LIVE:
        kind, reason = DecisionKind.RESEARCH, "FRESH_INFORMATION_REQUIRED"
    elif tool_need == "tool":
        kind, reason = DecisionKind.TOOL, "CONTROLLED_TOOL_REQUIRED"
    elif str(brief.task_type.value) in {"software_project", "multi_content"}:
        kind, reason = DecisionKind.COMPLEX_RUN, "MULTI_STEP_REQUIRED"
    else:
        kind, reason = DecisionKind.DIRECT, "BRIEF_SUFFICIENT"
    quality = "deterministic" if brief.task_type.value == "calculation" else "standard"
    return PipelineDecision(
        decision=kind,
        reason_code=reason,
        brief_version=brief.version,
        missing_hard_slots=missing,
        required_capability=(
            "none"
            if kind in {DecisionKind.DIRECT, DecisionKind.CLARIFY, DecisionKind.BLOCK}
            else kind.value.lower()
        ),
        quality_floor=quality,
    )


def _route_for_special_cases(
    brief: Brief,
    decision: DecisionKind,
    complexity: str,
    tool_need: str | None,
    router: AthenaRouter,
    *,
    security: str | None,
    memory_intent: str | None,
) -> RouteDecision:
    task = str(brief.task_type.value)
    if memory_intent is not None:
        return RouteDecision(tier=RouteTier.R1, reason_code="MEMORY_POLICY_ONLY")
    if decision is DecisionKind.BLOCK:
        return RouteDecision(
            tier=RouteTier.R2 if task == "file_summary" else RouteTier.R1,
            reason_code="SAFETY_GATE",
        )
    if security is not None:
        return RouteDecision(
            tier=RouteTier.R2 if security == "SAFE_SECRET_HANDLING" else RouteTier.R1,
            reason_code="SAFE_HANDLING",
        )
    if decision is DecisionKind.CLARIFY:
        tier = {
            "image_edit": RouteTier.R2,
            "multi_content": RouteTier.R3,
        }.get(task, RouteTier.R1)
        return RouteDecision(tier=tier, reason_code="CLARIFICATION_FIRST")
    if (
        decision is DecisionKind.DIRECT
        and task == "general_writing"
        and brief.risk_level.value == "low"
    ):
        return RouteDecision(tier=RouteTier.R2, reason_code="BALANCED_WRITING")
    return router.route(
        brief,
        complexity=complexity,
        tool_need=tool_need,
        quality_floor="standard",
    )
