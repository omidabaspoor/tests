# Requirement Compiler / Clarifier / Athena Router — 01D

## Scope

این مرحله فقط Domain Contract فهم درخواست را می‌سازد. مدل، Search، Tool، Worker، Memory Store، Content Generator، API route و persistence جدید وجود ندارند.

## Pipeline

```text
bounded normalization
→ Fake Understanding Provider (structured only)
→ explicit/history/memory-context merge
→ versioned Slot Pack defaults
→ missing/conflict detection
→ immutable Brief
→ one-question Clarification Policy
→ freshness + complexity
→ Pipeline Decision
→ model-agnostic Athena Route
```

متن کاربر Data است. Provider اجازه تغییر security policy، capability یا route را ندارد؛ Compiler security checks مستقل دارد. Input حداکثر 4000 کاراکتر، History حداکثر 8 turn و attachment فقط manifest با نام امن و حداکثر 20 entry است. هیچ فایل واقعی خوانده نمی‌شود.

## Brief and provenance

هر Slot شامل value، status، source، confidence و required_level است. Pydantic frozen snapshot استفاده شده و collectionهای Brief tuple/frozenset هستند. Explicit فقط source=message، inferred الزاماً source/confidence و default الزاماً نام policy دارد. Conflict به‌صورت `conflicting` باقی می‌ماند و مخفیانه resolve نمی‌شود.

Status: explicit, inferred, defaulted, unknown, conflicting. Required level: hard, quality, inferable, optional.

## Clarification

Policy فقط hard missing یا conflict مؤثر را می‌پرسد. Priority ثابت است و در هر compile حداکثر یک Question بازمی‌گردد. Questionها 2–4 option واقعی، recommended معتبر، delegate/other flags، شناسه پایدار و slot target دارند. State سقف 3، asked IDs و delegate را نگه می‌دارد. Optional slot سؤال اجباری نمی‌سازد.

## Decisions and routes

Pipeline decision فقط DIRECT, CLARIFY, RESEARCH, TOOL, COMPLEX_RUN, BLOCK است و reason code، brief version، missing hard slots، capability و quality floor دارد.

Route فقط R0–R4 است و نام مدل ندارد. R0 deterministic math، R1 transform/policy/clarification، R2 balanced output، R3 sensitive/live/tool/multi-step و R4 فقط candidate flag آینده است. Medical حداقل R3 با warning و live research حداقل R3 است.

## Provider and memory boundary

`UnderstandingProvider` Protocol vendor-neutral است. Fake provider deterministic، offline و fixture-overridable است. Memory فقط `MemoryContextProvider` read-context interface دارد؛ Store یا write path ساخته نشده است. Sensitive/anonymous/instruction memory cases فقط policy decision تولید می‌کنند.

## Security

Prompt injection نمی‌تواند forbidden items یا policy را تغییر دهد. Minor sexualization، exfiltration، deceptive real-person edit و cross-tenant terminal request block می‌شوند. Secret debugging safe-handled است و raw secret در Brief outputهای گزارش‌شده درج نمی‌شود. Tool capability توسط Provider قابل افزایش نیست.
