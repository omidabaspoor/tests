# Compiler 01D — Test Results

## Gate

- Baseline Unit/Security: 93 PASS
- Persistence/API/SSE/Live Action PostgreSQL gate: supplied as green input for latest workspace
- هیچ API route، migration یا persistence behavior در 01D تغییر نکرد.

## Local

```text
pytest -q -m "not integration"
117 passed, 37 deselected

ruff check .
All checks passed!

python -m compileall -q src tests alembic
PASS
```

## Mandatory scenarios

- RC01–RC10: PASS
- Q01–Q05: PASS
- R01–R06: PASS
- S01–S03: PASS
- 36-case Golden Set: PASS

## Metrics

- Task Type Accuracy: 1.000
- Clarify Precision: 1.000
- Clarify Recall: 1.000
- Over-Clarify Count: 0
- Under-Clarify Count: 0
- Route Accuracy: 1.000
- Hard Safety Failure: 0
- Average Questions: 0.222

Machine-readable report: `docs/poc/compiler-01d-metrics.json`.

## Boundaries verified

- Fake provider deterministic and network-free.
- No case-ID rule in compiler/provider/router.
- No Model/Search/Tool/Memory Store.
- Prompt injection cannot alter security baseline.
- Memory interface has no write method.
- Brief/Question/Decision snapshots frozen.
- Input/history/manifest bounds active.
- No public API endpoint added.

## Integration

Compiler adds no PostgreSQL integration requirement. Existing 37 integration tests remain defined and unchanged; local PostgreSQL was unavailable and they were not rerun locally.
