# Slot Pack Registry 01D

Registry version اولیه `0.1` و کاملاً data-driven است. هر Pack hard/quality slots، defaults، allowed questions، output type، freshness و baseline route دارد.

| Pack | Hard | Quality | Defaults | Output | Freshness | Baseline |
|---|---|---|---|---|---|---|
| caption | subject | platform,tone,audience | instagram,friendly | caption | stable | R2 |
| social_content | subject | platform,audience | instagram | social_content | stable | R2 |
| reel_scenario | subject | audience,tone | engaging | reel_scenario | stable | R2 |
| ad_copy | subject,audience | platform,constraints | — | ad_copy | periodic | R2 |
| general_writing | subject | tone,audience | neutral | text | stable | R1 |
| instagram_audit | evidence | goal | — | audit | daily | R3 |
| image_generation | subject | tone,constraints | — | image | stable | R3 |
| image_edit | edit_target | constraints | — | edited_image | stable | R3 |
| file_summary | attachments | output_type | summary | summary | stable | R2 |
| research | subject | success_criteria | — | research_report | live | R3 |

Packهای داخلی مکمل برای calculation، rewrite، file assembly، software project، multi-content و memory-policy نیز در همان Registry تعریف شده‌اند؛ ruleها بر اساس Case ID نیستند.

Default provenance به شکل `default-policy:<pack>:<version>` ثبت می‌شود. Delegate از `default-policy:delegated-safe-choice` استفاده می‌کند. سؤال فقط از allowed targetهای Registry/Question Registry انتخاب می‌شود.
