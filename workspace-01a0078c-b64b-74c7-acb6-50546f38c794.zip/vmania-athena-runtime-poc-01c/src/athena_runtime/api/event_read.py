from typing import Any
from uuid import UUID

from sqlalchemy import select

from athena_runtime.api.contracts import PublicEvent, RunView
from athena_runtime.api.live_action import LiveActionPayload
from athena_runtime.persistence.context import WorkspaceContext, WorkspaceTransactionManager
from athena_runtime.persistence.schema import run_events, runs
from athena_runtime.runs import RunState

DEFAULT_EVENT_LIMIT = 50
MAX_EVENT_LIMIT = 100


class PostgresEventReadRepository:
    def __init__(self, transactions: WorkspaceTransactionManager) -> None:
        self._transactions = transactions

    async def list_after(
        self,
        context: WorkspaceContext,
        run_id: UUID,
        after_sequence: int,
        *,
        limit: int = DEFAULT_EVENT_LIMIT,
    ) -> tuple[PublicEvent, ...]:
        if not 1 <= limit <= MAX_EVENT_LIMIT:
            raise ValueError("event limit outside allowed range")
        async with self._transactions.transaction(context) as connection:
            rows = (
                (
                    await connection.execute(
                        select(run_events)
                        .where(
                            run_events.c.workspace_id == context.workspace_id,
                            run_events.c.run_id == run_id,
                            run_events.c.sequence > after_sequence,
                            run_events.c.visibility == "user",
                        )
                        .order_by(run_events.c.sequence)
                        .limit(limit)
                    )
                )
                .mappings()
                .all()
            )
        return tuple(
            PublicEvent(
                row["id"],
                row["run_id"],
                row["sequence"],
                row["event_type"],
                row["occurred_at"],
                row["created_at"],
                _safe_public_payload(row["event_type"], row["payload"]),
            )
            for row in rows
        )

    async def current_run(self, context: WorkspaceContext, run_id: UUID) -> RunView | None:
        async with self._transactions.transaction(context) as connection:
            row = (
                await connection.execute(
                    select(runs.c.id, runs.c.state, runs.c.version).where(
                        runs.c.workspace_id == context.workspace_id,
                        runs.c.id == run_id,
                    )
                )
            ).one_or_none()
        if row is None:
            return None
        return RunView(row.id, RunState(row.state), row.version)


def _safe_public_payload(event_type: str, payload: dict[str, Any]) -> dict[str, Any]:
    if event_type == "live_action.updated":
        return LiveActionPayload.model_validate(payload).model_dump(mode="json")
    result: dict[str, Any] = {}
    for key in ("progress_current", "progress_total"):
        value = payload.get(key)
        if isinstance(value, int) and not isinstance(value, bool) and value >= 0:
            result[key] = value
    if isinstance(payload.get("countable"), bool):
        result["countable"] = payload["countable"]
    code = payload.get("code")
    if isinstance(code, str) and 0 < len(code) <= 64 and code.replace("_", "").isalnum():
        result["code"] = code
    return result
