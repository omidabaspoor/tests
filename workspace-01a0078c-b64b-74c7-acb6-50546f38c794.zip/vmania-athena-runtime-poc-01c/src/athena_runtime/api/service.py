import hashlib
import json
from datetime import UTC, datetime, timedelta
from uuid import UUID, uuid4

from sqlalchemy import insert, select, update
from sqlalchemy.dialects.postgresql import insert as postgresql_insert

from athena_runtime.api.contracts import AuthContext, RunView
from athena_runtime.api.errors import IDEMPOTENCY_CONFLICT, RUN_NOT_STOPPABLE, ApiError
from athena_runtime.errors import InvalidTransition
from athena_runtime.persistence.context import WorkspaceTransactionManager
from athena_runtime.persistence.errors import OptimisticLockError
from athena_runtime.persistence.repositories import RunStore, RunTransitionService
from athena_runtime.persistence.schema import api_idempotency_records, runs
from athena_runtime.runs import RunState


class PostgresRunApiService:
    def __init__(
        self,
        runs_store: RunStore,
        transitions: RunTransitionService,
        transactions: WorkspaceTransactionManager,
        *,
        max_steps: int = 12,
        max_cost_microunits: int = 100_000,
        deadline: timedelta = timedelta(minutes=10),
    ) -> None:
        self._runs = runs_store
        self._transitions = transitions
        self._transactions = transactions
        self._max_steps = max_steps
        self._max_cost = max_cost_microunits
        self._deadline = deadline

    async def create_run(self, auth: AuthContext, goal: str, idempotency_key: str) -> RunView:
        request_hash = hashlib.sha256(
            json.dumps(
                {"goal": goal}, ensure_ascii=False, sort_keys=True, separators=(",", ":")
            ).encode()
        ).hexdigest()
        endpoint = "POST:/v1/runs"
        async with self._transactions.transaction(auth.workspace) as connection:
            record_id = uuid4()
            inserted = await connection.scalar(
                postgresql_insert(api_idempotency_records)
                .values(
                    id=record_id,
                    workspace_id=auth.workspace.workspace_id,
                    endpoint=endpoint,
                    idempotency_key=idempotency_key,
                    request_hash=request_hash,
                    status="pending",
                    expires_at=datetime.now(UTC) + timedelta(hours=24),
                )
                .on_conflict_do_nothing(
                    index_elements=[
                        api_idempotency_records.c.workspace_id,
                        api_idempotency_records.c.endpoint,
                        api_idempotency_records.c.idempotency_key,
                    ]
                )
                .returning(api_idempotency_records.c.id)
            )
            if inserted is None:
                existing = (
                    (
                        await connection.execute(
                            select(api_idempotency_records)
                            .where(
                                api_idempotency_records.c.workspace_id
                                == auth.workspace.workspace_id,
                                api_idempotency_records.c.endpoint == endpoint,
                                api_idempotency_records.c.idempotency_key == idempotency_key,
                            )
                            .with_for_update()
                        )
                    )
                    .mappings()
                    .one()
                )
                if existing["request_hash"] != request_hash:
                    raise IDEMPOTENCY_CONFLICT
                if existing["status"] != "completed" or existing["resource_id"] is None:
                    raise ApiError(
                        409,
                        "IDEMPOTENCY_IN_PROGRESS",
                        "درخواست مشابه در حال پردازش است.",
                        retryable=True,
                    )
                return RunView(existing["resource_id"], RunState.CREATED, 0)

            run_id = uuid4()
            await connection.execute(
                insert(runs).values(
                    id=run_id,
                    workspace_id=auth.workspace.workspace_id,
                    goal=goal,
                    state=RunState.CREATED.value,
                    version=0,
                    max_cost_microunits=self._max_cost,
                    max_steps=self._max_steps,
                    deadline_at=datetime.now(UTC) + self._deadline,
                )
            )
            response_body = {
                "run_id": str(run_id),
                "status": "created",
                "events_url": f"/v1/runs/{run_id}/events",
            }
            await connection.execute(
                update(api_idempotency_records)
                .where(api_idempotency_records.c.id == record_id)
                .values(
                    status="completed",
                    response_status=201,
                    response_body=response_body,
                    resource_id=run_id,
                )
            )
            return RunView(run_id, RunState.CREATED, 0)

    async def get_run(self, auth: AuthContext, run_id: UUID) -> RunView | None:
        snapshot = await self._runs.load(auth.workspace, run_id)
        if snapshot is None:
            return None
        return RunView(run_id, snapshot.run.state, snapshot.version)

    async def stop_run(self, auth: AuthContext, run_id: UUID) -> RunView | None:
        snapshot = await self._runs.load(auth.workspace, run_id)
        if snapshot is None:
            return None
        if snapshot.run.state is RunState.STOPPED:
            return RunView(run_id, snapshot.run.state, snapshot.version)
        if snapshot.run.state in {
            RunState.COMPLETED,
            RunState.FAILED,
            RunState.EXPIRED,
            RunState.BLOCKED,
        }:
            raise RUN_NOT_STOPPABLE
        try:
            version = await self._transitions.transition(
                auth.workspace,
                run_id,
                expected_version=snapshot.version,
                to_state=RunState.STOPPED,
            )
        except OptimisticLockError as exc:
            current = await self._runs.load(auth.workspace, run_id)
            if current is not None and current.run.state is RunState.STOPPED:
                return RunView(run_id, RunState.STOPPED, current.version)
            if current is not None and current.run.state in {
                RunState.COMPLETED,
                RunState.FAILED,
                RunState.EXPIRED,
                RunState.BLOCKED,
            }:
                raise RUN_NOT_STOPPABLE from exc
            raise ApiError(
                409,
                "RUN_STATE_CONFLICT",
                "وضعیت کار تغییر کرده است.",
                retryable=True,
                action="retry",
            ) from exc
        except InvalidTransition as exc:
            raise ApiError(
                409, "RUN_STATE_CONFLICT", "وضعیت کار تغییر کرده است.", retryable=True
            ) from exc
        return RunView(run_id, RunState.STOPPED, version)
