from datetime import UTC, datetime
from uuid import UUID

from sqlalchemy import select

from athena_runtime.api.live_action import LiveActionService
from athena_runtime.errors import InvalidTransition
from athena_runtime.persistence.context import WorkspaceContext, WorkspaceTransactionManager
from athena_runtime.persistence.errors import OptimisticLockError, RecordNotFoundError
from athena_runtime.persistence.repositories import RunStore, RunTransitionService
from athena_runtime.persistence.schema import run_events
from athena_runtime.runs import RunState


def validate_completion_markers(markers: set[str]) -> None:
    if "quality.decision" not in markers:
        raise ValueError("quality marker missing")
    if not markers & {"artifact.ready", "artifact.not_required"}:
        raise ValueError("artifact marker missing")
    if "cost.status" not in markers:
        raise ValueError("cost marker missing")


class RunCompletionService:
    def __init__(
        self,
        transactions: WorkspaceTransactionManager,
        runs: RunStore,
        transitions: RunTransitionService,
        live_actions: LiveActionService,
    ) -> None:
        self._transactions = transactions
        self._runs = runs
        self._transitions = transitions
        self._live_actions = live_actions

    async def complete(self, context: WorkspaceContext, run_id: UUID) -> RunState:
        snapshot = await self._runs.load(context, run_id)
        if snapshot is None:
            raise RecordNotFoundError("run not visible")
        if snapshot.run.state is RunState.COMPLETED:
            await self._publish_completed(context, run_id)
            return RunState.COMPLETED
        async with self._transactions.transaction(context) as connection:
            marker_rows = await connection.scalars(
                select(run_events.c.event_type).where(
                    run_events.c.workspace_id == context.workspace_id,
                    run_events.c.run_id == run_id,
                    run_events.c.event_type.in_(
                        (
                            "quality.decision",
                            "artifact.ready",
                            "artifact.not_required",
                            "cost.status",
                        )
                    ),
                )
            )
            markers = set(marker_rows)
        validate_completion_markers(markers)
        try:
            await self._transitions.transition(
                context,
                run_id,
                expected_version=snapshot.version,
                to_state=RunState.COMPLETED,
            )
        except OptimisticLockError:
            current = await self._runs.load(context, run_id)
            if current is None or current.run.state is not RunState.COMPLETED:
                raise
        except InvalidTransition:
            current = await self._runs.load(context, run_id)
            if current is None or current.run.state is not RunState.COMPLETED:
                raise
        await self._publish_completed(context, run_id)
        return RunState.COMPLETED

    async def _publish_completed(self, context: WorkspaceContext, run_id: UUID) -> None:
        await self._live_actions.publish(
            context,
            run_id,
            source_event_type="run.completed",
            source_payload={},
            occurred_at=datetime.now(UTC),
        )
