from dataclasses import dataclass
from datetime import datetime
from typing import Any, Protocol
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field

from athena_runtime.persistence.context import WorkspaceContext
from athena_runtime.runs import RunState


class CreateRunBody(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)
    goal: str = Field(min_length=3, max_length=500)


class RunResponse(BaseModel):
    run_id: UUID
    status: RunState
    events_url: str


class ErrorBody(BaseModel):
    code: str
    message: str
    retryable: bool
    action: str | None = None
    request_id: str


class ErrorResponse(BaseModel):
    error: ErrorBody


@dataclass(frozen=True, slots=True)
class AuthContext:
    principal_id: str
    workspace: WorkspaceContext


@dataclass(frozen=True, slots=True)
class RunView:
    run_id: UUID
    state: RunState
    version: int


@dataclass(frozen=True, slots=True)
class PublicEvent:
    event_id: UUID
    run_id: UUID
    sequence: int
    event_type: str
    occurred_at: datetime
    recorded_at: datetime
    payload: dict[str, Any]


class RunApiService(Protocol):
    async def create_run(self, auth: AuthContext, goal: str, idempotency_key: str) -> RunView: ...

    async def get_run(self, auth: AuthContext, run_id: UUID) -> RunView | None: ...

    async def stop_run(self, auth: AuthContext, run_id: UUID) -> RunView | None: ...


class EventReader(Protocol):
    async def list_after(
        self,
        context: WorkspaceContext,
        run_id: UUID,
        after_sequence: int,
        *,
        limit: int,
    ) -> tuple[PublicEvent, ...]: ...

    async def current_run(self, context: WorkspaceContext, run_id: UUID) -> RunView | None: ...
