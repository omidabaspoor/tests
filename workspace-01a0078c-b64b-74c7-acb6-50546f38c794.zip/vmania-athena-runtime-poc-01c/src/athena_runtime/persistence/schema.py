from sqlalchemy import (
    BigInteger,
    CheckConstraint,
    Column,
    DateTime,
    ForeignKeyConstraint,
    Index,
    Integer,
    MetaData,
    String,
    Table,
    UniqueConstraint,
    text,
)
from sqlalchemy.dialects.postgresql import JSONB, UUID

MAX_PAYLOAD_BYTES = 16_384
MAX_OUTCOME_BYTES = 16_384

NAMING_CONVENTION = {
    "ix": "ix_%(table_name)s_%(column_0_name)s",
    "uq": "uq_%(table_name)s_%(column_0_name)s",
    "ck": "ck_%(table_name)s_%(constraint_name)s",
    "fk": "fk_%(table_name)s_%(column_0_name)s_%(referred_table_name)s",
    "pk": "pk_%(table_name)s",
}
metadata = MetaData(naming_convention=NAMING_CONVENTION, schema="athena")

_uuid_pk = {"primary_key": True, "server_default": text("gen_random_uuid()")}


def _timestamps() -> tuple[Column[object], Column[object]]:
    return (
        Column("created_at", DateTime(timezone=True), nullable=False, server_default=text("now()")),
        Column(
            "updated_at",
            DateTime(timezone=True),
            nullable=False,
            server_default=text("now()"),
        ),
    )


runs = Table(
    "runs",
    metadata,
    Column("id", UUID(as_uuid=True), **_uuid_pk),
    Column("workspace_id", UUID(as_uuid=True), nullable=False),
    Column("goal", String(500), nullable=False),
    Column("state", String(32), nullable=False),
    Column("version", BigInteger, nullable=False, server_default=text("0")),
    Column("max_cost_microunits", BigInteger, nullable=False),
    Column("max_steps", Integer, nullable=False),
    Column("deadline_at", DateTime(timezone=True), nullable=False),
    *_timestamps(),
    UniqueConstraint("workspace_id", "id", name="uq_runs_workspace_id_id"),
    CheckConstraint(
        "state IN ('created','validating','needs_clarification','needs_approval','queued',"
        "'running','quality_check','completed','failed','stopped','expired','blocked')",
        name="run_state",
    ),
    CheckConstraint("version >= 0", name="run_version_nonnegative"),
    CheckConstraint("max_cost_microunits >= 0", name="run_max_cost_nonnegative"),
    CheckConstraint("max_steps > 0 AND max_steps <= 100", name="run_max_steps_range"),
)
Index("ix_runs_workspace_state", runs.c.workspace_id, runs.c.state)

run_events = Table(
    "run_events",
    metadata,
    Column("id", UUID(as_uuid=True), **_uuid_pk),
    Column("workspace_id", UUID(as_uuid=True), nullable=False),
    Column("run_id", UUID(as_uuid=True), nullable=False),
    Column("sequence", BigInteger, nullable=False),
    Column("transition_version", BigInteger),
    Column("event_type", String(64), nullable=False),
    Column("visibility", String(24), nullable=False),
    Column("payload", JSONB, nullable=False),
    Column("occurred_at", DateTime(timezone=True), nullable=False),
    Column("created_at", DateTime(timezone=True), nullable=False, server_default=text("now()")),
    ForeignKeyConstraint(
        ["workspace_id", "run_id"],
        ["athena.runs.workspace_id", "athena.runs.id"],
        ondelete="CASCADE",
        name="fk_run_events_workspace_run",
    ),
    UniqueConstraint("run_id", "sequence", name="uq_run_events_run_sequence"),
    CheckConstraint("sequence > 0", name="run_event_sequence_positive"),
    CheckConstraint(
        "transition_version IS NULL OR transition_version > 0",
        name="run_event_transition_version_positive",
    ),
    CheckConstraint(
        "(event_type = 'run.transitioned' AND transition_version IS NOT NULL) OR "
        "(event_type <> 'run.transitioned' AND transition_version IS NULL)",
        name="run_event_transition_binding",
    ),
    CheckConstraint("visibility IN ('internal','user','audit')", name="run_event_visibility"),
    CheckConstraint(
        f"octet_length(payload::text) <= {MAX_PAYLOAD_BYTES}", name="run_event_payload_size"
    ),
)
Index("ix_run_events_workspace_run", run_events.c.workspace_id, run_events.c.run_id)
Index(
    "uq_run_events_transition_version",
    run_events.c.run_id,
    run_events.c.transition_version,
    unique=True,
    postgresql_where=run_events.c.transition_version.is_not(None),
)

idempotency_records = Table(
    "idempotency_records",
    metadata,
    Column("id", UUID(as_uuid=True), **_uuid_pk),
    Column("workspace_id", UUID(as_uuid=True), nullable=False),
    Column("run_id", UUID(as_uuid=True), nullable=False),
    Column("tool_call_id", String(128), nullable=False),
    Column("operation", String(64), nullable=False),
    Column("args_digest", String(64), nullable=False),
    Column("policy_version", String(64), nullable=False),
    Column("status", String(48), nullable=False),
    Column("outcome", JSONB),
    Column("error", JSONB),
    Column("lease_owner", String(128)),
    Column("lease_expires_at", DateTime(timezone=True)),
    *_timestamps(),
    ForeignKeyConstraint(
        ["workspace_id", "run_id"],
        ["athena.runs.workspace_id", "athena.runs.id"],
        ondelete="CASCADE",
        name="fk_idempotency_workspace_run",
    ),
    UniqueConstraint(
        "workspace_id",
        "run_id",
        "tool_call_id",
        "operation",
        name="uq_idempotency_business_key",
    ),
    CheckConstraint(
        "status IN ('reserved','completed','failed','unknown_reconciliation_required')",
        name="idempotency_status",
    ),
    CheckConstraint(
        f"outcome IS NULL OR octet_length(outcome::text) <= {MAX_OUTCOME_BYTES}",
        name="idempotency_outcome_size",
    ),
    CheckConstraint(
        f"error IS NULL OR octet_length(error::text) <= {MAX_OUTCOME_BYTES}",
        name="idempotency_error_size",
    ),
)
Index(
    "ix_idempotency_workspace_lease",
    idempotency_records.c.workspace_id,
    idempotency_records.c.status,
    idempotency_records.c.lease_expires_at,
)

approvals = Table(
    "approvals",
    metadata,
    Column("id", UUID(as_uuid=True), **_uuid_pk),
    Column("workspace_id", UUID(as_uuid=True), nullable=False),
    Column("run_id", UUID(as_uuid=True), nullable=False),
    Column("tool_call_id", String(128), nullable=False),
    Column("operation", String(64), nullable=False),
    Column("args_digest", String(64), nullable=False),
    Column("decision", String(16), nullable=False),
    Column("expires_at", DateTime(timezone=True), nullable=False),
    Column("consumed_at", DateTime(timezone=True)),
    Column("created_at", DateTime(timezone=True), nullable=False, server_default=text("now()")),
    ForeignKeyConstraint(
        ["workspace_id", "run_id"],
        ["athena.runs.workspace_id", "athena.runs.id"],
        ondelete="CASCADE",
        name="fk_approvals_workspace_run",
    ),
    UniqueConstraint(
        "workspace_id",
        "run_id",
        "tool_call_id",
        "operation",
        "args_digest",
        name="uq_approvals_binding",
    ),
    CheckConstraint("decision IN ('once','deny')", name="approval_decision"),
)
Index("ix_approvals_workspace_run", approvals.c.workspace_id, approvals.c.run_id)

outbox_events = Table(
    "outbox_events",
    metadata,
    Column("id", UUID(as_uuid=True), **_uuid_pk),
    Column("workspace_id", UUID(as_uuid=True), nullable=False),
    Column("aggregate_type", String(64), nullable=False),
    Column("aggregate_id", UUID(as_uuid=True), nullable=False),
    Column("event_type", String(64), nullable=False),
    Column("payload", JSONB, nullable=False),
    Column("created_at", DateTime(timezone=True), nullable=False, server_default=text("now()")),
    Column("published_at", DateTime(timezone=True)),
    Column("attempt_count", Integer, nullable=False, server_default=text("0")),
    Column("last_error_code", String(64)),
    Column("claim_owner", String(128)),
    Column("claim_expires_at", DateTime(timezone=True)),
    ForeignKeyConstraint(
        ["workspace_id", "aggregate_id"],
        ["athena.runs.workspace_id", "athena.runs.id"],
        ondelete="CASCADE",
        name="fk_outbox_workspace_run",
    ),
    CheckConstraint("aggregate_type = 'run'", name="outbox_run_aggregate"),
    CheckConstraint("attempt_count >= 0", name="outbox_attempt_nonnegative"),
    CheckConstraint(
        f"octet_length(payload::text) <= {MAX_PAYLOAD_BYTES}", name="outbox_payload_size"
    ),
)
Index(
    "ix_outbox_unpublished",
    outbox_events.c.workspace_id,
    outbox_events.c.published_at,
    outbox_events.c.created_at,
)

cost_reservations = Table(
    "cost_reservations",
    metadata,
    Column("id", UUID(as_uuid=True), **_uuid_pk),
    Column("workspace_id", UUID(as_uuid=True), nullable=False),
    Column("run_id", UUID(as_uuid=True), nullable=False),
    Column("reserved_microunits", BigInteger, nullable=False),
    Column("settled_microunits", BigInteger, nullable=False, server_default=text("0")),
    Column("status", String(32), nullable=False),
    Column("version", BigInteger, nullable=False, server_default=text("0")),
    *_timestamps(),
    ForeignKeyConstraint(
        ["workspace_id", "run_id"],
        ["athena.runs.workspace_id", "athena.runs.id"],
        ondelete="CASCADE",
        name="fk_cost_reservations_workspace_run",
    ),
    UniqueConstraint("workspace_id", "run_id", name="uq_cost_reservations_workspace_run"),
    CheckConstraint("reserved_microunits >= 0", name="cost_reserved_nonnegative"),
    CheckConstraint("settled_microunits >= 0", name="cost_settled_nonnegative"),
    CheckConstraint(
        "settled_microunits <= reserved_microunits", name="cost_settled_within_reserved"
    ),
    CheckConstraint("version >= 0", name="cost_version_nonnegative"),
    CheckConstraint(
        "status IN ('reserved','partially_settled','settled','released','disputed')",
        name="cost_status",
    ),
)
Index("ix_cost_workspace_run", cost_reservations.c.workspace_id, cost_reservations.c.run_id)

api_idempotency_records = Table(
    "api_idempotency_records",
    metadata,
    Column("id", UUID(as_uuid=True), **_uuid_pk),
    Column("workspace_id", UUID(as_uuid=True), nullable=False),
    Column("endpoint", String(64), nullable=False),
    Column("idempotency_key", String(128), nullable=False),
    Column("request_hash", String(64), nullable=False),
    Column("status", String(16), nullable=False),
    Column("response_status", Integer),
    Column("response_body", JSONB),
    Column("resource_id", UUID(as_uuid=True)),
    Column("created_at", DateTime(timezone=True), nullable=False, server_default=text("now()")),
    Column("expires_at", DateTime(timezone=True), nullable=False),
    ForeignKeyConstraint(
        ["workspace_id", "resource_id"],
        ["athena.runs.workspace_id", "athena.runs.id"],
        ondelete="CASCADE",
        name="fk_api_idempotency_workspace_run",
    ),
    UniqueConstraint("workspace_id", "endpoint", "idempotency_key", name="uq_api_idempotency_key"),
    CheckConstraint("status IN ('pending','completed')", name="api_idempotency_status"),
    CheckConstraint(
        f"response_body IS NULL OR octet_length(response_body::text) <= {MAX_OUTCOME_BYTES}",
        name="api_idempotency_response_size",
    ),
)
Index(
    "ix_api_idempotency_expiry",
    api_idempotency_records.c.workspace_id,
    api_idempotency_records.c.expires_at,
)
