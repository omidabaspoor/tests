import json
from collections.abc import Sequence
from dataclasses import dataclass
from datetime import timedelta
from typing import Any
from uuid import UUID, uuid4

from sqlalchemy import delete, func, insert, or_, select, text, update
from sqlalchemy.dialects.postgresql import insert as postgresql_insert
from sqlalchemy.exc import DBAPIError
from sqlalchemy.ext.asyncio import AsyncConnection

from athena_runtime.approvals import Approval
from athena_runtime.idempotency import (
    IdempotencyKey,
    IdempotencyStore,
    RequestFingerprint,
    Reservation,
    ReservationState,
)
from athena_runtime.persistence.context import (
    TransactionIsolation,
    WorkspaceContext,
    WorkspaceTransactionManager,
)
from athena_runtime.persistence.errors import (
    CostReservationError,
    OptimisticLockError,
    RecordNotFoundError,
)
from athena_runtime.persistence.limits import validate_json_payload, validate_outcome
from athena_runtime.persistence.schema import (
    approvals,
    cost_reservations,
    idempotency_records,
    outbox_events,
    run_events,
    runs,
)
from athena_runtime.runs import Run, RunState, RunTransitionEvent


@dataclass(frozen=True, slots=True)
class RunSnapshot:
    run_id: UUID
    workspace_id: UUID
    version: int
    goal: str
    max_cost_microunits: int
    max_steps: int
    deadline_at: Any
    run: Run


@dataclass(frozen=True, slots=True)
class CostReservationSnapshot:
    reservation_id: UUID
    reserved_microunits: int
    settled_microunits: int
    status: str
    version: int


class RunStore:
    def __init__(self, transactions: WorkspaceTransactionManager) -> None:
        self._transactions = transactions

    async def create(
        self,
        context: WorkspaceContext,
        *,
        run_id: UUID | None = None,
        goal: str = "internal PoC run",
        max_cost_microunits: int,
        max_steps: int,
        deadline_at: Any,
    ) -> UUID:
        if not 3 <= len(goal) <= 500:
            raise ValueError("invalid run goal")
        if max_cost_microunits < 0 or not 0 < max_steps <= 100:
            raise ValueError("invalid run limits")
        identifier = run_id or uuid4()
        async with self._transactions.transaction(context) as connection:
            await connection.execute(
                insert(runs).values(
                    id=identifier,
                    workspace_id=context.workspace_id,
                    goal=goal,
                    state=RunState.CREATED.value,
                    version=0,
                    max_cost_microunits=max_cost_microunits,
                    max_steps=max_steps,
                    deadline_at=deadline_at,
                )
            )
        return identifier

    async def load(self, context: WorkspaceContext, run_id: UUID) -> RunSnapshot | None:
        async with self._transactions.transaction(context) as connection:
            return await self.load_in_transaction(connection, context, run_id)

    async def load_in_transaction(
        self, connection: AsyncConnection, context: WorkspaceContext, run_id: UUID
    ) -> RunSnapshot | None:
        row = (
            (
                await connection.execute(
                    select(runs).where(
                        runs.c.id == run_id, runs.c.workspace_id == context.workspace_id
                    )
                )
            )
            .mappings()
            .one_or_none()
        )
        if row is None:
            return None
        event_rows = (
            (
                await connection.execute(
                    select(run_events)
                    .where(
                        run_events.c.run_id == run_id,
                        run_events.c.workspace_id == context.workspace_id,
                    )
                    .order_by(run_events.c.sequence)
                )
            )
            .mappings()
            .all()
        )
        domain_run = rehydrate_run_from_event_rows(run_id, RunState(row["state"]), event_rows)
        return RunSnapshot(
            run_id,
            context.workspace_id,
            row["version"],
            row["goal"],
            row["max_cost_microunits"],
            row["max_steps"],
            row["deadline_at"],
            domain_run,
        )


@dataclass(frozen=True, slots=True)
class LiveEventReceipt:
    event_id: UUID
    sequence: int


class EventStore:
    async def append_live_event(
        self,
        connection: AsyncConnection,
        context: WorkspaceContext,
        run_id: UUID,
        *,
        event_type: str,
        payload: dict[str, Any],
        occurred_at: Any,
        visibility: str = "internal",
    ) -> LiveEventReceipt:
        safe_payload = validate_json_payload(payload)
        row = (
            await connection.execute(
                text(
                    "SELECT event_id, event_sequence FROM athena.append_run_event("
                    ":run_id, :event_type, :visibility, "
                    "CAST(:payload AS jsonb), :occurred_at)"
                ),
                {
                    "run_id": run_id,
                    "event_type": event_type,
                    "visibility": visibility,
                    "payload": json.dumps(safe_payload, separators=(",", ":")),
                    "occurred_at": occurred_at,
                },
            )
        ).one()
        return LiveEventReceipt(row.event_id, row.event_sequence)


class OutboxStore:
    async def append(
        self,
        connection: AsyncConnection,
        context: WorkspaceContext,
        *,
        aggregate_type: str,
        aggregate_id: UUID,
        event_type: str,
        payload: dict[str, Any],
    ) -> UUID:
        safe_payload = validate_json_payload(payload)
        event_id = uuid4()
        await connection.execute(
            insert(outbox_events).values(
                id=event_id,
                workspace_id=context.workspace_id,
                aggregate_type=aggregate_type,
                aggregate_id=aggregate_id,
                event_type=event_type,
                payload=safe_payload,
            )
        )
        return event_id

    async def claim_batch(
        self,
        connection: AsyncConnection,
        context: WorkspaceContext,
        *,
        owner: str,
        limit: int,
        lease: timedelta,
    ) -> Sequence[dict[str, Any]]:
        if limit <= 0:
            return ()
        rows = (
            (
                await connection.execute(
                    select(outbox_events)
                    .where(
                        outbox_events.c.workspace_id == context.workspace_id,
                        outbox_events.c.published_at.is_(None),
                        or_(
                            outbox_events.c.claim_expires_at.is_(None),
                            outbox_events.c.claim_expires_at <= func.now(),
                        ),
                    )
                    .order_by(outbox_events.c.created_at, outbox_events.c.id)
                    .limit(limit)
                    .with_for_update(skip_locked=True)
                )
            )
            .mappings()
            .all()
        )
        identifiers = [row["id"] for row in rows]
        if not identifiers:
            return ()
        await connection.execute(
            update(outbox_events)
            .where(outbox_events.c.id.in_(identifiers))
            .values(
                claim_owner=owner,
                claim_expires_at=func.now() + lease,
                attempt_count=outbox_events.c.attempt_count + 1,
            )
        )
        return tuple(dict(row) for row in rows)


class RunTransitionService:
    def __init__(self, transactions: WorkspaceTransactionManager) -> None:
        self._transactions = transactions
        self._runs = RunStore(transactions)

    async def transition(
        self,
        context: WorkspaceContext,
        run_id: UUID,
        *,
        expected_version: int,
        to_state: RunState,
        outbox_payload: dict[str, Any] | None = None,
    ) -> int:
        async with self._transactions.transaction(
            context, isolation=TransactionIsolation.REPEATABLE_READ
        ) as connection:
            snapshot = await self._runs.load_in_transaction(connection, context, run_id)
            if snapshot is None:
                raise RecordNotFoundError("run not visible")
            if snapshot.version != expected_version:
                raise OptimisticLockError("stale run version")
            event = snapshot.run.transition(to_state)
            payload = validate_json_payload(
                outbox_payload
                or {
                    "run_id": str(run_id),
                    "transition_version": event.sequence,
                    "to_state": event.to_state.value,
                }
            )
            try:
                new_version = await connection.scalar(
                    text(
                        "SELECT athena.transition_run("
                        ":run_id, :expected_version, :from_state, :to_state, "
                        ":occurred_at, CAST(:outbox_payload AS jsonb))"
                    ),
                    {
                        "run_id": run_id,
                        "expected_version": expected_version,
                        "from_state": event.from_state.value,
                        "to_state": event.to_state.value,
                        "occurred_at": event.occurred_at,
                        "outbox_payload": json.dumps(payload, separators=(",", ":")),
                    },
                )
            except DBAPIError as exc:
                sqlstate = getattr(getattr(exc, "orig", None), "sqlstate", None)
                if sqlstate == "40001":
                    raise OptimisticLockError("concurrent run update") from exc
                raise
            if new_version is None:
                raise OptimisticLockError("transition function returned no version")
            return int(new_version)


class PostgresIdempotencyStore(IdempotencyStore):
    def __init__(
        self,
        transactions: WorkspaceTransactionManager,
        context: WorkspaceContext,
        *,
        lease_owner: str,
        lease_duration: timedelta = timedelta(seconds=30),
    ) -> None:
        self._transactions = transactions
        self._context = context
        self._lease_owner = lease_owner
        self._lease_duration = lease_duration

    def _validate_key(self, key: IdempotencyKey) -> UUID:
        workspace_id = UUID(key.workspace_id)
        if workspace_id != self._context.workspace_id:
            raise PermissionError("idempotency key workspace mismatch")
        return UUID(key.run_id)

    async def reserve(self, key: IdempotencyKey, fingerprint: RequestFingerprint) -> Reservation:
        run_id = self._validate_key(key)
        async with self._transactions.transaction(self._context) as connection:
            statement = (
                postgresql_insert(idempotency_records)
                .values(
                    id=uuid4(),
                    workspace_id=self._context.workspace_id,
                    run_id=run_id,
                    tool_call_id=key.tool_call_id,
                    operation=key.operation,
                    args_digest=fingerprint.args_digest,
                    policy_version=fingerprint.policy_version,
                    status="reserved",
                    lease_owner=self._lease_owner,
                    lease_expires_at=func.now() + self._lease_duration,
                )
                .on_conflict_do_nothing(
                    index_elements=[
                        idempotency_records.c.workspace_id,
                        idempotency_records.c.run_id,
                        idempotency_records.c.tool_call_id,
                        idempotency_records.c.operation,
                    ]
                )
                .returning(idempotency_records.c.id)
            )
            inserted = await connection.scalar(statement)
            if inserted is not None:
                return Reservation(ReservationState.RESERVED)
            row = (
                (
                    await connection.execute(
                        select(
                            idempotency_records,
                            (idempotency_records.c.lease_expires_at <= func.now()).label(
                                "lease_expired"
                            ),
                        )
                        .where(
                            idempotency_records.c.workspace_id == self._context.workspace_id,
                            idempotency_records.c.run_id == run_id,
                            idempotency_records.c.tool_call_id == key.tool_call_id,
                            idempotency_records.c.operation == key.operation,
                        )
                        .with_for_update()
                    )
                )
                .mappings()
                .one()
            )
            if (
                row["args_digest"] != fingerprint.args_digest
                or row["policy_version"] != fingerprint.policy_version
            ):
                return Reservation(ReservationState.CONFLICT)
            if row["status"] in {"completed", "failed"}:
                return Reservation(
                    ReservationState.REPLAY, _deserialize_broker_outcome(row["outcome"])
                )
            if row["status"] == "unknown_reconciliation_required":
                return Reservation(ReservationState.UNKNOWN_RECONCILIATION_REQUIRED)
            if row["lease_expired"]:
                await connection.execute(
                    update(idempotency_records)
                    .where(idempotency_records.c.id == row["id"])
                    .values(
                        status="unknown_reconciliation_required",
                        updated_at=func.now(),
                    )
                )
                return Reservation(ReservationState.UNKNOWN_RECONCILIATION_REQUIRED)
            return Reservation(ReservationState.IN_PROGRESS)

    async def complete(self, key: IdempotencyKey, outcome: Any) -> None:
        run_id = self._validate_key(key)
        serialized = _serialize_broker_outcome(outcome)
        async with self._transactions.transaction(self._context) as connection:
            result = await connection.execute(
                update(idempotency_records)
                .where(
                    idempotency_records.c.workspace_id == self._context.workspace_id,
                    idempotency_records.c.run_id == run_id,
                    idempotency_records.c.tool_call_id == key.tool_call_id,
                    idempotency_records.c.operation == key.operation,
                    idempotency_records.c.status == "reserved",
                    idempotency_records.c.lease_owner == self._lease_owner,
                )
                .values(
                    status="failed" if serialized["status"] == "failed" else "completed",
                    outcome=serialized,
                    lease_owner=None,
                    lease_expires_at=None,
                    updated_at=func.now(),
                )
            )
            if result.rowcount != 1:
                raise RecordNotFoundError("owned idempotency reservation not found")

    async def release(self, key: IdempotencyKey) -> None:
        run_id = self._validate_key(key)
        async with self._transactions.transaction(self._context) as connection:
            await connection.execute(
                delete(idempotency_records).where(
                    idempotency_records.c.workspace_id == self._context.workspace_id,
                    idempotency_records.c.run_id == run_id,
                    idempotency_records.c.tool_call_id == key.tool_call_id,
                    idempotency_records.c.operation == key.operation,
                    idempotency_records.c.status == "reserved",
                    idempotency_records.c.lease_owner == self._lease_owner,
                )
            )


class PostgresApprovalStore:
    def __init__(
        self, transactions: WorkspaceTransactionManager, context: WorkspaceContext
    ) -> None:
        self._transactions = transactions
        self._context = context

    async def add(self, item: Approval) -> None:
        async with self._transactions.transaction(self._context) as connection:
            await connection.execute(
                insert(approvals).values(
                    id=uuid4(),
                    workspace_id=self._context.workspace_id,
                    run_id=UUID(item.run_id),
                    tool_call_id=item.tool_call_id,
                    operation=item.operation,
                    args_digest=item.args_digest,
                    decision=item.decision,
                    expires_at=item.expires_at,
                )
            )

    async def consume(self, run_id: str, tool_call_id: str, operation: str, digest: str) -> bool:
        result_id: UUID | None
        async with self._transactions.transaction(self._context) as connection:
            result_id = await connection.scalar(
                update(approvals)
                .where(
                    approvals.c.workspace_id == self._context.workspace_id,
                    approvals.c.run_id == UUID(run_id),
                    approvals.c.tool_call_id == tool_call_id,
                    approvals.c.operation == operation,
                    approvals.c.args_digest == digest,
                    approvals.c.decision == "once",
                    approvals.c.consumed_at.is_(None),
                    approvals.c.expires_at > func.now(),
                )
                .values(consumed_at=func.now())
                .returning(approvals.c.id)
            )
        return result_id is not None


class CostReservationStore:
    def __init__(self, transactions: WorkspaceTransactionManager) -> None:
        self._transactions = transactions

    async def create(
        self,
        context: WorkspaceContext,
        run_id: UUID,
        reserved_microunits: int,
    ) -> UUID:
        if reserved_microunits < 0:
            raise CostReservationError("negative reservation")
        identifier = uuid4()
        async with self._transactions.transaction(context) as connection:
            await connection.execute(
                insert(cost_reservations).values(
                    id=identifier,
                    workspace_id=context.workspace_id,
                    run_id=run_id,
                    reserved_microunits=reserved_microunits,
                    settled_microunits=0,
                    status="reserved",
                    version=0,
                )
            )
        return identifier

    async def settle_to(
        self,
        context: WorkspaceContext,
        reservation_id: UUID,
        settled_microunits: int,
    ) -> CostReservationSnapshot:
        if settled_microunits < 0:
            raise CostReservationError("negative settlement")
        async with self._transactions.transaction(context) as connection:
            row = await self._locked_row(connection, context, reservation_id)
            if settled_microunits == row["settled_microunits"]:
                return _cost_snapshot(row)
            if row["status"] in {"released", "disputed"}:
                raise CostReservationError("reservation cannot be settled")
            if settled_microunits < row["settled_microunits"]:
                raise CostReservationError("settlement cannot decrease")
            if settled_microunits > row["reserved_microunits"]:
                raise CostReservationError("settlement exceeds reservation")
            status = (
                "settled"
                if settled_microunits == row["reserved_microunits"]
                else "partially_settled"
            )
            updated = (
                (
                    await connection.execute(
                        update(cost_reservations)
                        .where(cost_reservations.c.id == reservation_id)
                        .values(
                            settled_microunits=settled_microunits,
                            status=status,
                            version=cost_reservations.c.version + 1,
                            updated_at=func.now(),
                        )
                        .returning(cost_reservations)
                    )
                )
                .mappings()
                .one()
            )
            return _cost_snapshot(updated)

    async def release(
        self, context: WorkspaceContext, reservation_id: UUID
    ) -> CostReservationSnapshot:
        async with self._transactions.transaction(context) as connection:
            row = await self._locked_row(connection, context, reservation_id)
            if row["status"] == "released":
                return _cost_snapshot(row)
            if row["status"] in {"settled", "disputed"}:
                raise CostReservationError("reservation cannot be released")
            updated = (
                (
                    await connection.execute(
                        update(cost_reservations)
                        .where(cost_reservations.c.id == reservation_id)
                        .values(
                            status="released",
                            version=cost_reservations.c.version + 1,
                            updated_at=func.now(),
                        )
                        .returning(cost_reservations)
                    )
                )
                .mappings()
                .one()
            )
            return _cost_snapshot(updated)

    async def _locked_row(
        self,
        connection: AsyncConnection,
        context: WorkspaceContext,
        reservation_id: UUID,
    ) -> Any:
        row = (
            (
                await connection.execute(
                    select(cost_reservations)
                    .where(
                        cost_reservations.c.id == reservation_id,
                        cost_reservations.c.workspace_id == context.workspace_id,
                    )
                    .with_for_update()
                )
            )
            .mappings()
            .one_or_none()
        )
        if row is None:
            raise RecordNotFoundError("cost reservation not visible")
        return row


def rehydrate_run_from_event_rows(
    run_id: UUID,
    state: RunState,
    rows: Sequence[Any],
) -> Run:
    transition_rows = sorted(
        (row for row in rows if row["event_type"] == "run.transitioned"),
        key=lambda row: row["transition_version"],
    )
    events = tuple(
        RunTransitionEvent(
            str(run_id),
            row["transition_version"],
            RunState(row["payload"]["from_state"]),
            RunState(row["payload"]["to_state"]),
            row["occurred_at"],
        )
        for row in transition_rows
    )
    return Run.rehydrate(str(run_id), state, events)


def _cost_snapshot(row: Any) -> CostReservationSnapshot:
    return CostReservationSnapshot(
        row["id"],
        row["reserved_microunits"],
        row["settled_microunits"],
        row["status"],
        row["version"],
    )


def _serialize_broker_outcome(outcome: Any) -> dict[str, Any]:
    status = getattr(outcome, "status", None)
    status_value = getattr(status, "value", status)
    payload = {
        "status": status_value,
        "detail": str(getattr(outcome, "detail", ""))[:512],
        "result": getattr(outcome, "result", None),
        "error_code": type(getattr(outcome, "error", None)).__name__
        if getattr(outcome, "error", None) is not None
        else None,
    }
    validated = validate_outcome(payload)
    if validated is None:
        raise ValueError("outcome cannot be null")
    return validated


def _deserialize_broker_outcome(payload: dict[str, Any] | None) -> Any:
    if payload is None:
        raise ValueError("completed idempotency record has no outcome")
    from athena_runtime.tools import BrokerOutcome, BrokerOutcomeStatus

    return BrokerOutcome(
        BrokerOutcomeStatus(payload["status"]),
        payload.get("detail", "replayed durable outcome"),
        payload.get("result"),
    )
