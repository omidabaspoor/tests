import ast
import re
from pathlib import Path

MIGRATION = Path("alembic/versions/20260816_01b_persistence_core.py")
API_MIGRATION = Path("alembic/versions/20260816_01c1_api_hardening.py")


def _sql_argument(node: ast.AST) -> str:
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        return node.value
    if isinstance(node, ast.JoinedStr):
        return "".join(
            value.value if isinstance(value, ast.Constant) else "{expression}"
            for value in node.values
        )
    raise AssertionError("op.execute must receive a statically inspectable SQL string")


def _top_level_statements(sql: str) -> list[str]:
    without_function_bodies = re.sub(r"\$\$.*?\$\$", "$$BODY$$", sql, flags=re.DOTALL)
    return [
        statement.strip() for statement in without_function_bodies.split(";") if statement.strip()
    ]


def _op_execute_sql(path: Path = MIGRATION) -> list[str]:
    tree = ast.parse(path.read_text(encoding="utf-8"))
    statements: list[str] = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call) or not isinstance(node.func, ast.Attribute):
            continue
        if (
            isinstance(node.func.value, ast.Name)
            and node.func.value.id == "op"
            and node.func.attr == "execute"
        ):
            assert len(node.args) == 1
            statements.append(_sql_argument(node.args[0]))
    return statements


def test_every_op_execute_contains_one_top_level_statement() -> None:
    for sql in _op_execute_sql():
        assert len(_top_level_statements(sql)) == 1, sql


def test_function_and_trigger_ddl_is_split_into_six_execute_calls() -> None:
    create_statements = [
        " ".join(_top_level_statements(sql)[0].split())
        for sql in _op_execute_sql()
        if _top_level_statements(sql)[0].lstrip().upper().startswith("CREATE FUNCTION")
        or _top_level_statements(sql)[0].lstrip().upper().startswith("CREATE TRIGGER")
    ]
    assert len(create_statements) == 6
    assert create_statements[0].startswith("CREATE FUNCTION athena.enforce_run_state_transition()")
    assert create_statements[1].startswith("CREATE TRIGGER trg_run_state_transition")
    assert create_statements[2].startswith("CREATE FUNCTION athena.enforce_run_event_sequence()")
    assert create_statements[3].startswith("CREATE TRIGGER trg_run_event_sequence")
    assert create_statements[4].startswith("CREATE FUNCTION athena.append_run_event(")
    assert create_statements[5].startswith("CREATE FUNCTION athena.transition_run(")


def test_api_hardening_revision_has_single_statement_execute_calls() -> None:
    for sql in _op_execute_sql(API_MIGRATION):
        assert len(_top_level_statements(sql)) == 1, sql
