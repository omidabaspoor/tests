import pytest

from athena_runtime.api.completion import validate_completion_markers
from athena_runtime.api.live_action import (
    TEMPLATE_REGISTRY,
    TEMPLATE_VERSION,
    LiveActionComposer,
)


def test_la01_unknown_event_creates_no_status() -> None:
    assert LiveActionComposer().compose("r", "unknown.event", {}) is None


def test_la02_template_is_exact() -> None:
    status = LiveActionComposer().compose("r", "brief.compiling", {})
    assert status is not None
    assert status.text == "دارم درخواستت رو دقیق می‌کنم."


def test_la03_raw_payload_is_never_rendered() -> None:
    raw = "RAW_PRIVATE_VALUE"
    status = LiveActionComposer().compose("r", "source.searching", {"query": raw, "provider": raw})
    assert status is not None and raw not in status.text


def test_la04_sensitive_payload_is_rejected() -> None:
    projector = LiveActionComposer()
    assert projector.compose("r", "brief.compiling", {"prompt": "private"}) is None
    assert projector.compose("r2", "brief.compiling", {"nested": {"tool_args": {"x": 1}}}) is None


def test_la05_composer_is_stateless_and_deterministic() -> None:
    composer = LiveActionComposer()
    assert composer.compose("r", "brief.compiling", {}) == composer.compose(
        "r", "brief.compiling", {}
    )


def test_la06_composer_keeps_no_throttle_state() -> None:
    composer = LiveActionComposer()
    assert composer.compose("r", "brief.compiling", {}) is not None
    assert composer.compose("r", "source.searching", {}) is not None


def test_la07_terminal_status_bypasses_throttle() -> None:
    projector = LiveActionComposer()
    projector.compose("r", "brief.compiling", {})
    assert projector.compose("r", "run.failed", {}) is not None


def test_la08_creative_percentage_is_forbidden() -> None:
    for event_type in ("content.drafting", "image.generating", "quality.checking"):
        status = LiveActionComposer().compose(
            event_type,
            event_type,
            {"progress_current": 1, "progress_total": 2},
        )
        assert status is not None and status.progress_percent is None


def test_la09_countable_upload_or_page_percentage_is_valid() -> None:
    status = LiveActionComposer().compose(
        "r",
        "file.uploading",
        {"progress_current": 2, "progress_total": 4},
    )
    assert status is not None and status.progress_percent == 50


def test_la10_variant_is_stable_for_a_run() -> None:
    first = LiveActionComposer().compose("stable", "source.searching", {})
    second = LiveActionComposer().compose("stable", "source.searching", {})
    assert first is not None and second is not None and first.text == second.text


def test_la11_template_version_is_present() -> None:
    status = LiveActionComposer().compose("r", "run.failed", {})
    assert status is not None and status.template_version == TEMPLATE_VERSION


def test_la12_completed_without_markers_is_rejected() -> None:
    with pytest.raises(ValueError, match="marker"):
        validate_completion_markers(set())


def test_la13_completed_after_all_markers_is_valid() -> None:
    validate_completion_markers({"quality.decision", "artifact.not_required", "cost.status"})
    status = LiveActionComposer().compose("r", "run.completed", {})
    assert status is not None and status.text == "آماده شد."


def test_la14_stopped_status_follows_stop_event() -> None:
    status = LiveActionComposer().compose("r", "run.stopped", {})
    assert status is not None and status.text == "کار متوقف شد."


def test_la15_all_registered_outputs_are_short_fixed_persian() -> None:
    assert TEMPLATE_REGISTRY
    for event_type, templates in TEMPLATE_REGISTRY.items():
        for text in templates:
            assert 3 <= len(text) <= 100, event_type
            assert any("\u0600" <= character <= "\u06ff" for character in text)
            assert "{" not in text and "}" not in text
