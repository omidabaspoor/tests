# API 01C.1 — Test Results

## Gate

- 84 baseline Unit/Security: PASS
- آخرین Persistence PostgreSQL CI: PASS روی Python 3.12/3.13
- Migration Up/Down baseline: PASS در همان CI

## Local

```text
pytest -q -m "not integration"
89 passed, 36 deselected

ruff check .
All checks passed!

python -m compileall -q src tests alembic
PASS

python -m build --wheel + isolated install/import
PASS

alembic upgrade head --sql
PASS (01b + 01c1)

alembic downgrade 20260816_01c1:base --sql
PASS
```

PostgreSQL محلی موجود نبود:

- Integration تعریف‌شده: 36
- Integration اجراشده محلی: 0
- وضعیت Integration جدید: `BLOCKED_NOT_RUN`
- CI 01C.1: `NOT_RUN_YET`

## Required scenarios

| Scenario | Local status | PostgreSQL status |
|---|---|---|
| L01 Source → persisted live_action | Composer PASS | Defined, pending CI |
| L02 unknown → no write | PASS_UNIT | Defined |
| L03 duplicate no second write | deterministic composer PASS | Defined |
| L04 two service throttle | architecture/static PASS | Defined |
| L05 terminal bypass | PASS_UNIT | Defined |
| L06 reconnect persisted text | SSE persisted payload unit PASS | Defined |
| L07 restart variant stable | PASS_UNIT | Defined |
| L08 sensitive excluded | PASS_UNIT | Defined |
| C01 missing marker rejected | PASS_UNIT | Defined |
| C02 markers complete | PASS_UNIT | Defined |
| C03 concurrent completion single transition | — | Defined |
| C04 completed live action persisted | — | Defined |
| I01 missing key rejected | PASS_UNIT | N/A |
| I02 retry same response/run | PASS_UNIT | Defined |
| I03 changed body 409 | PASS_UNIT | Defined by store path |
| I04 20 concurrent POST one Run | PASS_UNIT fake | Defined PostgreSQL |
| S01 concurrent Stop both stopped | baseline idempotency PASS | Defined PostgreSQL |
| B01 chunked oversized 413 | PASS_UNIT |
| T01 occurred_at/recorded_at | PASS_UNIT | Defined PostgreSQL |

## F01–F08

- F01 Durable Live Action: IMPLEMENTED; PostgreSQL proof pending.
- F02 persisted dedup/throttle: IMPLEMENTED in locked DB function; pending CI.
- F03 persisted Completion: IMPLEMENTED; concurrency pending CI.
- F04 event time contract: PASS_UNIT; DB round-trip pending CI.
- F05 goal persistence: IMPLEMENTED in revision; pending CI.
- F06 API idempotency: PASS_UNIT + integration defined; pending CI.
- F07 concurrent stop reread: IMPLEMENTED + integration defined; pending CI.
- F08 streaming body limit: PASS_UNIT including chunked/no Content-Length.

## Security summary

- Goal در SSE/error/idempotency response نیست.
- `live_action.updated` payload schema دقیق دارد.
- SSE Composer را در read path اجرا نمی‌کند.
- Workspace فقط Auth Context است.
- api_idempotency RLS/FORCE RLS در migration تعریف شده است.
- Unauthorized side effect در تست‌های محلی: صفر.
