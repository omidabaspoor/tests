# API 01C.1 Hardening

## F01/F02 — Durable Live Action

`LiveActionComposer` stateless است و فقط Source Event ساختاریافته را به template ثابت `01c.v2` تبدیل می‌کند. هیچ Dict state، model call یا raw payload rendering ندارد.

`LiveActionService` نتیجه validate‌شده را به function امن `athena.append_live_action` می‌دهد. Function زیر lock همان Run آخرین `live_action.updated` پایدار را می‌خواند، duplicate/throttle را تصمیم می‌گیرد، global sequence تخصیص می‌دهد و event نهایی user-visible را درج می‌کند. بنابراین restart و دو service instance نتیجه را تغییر نمی‌دهند. Terminal/approval/failure با flag ساختاریافته throttle را bypass می‌کنند؛ duplicate همچنان write دوم ندارد.

SSE فقط payload ذخیره‌شده `live_action.updated` را replay می‌کند و Composer در read path وجود ندارد.

## F03 — Durable Completion

`CompletionGate` حافظه‌ای حذف شد. `RunCompletionService` eventهای داخلی `quality.decision`، یکی از `artifact.ready|artifact.not_required` و `cost.status` را برای همان workspace/run می‌خواند. بدون marker کامل completion رد می‌شود. سپس Domain/Persistence transition اتمیک به completed انجام می‌شود. conflict هم‌زمان با reread completed idempotent می‌شود و Live Action completed از طریق durable service ثبت می‌گردد. Endpoint عمومی completion وجود ندارد.

## F04 — Event time

Public contract اکنون `occurred_at` و `recorded_at` دارد. `created_at` مبهم حذف شد. UI باید occurred_at را نمایش دهد. جزئیات در `event-contract-01c1.md` است.

## F05 — Goal

Revision جدید ستون `athena.runs.goal VARCHAR(500) NOT NULL` را اضافه می‌کند. مقدار دقیق Pydantic-validated API در همان transaction ساخت Run ذخیره می‌شود. Goal در response، public event، error و idempotency response body ذخیره/نمایش داده نمی‌شود و تحت RLS Run است. طبقه‌بندی: D2/Confidential.

## F06 — API idempotency

Revision `20260816_01c1` جدول RLSدار `api_idempotency_records` را اضافه می‌کند. `POST /v1/runs` header اجباری `Idempotency-Key` با charset/length محدود دارد. Canonical goal hash به `(workspace, endpoint, key)` متصل است.

- اولین insert winner: idempotency record + Run + response محدود در یک transaction.
- همان key/body: همان run_id/status/events_url replay می‌شود.
- key با body متفاوت: `IDEMPOTENCY_CONFLICT` 409.
- `ON CONFLICT` و row lock باعث یک Run در race می‌شود.
- expires_at برابر 24 ساعت ثبت می‌شود؛ cleanup worker خارج Scope است.

## F07 — Concurrent Stop

پس از OptimisticLockError، service Run را reread می‌کند: stopped → 200؛ terminal دیگر → RUN_NOT_STOPPABLE؛ وضعیت دیگر → conflict امن. Retry کور وجود ندارد.

## F08 — Body limit

`BodyLimitMiddleware` یک ASGI wrapper کوچک است که Content-Length را پیشاپیش بررسی می‌کند و stream بدون Content-Length را chunk-by-chunk فقط تا سقف 16 KiB می‌خواند. با عبور از سقف، 413 می‌فرستد و body باقی‌مانده را drain/buffer نمی‌کند. B01 chunked oversize را پوشش می‌دهد.

Deployment contract: reverse proxy نیز باید hard request-body limit برابر یا کمتر از 16 KiB، timeout و buffering محدود داشته باشد. ASGI limit جایگزین proxy limit نیست.

## Migration

Initial Revision بازنویسی نشد. Revision جدید `20260816_01c1_api_hardening.py` شامل goal، idempotency table/RLS و append_live_action SECURITY DEFINER است. Up/Down offline compile شده‌اند و هر `op.execute` یک top-level statement دارد.

## Remaining risk

PostgreSQL محلی موجود نیست؛ 36 Integration test از جمله L/C/I/S/T جدید باید در CI Python 3.12/3.13 + PostgreSQL 17 اجرا شوند. API rate limiting، Auth واقعی، proxy production test، cleanup TTL، Worker و UI خارج Scope هستند.
