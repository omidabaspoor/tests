# Public Event Contract 01C.1

SSE فقط Event پایدار با `visibility=user` را می‌خواند؛ متن Live Action هنگام Read تولید نمی‌شود.

```json
{
  "event_id": "uuid",
  "run_id": "uuid",
  "sequence": 7,
  "type": "live_action.updated",
  "occurred_at": "2026-08-16T10:00:00Z",
  "recorded_at": "2026-08-16T10:00:00.050000Z",
  "payload": {
    "text": "دارم منابع تازه رو بررسی می‌کنم.",
    "source_event_type": "source.searching",
    "template_version": "01c.v2",
    "progress_percent": null
  }
}
```

- `occurred_at`: زمان واقعی Source Event و زمان مورد استفاده UI.
- `recorded_at`: زمان ingest پایگاه داده (`run_events.created_at`).
- `created_at` از Public Contract حذف شده است.
- `sequence` همان global Run sequence است.
- `live_action.updated` فقط payload دقیق بالا را می‌پذیرد: متن 1–100 کاراکتر، source type محدود، template version حداکثر 32، درصد null یا 0–100.
- Payload eventهای عمومی دیگر whitelist جدا و بدون generic text دارد.
- internal/audit، goal، prompt، tool args، model/provider و secret به SSE راه ندارند.
