"""Persist goals, API idempotency, and durable live actions.

Revision ID: 20260816_01c1
Revises: 20260816_01b
"""

import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

from alembic import op

revision: str = "20260816_01c1"
down_revision: str | None = "20260816_01b"
branch_labels: str | None = None
depends_on: str | None = None


def upgrade() -> None:
    op.add_column(
        "runs",
        sa.Column("goal", sa.String(500), nullable=False),
        schema="athena",
    )
    op.create_table(
        "api_idempotency_records",
        sa.Column(
            "id",
            postgresql.UUID(as_uuid=True),
            server_default=sa.text("gen_random_uuid()"),
            nullable=False,
        ),
        sa.Column("workspace_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("endpoint", sa.String(64), nullable=False),
        sa.Column("idempotency_key", sa.String(128), nullable=False),
        sa.Column("request_hash", sa.String(64), nullable=False),
        sa.Column("status", sa.String(16), nullable=False),
        sa.Column("response_status", sa.Integer(), nullable=True),
        sa.Column("response_body", postgresql.JSONB(), nullable=True),
        sa.Column("resource_id", postgresql.UUID(as_uuid=True), nullable=True),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=False,
        ),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=False),
        sa.ForeignKeyConstraint(
            ["workspace_id", "resource_id"],
            ["athena.runs.workspace_id", "athena.runs.id"],
            name="fk_api_idempotency_workspace_run",
            ondelete="CASCADE",
        ),
        sa.PrimaryKeyConstraint("id", name="pk_api_idempotency_records"),
        sa.UniqueConstraint(
            "workspace_id",
            "endpoint",
            "idempotency_key",
            name="uq_api_idempotency_key",
        ),
        sa.CheckConstraint(
            "status IN ('pending','completed')",
            name="ck_api_idempotency_records_api_idempotency_status",
        ),
        sa.CheckConstraint(
            "response_body IS NULL OR octet_length(response_body::text) <= 16384",
            name="ck_api_idempotency_records_api_idempotency_response_size",
        ),
        schema="athena",
    )
    op.create_index(
        "ix_api_idempotency_expiry",
        "api_idempotency_records",
        ["workspace_id", "expires_at"],
        schema="athena",
    )
    op.execute("ALTER TABLE athena.api_idempotency_records OWNER TO athena_migration")
    op.execute("ALTER TABLE athena.api_idempotency_records ENABLE ROW LEVEL SECURITY")
    op.execute("ALTER TABLE athena.api_idempotency_records FORCE ROW LEVEL SECURITY")
    op.execute(
        """
        CREATE POLICY api_idempotency_workspace_isolation
          ON athena.api_idempotency_records
          FOR ALL TO athena_app, athena_migration
          USING (
            workspace_id = NULLIF(current_setting('app.workspace_id', true), '')::uuid
          )
          WITH CHECK (
            workspace_id = NULLIF(current_setting('app.workspace_id', true), '')::uuid
          )
        """
    )
    op.execute("GRANT SELECT, INSERT, UPDATE ON athena.api_idempotency_records TO athena_app")
    op.execute(
        """
        CREATE FUNCTION athena.append_live_action(
          p_run_id uuid,
          p_payload jsonb,
          p_occurred_at timestamptz,
          p_bypass_throttle boolean
        ) RETURNS TABLE(event_id uuid, event_sequence bigint)
        LANGUAGE plpgsql
        SECURITY DEFINER
        SET search_path = pg_catalog, athena
        AS $$
        DECLARE
          v_workspace uuid;
          v_sequence bigint;
          v_event_id uuid := gen_random_uuid();
          v_last_text text;
          v_last_occurred timestamptz;
        BEGIN
          v_workspace := NULLIF(current_setting('app.workspace_id', true), '')::uuid;
          IF v_workspace IS NULL OR p_run_id IS NULL OR p_payload IS NULL
             OR p_occurred_at IS NULL OR p_bypass_throttle IS NULL THEN
            RAISE EXCEPTION 'missing live action context' USING ERRCODE = '22023';
          END IF;
          IF jsonb_typeof(p_payload) <> 'object'
             OR NOT (p_payload ? 'text')
             OR NOT (p_payload ? 'source_event_type')
             OR NOT (p_payload ? 'template_version')
             OR length(p_payload->>'text') NOT BETWEEN 1 AND 100
             OR (p_payload->>'source_event_type') !~ '^[a-z0-9][a-z0-9._-]{0,63}$'
             OR length(p_payload->>'template_version') NOT BETWEEN 1 AND 32
             OR EXISTS (
               SELECT 1 FROM jsonb_object_keys(p_payload) AS key
               WHERE key NOT IN ('text','source_event_type','template_version','progress_percent')
             )
             OR (
               p_payload->'progress_percent' IS NOT NULL
               AND jsonb_typeof(p_payload->'progress_percent') <> 'null'
               AND (
                 jsonb_typeof(p_payload->'progress_percent') <> 'number'
                 OR (p_payload->>'progress_percent')::integer NOT BETWEEN 0 AND 100
               )
             ) THEN
            RAISE EXCEPTION 'invalid live action payload' USING ERRCODE = '22023';
          END IF;
          PERFORM 1 FROM athena.runs
            WHERE id = p_run_id AND workspace_id = v_workspace
            FOR UPDATE;
          IF NOT FOUND THEN
            RAISE EXCEPTION 'run not visible in workspace' USING ERRCODE = '42501';
          END IF;
          SELECT payload->>'text', occurred_at
            INTO v_last_text, v_last_occurred
            FROM athena.run_events
            WHERE run_id = p_run_id AND event_type = 'live_action.updated'
            ORDER BY sequence DESC LIMIT 1;
          IF v_last_text = p_payload->>'text' THEN
            RETURN;
          END IF;
          IF NOT p_bypass_throttle AND v_last_occurred IS NOT NULL
             AND p_occurred_at < v_last_occurred + interval '2 seconds' THEN
            RETURN;
          END IF;
          SELECT COALESCE(MAX(sequence), 0) + 1 INTO v_sequence
            FROM athena.run_events WHERE run_id = p_run_id;
          INSERT INTO athena.run_events(
            id, workspace_id, run_id, sequence, transition_version,
            event_type, visibility, payload, occurred_at
          ) VALUES (
            v_event_id, v_workspace, p_run_id, v_sequence, NULL,
            'live_action.updated', 'user', p_payload, p_occurred_at
          );
          event_id := v_event_id;
          event_sequence := v_sequence;
          RETURN NEXT;
        END $$;
        """
    )
    op.execute(
        "ALTER FUNCTION athena.append_live_action(uuid,jsonb,timestamptz,boolean) "
        "OWNER TO athena_migration"
    )
    op.execute(
        "REVOKE ALL ON FUNCTION "
        "athena.append_live_action(uuid,jsonb,timestamptz,boolean) FROM PUBLIC"
    )
    op.execute(
        "GRANT EXECUTE ON FUNCTION "
        "athena.append_live_action(uuid,jsonb,timestamptz,boolean) TO athena_app"
    )


def downgrade() -> None:
    op.execute("DROP FUNCTION IF EXISTS athena.append_live_action(uuid,jsonb,timestamptz,boolean)")
    op.drop_index(
        "ix_api_idempotency_expiry",
        table_name="api_idempotency_records",
        schema="athena",
    )
    op.drop_table("api_idempotency_records", schema="athena")
    op.drop_column("runs", "goal", schema="athena")
