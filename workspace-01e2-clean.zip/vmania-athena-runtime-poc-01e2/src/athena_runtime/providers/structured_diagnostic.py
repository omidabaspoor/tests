import json
from dataclasses import dataclass

from pydantic import ValidationError

from athena_runtime.providers.understanding import (
    MAX_STRUCTURED_OUTPUT_BYTES,
    UnderstandingOutput,
)


@dataclass(frozen=True, slots=True)
class SafeDiagnostic:
    content_length: int
    first_non_whitespace_character: str | None
    starts_with_code_fence: bool
    validation_error_location: str | None = None
    validation_error_type: str | None = None
    validation_error_message: str | None = None
    response_format_mode: str = "json_schema"


def parse_structured_content(
    content: str,
) -> tuple[UnderstandingOutput | None, SafeDiagnostic]:
    encoded = content.encode("utf-8")
    stripped = content.lstrip()
    base = {
        "content_length": len(encoded),
        "first_non_whitespace_character": stripped[0] if stripped else None,
        "starts_with_code_fence": stripped.startswith("```"),
    }
    if len(encoded) > MAX_STRUCTURED_OUTPUT_BYTES:
        return None, SafeDiagnostic(
            **base,
            validation_error_location="$",
            validation_error_type="output_too_large",
            validation_error_message="Structured output exceeded the byte limit.",
        )
    if stripped.startswith("```"):
        return None, SafeDiagnostic(
            **base,
            validation_error_location="$",
            validation_error_type="code_fence_not_allowed",
            validation_error_message="Markdown code fences are not accepted.",
        )
    try:
        payload = json.loads(content)
    except json.JSONDecodeError:
        return None, SafeDiagnostic(
            **base,
            validation_error_location="$",
            validation_error_type="json_invalid",
            validation_error_message="Content is not direct valid JSON.",
        )
    if not isinstance(payload, dict):
        return None, SafeDiagnostic(
            **base,
            validation_error_location="$",
            validation_error_type="object_required",
            validation_error_message="Top-level JSON must be an object.",
        )
    try:
        output = UnderstandingOutput.model_validate_json(content)
    except ValidationError as exc:
        error = exc.errors(include_input=False, include_url=False)[0]
        location = ".".join(str(item) for item in error.get("loc", ())) or "$"
        return None, SafeDiagnostic(
            **base,
            validation_error_location=location[:128],
            validation_error_type=str(error.get("type", "validation_error"))[:64],
            validation_error_message=str(error.get("msg", "Schema validation failed."))[:160],
        )
    return output, SafeDiagnostic(**base)
