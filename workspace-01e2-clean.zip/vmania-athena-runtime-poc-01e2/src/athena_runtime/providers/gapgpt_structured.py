import json
from dataclasses import dataclass
from time import monotonic

import httpx

from athena_runtime.providers.errors import (
    MissingProviderSecret,
    ProviderAuthenticationError,
    ProviderRedirectError,
    ProviderResponseError,
    StructuredOutputUnsupported,
)
from athena_runtime.providers.gapgpt import GapGPTConfig
from athena_runtime.providers.gapgpt_chat import ALLOWED_SMOKE_MODELS, ChatUsage
from athena_runtime.providers.structured_prompt import structured_messages
from athena_runtime.providers.structured_schema import response_format

STRUCTURED_MAX_OUTPUT_TOKENS = 300


@dataclass(frozen=True, slots=True)
class StructuredChatResponse:
    requested_model: str
    response_model: str | None
    content: str
    finish_reason: str | None
    usage: ChatUsage
    latency_ms: int


class GapGPTStructuredOutputClient:
    """Single-attempt JSON Schema capability probe client."""

    def __init__(
        self,
        config: GapGPTConfig | None = None,
        *,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        self._config = config or GapGPTConfig()
        self._transport = transport

    async def probe(
        self, *, model: str, synthetic_user_input: str, secret: str
    ) -> StructuredChatResponse:
        if model not in ALLOWED_SMOKE_MODELS:
            raise ValueError("model is not in structured probe allowlist")
        if not secret or not secret.strip():
            raise MissingProviderSecret("provider credential is missing")
        body = {
            "model": model,
            "messages": list(structured_messages(synthetic_user_input)),
            "temperature": 0,
            "max_tokens": STRUCTURED_MAX_OUTPUT_TOKENS,
            "stream": False,
            "response_format": response_format(),
        }
        timeout = httpx.Timeout(
            connect=self._config.timeout_connect,
            read=self._config.timeout_read,
            write=self._config.timeout_read,
            pool=self._config.timeout_connect,
        )
        started = monotonic()
        async with httpx.AsyncClient(
            base_url=self._config.base_url.rstrip("/") + "/",
            timeout=timeout,
            follow_redirects=False,
            verify=True,
            trust_env=False,
            transport=self._transport,
            headers={
                "Authorization": f"Bearer {secret}",
                "Accept": "application/json",
                "Content-Type": "application/json",
                "User-Agent": self._config.user_agent,
            },
        ) as client:
            try:
                async with client.stream("POST", "chat/completions", json=body) as response:
                    if 300 <= response.status_code < 400:
                        raise ProviderRedirectError("provider redirect is forbidden")
                    if response.status_code in {400, 422}:
                        raise StructuredOutputUnsupported("structured output is unsupported")
                    if response.status_code in {401, 403}:
                        raise ProviderAuthenticationError("provider authentication failed")
                    if response.status_code != 200:
                        raise ProviderResponseError("structured probe request failed")
                    raw = await _bounded_body(response, self._config.max_response_bytes)
            except httpx.TimeoutException as exc:
                raise ProviderResponseError("structured probe timed out") from exc
            except httpx.RequestError as exc:
                raise ProviderResponseError("structured probe transport failed") from exc
        return _parse_envelope(
            raw,
            requested_model=model,
            latency_ms=max(0, int((monotonic() - started) * 1000)),
        )


async def _bounded_body(response: httpx.Response, maximum: int) -> bytes:
    data = bytearray()
    async for chunk in response.aiter_bytes():
        data.extend(chunk)
        if len(data) > maximum:
            raise ProviderResponseError("structured probe response exceeded size limit")
    return bytes(data)


def _parse_envelope(raw: bytes, *, requested_model: str, latency_ms: int) -> StructuredChatResponse:
    try:
        payload = json.loads(raw)
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ProviderResponseError("structured probe envelope is malformed") from exc
    if not isinstance(payload, dict):
        raise ProviderResponseError("structured probe envelope is invalid")
    choices = payload.get("choices")
    if not isinstance(choices, list) or len(choices) != 1:
        raise ProviderResponseError("structured probe choices are invalid")
    choice = choices[0]
    if not isinstance(choice, dict) or not isinstance(choice.get("message"), dict):
        raise ProviderResponseError("structured probe choice is invalid")
    content = choice["message"].get("content")
    if not isinstance(content, str):
        raise ProviderResponseError("structured probe content is missing")
    usage = payload.get("usage") if isinstance(payload.get("usage"), dict) else {}
    return StructuredChatResponse(
        requested_model=requested_model,
        response_model=(payload.get("model") if isinstance(payload.get("model"), str) else None),
        content=content,
        finish_reason=(
            choice.get("finish_reason") if isinstance(choice.get("finish_reason"), str) else None
        ),
        usage=ChatUsage(
            _token(usage.get("prompt_tokens")),
            _token(usage.get("completion_tokens")),
            _token(usage.get("total_tokens")),
        ),
        latency_ms=latency_ms,
    )


def _token(value: object) -> int | None:
    return value if isinstance(value, int) and not isinstance(value, bool) and value >= 0 else None
