import hashlib
import json
from typing import Any

SCHEMA_VERSION = "athena-understanding-schema-0.1"

SLOT_SCHEMA: dict[str, Any] = {
    "type": "object",
    "additionalProperties": False,
    "required": ["name", "value", "status", "confidence"],
    "properties": {
        "name": {"type": "string", "minLength": 1, "maxLength": 64},
        "value": {
            "anyOf": [
                {"type": "string", "maxLength": 300},
                {"type": "integer"},
                {"type": "number"},
                {"type": "boolean"},
                {"type": "null"},
            ]
        },
        "status": {
            "type": "string",
            "enum": ["explicit", "inferred", "defaulted", "unknown", "conflicting"],
        },
        "confidence": {"type": "number", "minimum": 0, "maximum": 1},
    },
}

UNDERSTANDING_JSON_SCHEMA: dict[str, Any] = {
    "type": "object",
    "additionalProperties": False,
    "required": [
        "task_type",
        "goal_summary",
        "slots",
        "conflicts",
        "missing_hard_slots",
        "should_clarify",
        "clarification_slot",
        "freshness",
        "risk_category",
        "warning_required",
        "required_capability",
    ],
    "properties": {
        "task_type": {
            "type": "string",
            "enum": [
                "caption",
                "research",
                "general_writing",
                "policy_response",
                "image_generation",
                "image_edit",
                "file_summary",
                "calculation",
                "software_project",
                "unknown",
            ],
        },
        "goal_summary": {"type": "string", "minLength": 1, "maxLength": 300},
        "slots": {"type": "array", "maxItems": 32, "items": SLOT_SCHEMA},
        "conflicts": {
            "type": "array",
            "maxItems": 16,
            "items": {"type": "string", "minLength": 1, "maxLength": 64},
        },
        "missing_hard_slots": {
            "type": "array",
            "maxItems": 16,
            "items": {"type": "string", "minLength": 1, "maxLength": 64},
        },
        "should_clarify": {"type": "boolean"},
        "clarification_slot": {
            "anyOf": [
                {"type": "string", "minLength": 1, "maxLength": 64},
                {"type": "null"},
            ]
        },
        "freshness": {
            "type": "string",
            "enum": ["stable", "periodic", "daily", "live"],
        },
        "risk_category": {
            "type": "string",
            "enum": [
                "low",
                "medium",
                "medical",
                "legal",
                "financial",
                "prompt_injection",
                "high",
            ],
        },
        "warning_required": {"type": "boolean"},
        "required_capability": {
            "type": "string",
            "enum": [
                "none",
                "text_generation",
                "web_research",
                "policy_response",
                "image_generation",
                "image_edit",
                "file_parse_and_text",
                "deterministic_calculator",
                "sandboxed_code_runtime",
            ],
        },
    },
}

SCHEMA_HASH = hashlib.sha256(
    json.dumps(
        UNDERSTANDING_JSON_SCHEMA,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=True,
    ).encode()
).hexdigest()


def response_format() -> dict[str, Any]:
    return {
        "type": "json_schema",
        "json_schema": {
            "name": "athena_understanding",
            "strict": True,
            "schema": UNDERSTANDING_JSON_SCHEMA,
        },
    }
