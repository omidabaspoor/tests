import asyncio
import json
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from time import monotonic

import httpx

from athena_runtime.providers.errors import (
    MissingProviderSecret,
    ProviderAuthenticationError,
    ProviderRateLimitError,
    ProviderRedirectError,
    ProviderResponseError,
)
from athena_runtime.providers.gapgpt import GapGPTConfig
from athena_runtime.providers.understanding_prompt import build_messages

ALLOWED_SMOKE_MODELS = (
    "gpt-5.6-luna",
    "gemini-3.6-flash",
    "claude-sonnet-5",
    "gpt-5.6-sol",
)
MAX_OUTPUT_TOKENS = 600
Sleep = Callable[[float], Awaitable[None]]
_RETRYABLE = frozenset({429, 500, 502, 503, 504})


@dataclass(frozen=True, slots=True)
class ChatUsage:
    input_tokens: int | None
    output_tokens: int | None
    total_tokens: int | None


@dataclass(frozen=True, slots=True)
class ChatResponse:
    requested_model: str
    response_model: str | None
    content: str
    finish_reason: str | None
    usage: ChatUsage
    latency_ms: int


class GapGPTUnderstandingChatClient:
    def __init__(
        self,
        config: GapGPTConfig | None = None,
        *,
        transport: httpx.AsyncBaseTransport | None = None,
        sleep: Sleep = asyncio.sleep,
    ) -> None:
        self._config = config or GapGPTConfig()
        self._transport = transport
        self._sleep = sleep

    async def understand(
        self, *, model: str, synthetic_user_input: str, secret: str
    ) -> ChatResponse:
        if model not in ALLOWED_SMOKE_MODELS:
            raise ValueError("model is not in smoke allowlist")
        if not secret or not secret.strip():
            raise MissingProviderSecret("provider credential is missing")
        body = {
            "model": model,
            "messages": list(build_messages(synthetic_user_input)),
            "temperature": 0,
            "max_tokens": MAX_OUTPUT_TOKENS,
            "stream": False,
        }
        timeout = httpx.Timeout(
            connect=self._config.timeout_connect,
            read=self._config.timeout_read,
            write=self._config.timeout_read,
            pool=self._config.timeout_connect,
        )
        started = monotonic()
        async with httpx.AsyncClient(
            base_url=self._config.base_url.rstrip("/") + "/",
            timeout=timeout,
            follow_redirects=False,
            verify=True,
            trust_env=False,
            transport=self._transport,
            headers={
                "Authorization": f"Bearer {secret}",
                "Accept": "application/json",
                "Content-Type": "application/json",
                "User-Agent": self._config.user_agent,
            },
        ) as client:
            for attempt in range(2):
                try:
                    async with client.stream("POST", "chat/completions", json=body) as response:
                        if 300 <= response.status_code < 400:
                            raise ProviderRedirectError("provider redirect is forbidden")
                        if response.status_code in {401, 403}:
                            raise ProviderAuthenticationError("provider authentication failed")
                        if response.status_code in {400, 404}:
                            raise ProviderResponseError("provider rejected smoke request")
                        if response.status_code in _RETRYABLE:
                            if attempt == 0:
                                await self._sleep(0.1)
                                continue
                            if response.status_code == 429:
                                raise ProviderRateLimitError("provider rate limit persisted")
                            raise ProviderResponseError("provider temporarily unavailable")
                        if response.status_code != 200:
                            raise ProviderResponseError("unexpected provider status")
                        raw = await _bounded_body(response, self._config.max_response_bytes)
                        return _parse_chat(
                            raw,
                            requested_model=model,
                            latency_ms=max(0, int((monotonic() - started) * 1000)),
                        )
                except httpx.TimeoutException as exc:
                    if attempt == 0:
                        await self._sleep(0.1)
                        continue
                    raise ProviderResponseError("provider smoke timed out") from exc
                except httpx.RequestError as exc:
                    raise ProviderResponseError("provider transport failed") from exc
        raise ProviderResponseError("provider smoke failed")


async def _bounded_body(response: httpx.Response, maximum: int) -> bytes:
    data = bytearray()
    async for chunk in response.aiter_bytes():
        data.extend(chunk)
        if len(data) > maximum:
            raise ProviderResponseError("provider response exceeded size limit")
    return bytes(data)


def _parse_chat(raw: bytes, *, requested_model: str, latency_ms: int) -> ChatResponse:
    try:
        payload = json.loads(raw)
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ProviderResponseError("provider returned malformed envelope") from exc
    if not isinstance(payload, dict):
        raise ProviderResponseError("provider envelope is invalid")
    choices = payload.get("choices")
    if not isinstance(choices, list) or len(choices) != 1:
        raise ProviderResponseError("provider choices are invalid")
    choice = choices[0]
    if not isinstance(choice, dict) or not isinstance(choice.get("message"), dict):
        raise ProviderResponseError("provider choice is invalid")
    content = choice["message"].get("content")
    if not isinstance(content, str):
        raise ProviderResponseError("provider content is missing")
    usage = payload.get("usage") if isinstance(payload.get("usage"), dict) else {}
    return ChatResponse(
        requested_model=requested_model,
        response_model=payload.get("model") if isinstance(payload.get("model"), str) else None,
        content=content,
        finish_reason=(
            choice.get("finish_reason") if isinstance(choice.get("finish_reason"), str) else None
        ),
        usage=ChatUsage(
            input_tokens=_optional_nonnegative_int(usage.get("prompt_tokens")),
            output_tokens=_optional_nonnegative_int(usage.get("completion_tokens")),
            total_tokens=_optional_nonnegative_int(usage.get("total_tokens")),
        ),
        latency_ms=latency_ms,
    )


def _optional_nonnegative_int(value: object) -> int | None:
    return value if isinstance(value, int) and not isinstance(value, bool) and value >= 0 else None
