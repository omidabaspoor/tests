import json
from dataclasses import asdict
from pathlib import Path

import httpx
import pytest

from athena_runtime.providers.errors import StructuredOutputUnsupported
from athena_runtime.providers.gapgpt_chat import ALLOWED_SMOKE_MODELS, ChatUsage
from athena_runtime.providers.gapgpt_structured import (
    STRUCTURED_MAX_OUTPUT_TOKENS,
    GapGPTStructuredOutputClient,
    StructuredChatResponse,
)
from athena_runtime.providers.gapgpt_structured_probe import (
    HARD_LOGICAL_CALL_CAP,
    ProbeRecord,
    ProbeSummary,
    run_probe,
    write_probe,
)
from athena_runtime.providers.structured_diagnostic import parse_structured_content
from athena_runtime.providers.structured_prompt import (
    STRUCTURED_PROMPT_HASH,
    STRUCTURED_PROMPT_VERSION,
)
from athena_runtime.providers.structured_schema import (
    SCHEMA_HASH,
    SCHEMA_VERSION,
    UNDERSTANDING_JSON_SCHEMA,
)

SECRET = "mock-structured-secret"


def valid_content(**changes: object) -> str:
    value = {
        "task_type": "caption",
        "goal_summary": "classify a synthetic request",
        "slots": [
            {
                "name": "subject",
                "value": None,
                "status": "unknown",
                "confidence": 0.0,
            }
        ],
        "conflicts": [],
        "missing_hard_slots": ["subject"],
        "should_clarify": True,
        "clarification_slot": "subject",
        "freshness": "stable",
        "risk_category": "low",
        "warning_required": False,
        "required_capability": "text_generation",
    }
    value.update(changes)
    return json.dumps(value, ensure_ascii=False)


def envelope(
    request: httpx.Request, content: str, *, finish_reason: str = "stop"
) -> httpx.Response:
    return httpx.Response(
        200,
        json={
            "model": "gpt-5.6-luna",
            "choices": [
                {
                    "message": {"role": "assistant", "content": content},
                    "finish_reason": finish_reason,
                }
            ],
            "usage": {
                "prompt_tokens": 11,
                "completion_tokens": 22,
                "total_tokens": 33,
            },
        },
        request=request,
    )


@pytest.mark.asyncio
async def test_j01_request_contains_strict_json_schema_response_format() -> None:
    async def handler(request: httpx.Request) -> httpx.Response:
        body = json.loads(await request.aread())
        response_format = body["response_format"]
        assert response_format["type"] == "json_schema"
        assert response_format["json_schema"]["name"] == "athena_understanding"
        assert response_format["json_schema"]["strict"] is True
        assert response_format["json_schema"]["schema"] == UNDERSTANDING_JSON_SCHEMA
        assert body["max_tokens"] == STRUCTURED_MAX_OUTPUT_TOKENS == 300
        assert body["temperature"] == 0 and body["stream"] is False
        assert "athena_understanding" not in body["messages"][0]["content"]
        return envelope(request, valid_content())

    await GapGPTStructuredOutputClient(transport=httpx.MockTransport(handler)).probe(
        model=ALLOWED_SMOKE_MODELS[0], synthetic_user_input="synthetic", secret=SECRET
    )


def test_j02_schema_requires_every_contract_field() -> None:
    assert set(UNDERSTANDING_JSON_SCHEMA["required"]) == {
        "task_type",
        "goal_summary",
        "slots",
        "conflicts",
        "missing_hard_slots",
        "should_clarify",
        "clarification_slot",
        "freshness",
        "risk_category",
        "warning_required",
        "required_capability",
    }
    assert set(UNDERSTANDING_JSON_SCHEMA["properties"]) == set(
        UNDERSTANDING_JSON_SCHEMA["required"]
    )


def test_j03_every_object_schema_forbids_additional_properties() -> None:
    objects: list[dict[str, object]] = []

    def walk(value: object) -> None:
        if isinstance(value, dict):
            if value.get("type") == "object":
                objects.append(value)
            for child in value.values():
                walk(child)
        elif isinstance(value, list):
            for child in value:
                walk(child)

    walk(UNDERSTANDING_JSON_SCHEMA)
    assert len(objects) >= 2
    assert all(value.get("additionalProperties") is False for value in objects)


@pytest.mark.asyncio
async def test_j04_400_is_unsupported_without_retry() -> None:
    calls = 0

    def handler(request: httpx.Request) -> httpx.Response:
        nonlocal calls
        calls += 1
        return httpx.Response(400, request=request)

    with pytest.raises(StructuredOutputUnsupported):
        await GapGPTStructuredOutputClient(transport=httpx.MockTransport(handler)).probe(
            model=ALLOWED_SMOKE_MODELS[0], synthetic_user_input="synthetic", secret=SECRET
        )
    assert calls == 1


def test_j05_valid_json_schema_content_parses() -> None:
    output, diagnostic = parse_structured_content(valid_content())
    assert output is not None and output.task_type.value == "caption"
    assert diagnostic.validation_error_type is None


def test_j06_extra_field_is_rejected() -> None:
    output, diagnostic = parse_structured_content(valid_content(extra="forbidden"))
    assert output is None
    assert diagnostic.validation_error_type == "extra_forbidden"


def test_j07_diagnostic_excludes_input_value_and_urls() -> None:
    _output, diagnostic = parse_structured_content(valid_content(extra="sensitive-value"))
    serialized = json.dumps(asdict(diagnostic), ensure_ascii=False)
    assert "sensitive-value" not in serialized
    assert "input_value" not in serialized
    assert "errors.pydantic.dev" not in serialized


def test_j08_artifact_has_no_raw_response_prompt_or_secret(tmp_path: Path) -> None:
    record = ProbeRecord(
        stage="A",
        case_id="C01",
        requested_model=ALLOWED_SMOKE_MODELS[0],
        status="SCHEMA_FAILED",
        error_code="SCHEMA_FAILED",
        diagnostic={"content_length": 10, "response_format_mode": "json_schema"},
    )
    summary = ProbeSummary(
        schema_version=SCHEMA_VERSION,
        schema_hash=SCHEMA_HASH,
        prompt_version=STRUCTURED_PROMPT_VERSION,
        prompt_hash=STRUCTURED_PROMPT_HASH,
        hard_logical_call_cap=8,
        actual_logical_calls=1,
        available_models=(ALLOWED_SMOKE_MODELS[0],),
        missing_models=ALLOWED_SMOKE_MODELS[1:],
        stage_a_schema_valid_models=(),
        records=(record,),
    )
    json_path, markdown_path = tmp_path / "probe.json", tmp_path / "probe.md"
    write_probe(summary, json_path, markdown_path)
    artifact = json_path.read_text() + markdown_path.read_text()
    assert SECRET not in artifact
    assert "یه کپشن میخوام" not in artifact
    assert "raw_response" not in artifact
    assert "system_prompt" not in artifact


def test_j09_hard_call_cap_is_eight() -> None:
    assert HARD_LOGICAL_CALL_CAP == 8
    assert len(ALLOWED_SMOKE_MODELS) == 4


def test_j10_no_automatic_fallback_or_retry_mode_exists() -> None:
    source = Path("src/athena_runtime/providers/gapgpt_structured.py").read_text(encoding="utf-8")
    assert "json_object" not in source
    assert "fallback" not in source.casefold()
    assert "for attempt" not in source
    assert "while" not in source


@pytest.mark.asyncio
async def test_j11_finish_length_is_failure_and_not_confirmed(tmp_path: Path) -> None:
    class LengthClient:
        async def probe(
            self, *, model: str, synthetic_user_input: str, secret: str
        ) -> StructuredChatResponse:
            del synthetic_user_input, secret
            return StructuredChatResponse(
                requested_model=model,
                response_model=model,
                content=valid_content(),
                finish_reason="length",
                usage=ChatUsage(1, 2, 3),
                latency_ms=1,
            )

    inventory = tmp_path / "inventory.json"
    inventory.write_text(json.dumps({"models": [{"id": ALLOWED_SMOKE_MODELS[0]}]}))
    summary = await run_probe(
        secret=SECRET,
        inventory_path=inventory,
        client=LengthClient(),  # type: ignore[arg-type]
    )
    assert summary.actual_logical_calls == 1
    assert summary.records[0].status == "FINISH_LENGTH"
    assert summary.stage_a_schema_valid_models == ()


@pytest.mark.asyncio
async def test_j12_only_four_allowlisted_models_can_be_called(tmp_path: Path) -> None:
    class ValidClient:
        def __init__(self) -> None:
            self.calls: list[tuple[str, str]] = []

        async def probe(
            self, *, model: str, synthetic_user_input: str, secret: str
        ) -> StructuredChatResponse:
            del secret
            self.calls.append((model, synthetic_user_input))
            return StructuredChatResponse(
                requested_model=model,
                response_model=model,
                content=valid_content(),
                finish_reason="stop",
                usage=ChatUsage(1, 2, 3),
                latency_ms=1,
            )

    inventory = tmp_path / "inventory.json"
    inventory.write_text(
        json.dumps(
            {"models": [{"id": model} for model in (*ALLOWED_SMOKE_MODELS, "forbidden-terra")]}
        )
    )
    client = ValidClient()
    summary = await run_probe(
        secret=SECRET,
        inventory_path=inventory,
        client=client,  # type: ignore[arg-type]
    )
    assert summary.actual_logical_calls == 8
    assert len(client.calls) == 8
    assert {model for model, _case in client.calls} == set(ALLOWED_SMOKE_MODELS)
    assert "forbidden-terra" not in {model for model, _case in client.calls}
