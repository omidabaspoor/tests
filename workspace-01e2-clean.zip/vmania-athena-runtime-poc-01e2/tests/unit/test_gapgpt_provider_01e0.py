import os
from datetime import UTC, datetime
from pathlib import Path

import httpx
import pytest
from pydantic import ValidationError

from athena_runtime.providers.base import ModelDescriptor, ModelInventory
from athena_runtime.providers.errors import (
    MissingProviderSecret,
    ProviderAuthenticationError,
    ProviderRedirectError,
    ProviderResponseError,
)
from athena_runtime.providers.gapgpt import GapGPTConfig, GapGPTModelDiscoveryClient
from athena_runtime.providers.gapgpt_discover import atomic_write, write_inventory

SECRET = "test-secret-never-log"


async def no_sleep(seconds: float) -> None:
    del seconds


def response(status: int, payload: object, request: httpx.Request) -> httpx.Response:
    return httpx.Response(status, json=payload, request=request)


@pytest.mark.asyncio
async def test_g01_valid_200_returns_inventory() -> None:
    async def handler(request: httpx.Request) -> httpx.Response:
        assert request.method == "GET" and request.url.path == "/v1/models"
        assert request.headers["Authorization"] == f"Bearer {SECRET}"
        return response(
            200,
            {
                "object": "list",
                "data": [
                    {
                        "id": "model-alpha",
                        "owned_by": "provider",
                        "object": "model",
                        "created": 123,
                        "unknown": "ignored",
                    }
                ],
            },
            request,
        )

    inventory = await GapGPTModelDiscoveryClient(
        transport=httpx.MockTransport(handler)
    ).discover_models(SECRET)
    assert inventory.provider == "gapgpt"
    assert inventory.base_url_host == "api.gapgpt.app"
    assert inventory.models == (
        ModelDescriptor(id="model-alpha", owned_by="provider", object="model", created=123),
    )
    assert inventory.models[0].raw_capabilities == ()


@pytest.mark.asyncio
async def test_g02_missing_secret_fails_safely() -> None:
    with pytest.raises(MissingProviderSecret):
        await GapGPTModelDiscoveryClient(
            transport=httpx.MockTransport(lambda request: response(200, {"data": []}, request))
        ).discover_models("")


@pytest.mark.asyncio
async def test_g03_401_has_no_retry() -> None:
    calls = 0

    def handler(request: httpx.Request) -> httpx.Response:
        nonlocal calls
        calls += 1
        return response(401, {}, request)

    with pytest.raises(ProviderAuthenticationError):
        await GapGPTModelDiscoveryClient(
            transport=httpx.MockTransport(handler), sleep=no_sleep
        ).discover_models(SECRET)
    assert calls == 1


@pytest.mark.asyncio
async def test_g04_429_retries_only_once() -> None:
    calls = 0

    def handler(request: httpx.Request) -> httpx.Response:
        nonlocal calls
        calls += 1
        if calls == 1:
            return httpx.Response(429, headers={"Retry-After": "999"}, request=request)
        return response(200, {"data": []}, request)

    inventory = await GapGPTModelDiscoveryClient(
        transport=httpx.MockTransport(handler), sleep=no_sleep
    ).discover_models(SECRET)
    assert calls == 2 and inventory.models == ()


@pytest.mark.asyncio
async def test_g05_500_retries_only_once() -> None:
    calls = 0

    def handler(request: httpx.Request) -> httpx.Response:
        nonlocal calls
        calls += 1
        return response(500, {}, request)

    with pytest.raises(ProviderResponseError):
        await GapGPTModelDiscoveryClient(
            transport=httpx.MockTransport(handler), sleep=no_sleep
        ).discover_models(SECRET)
    assert calls == 2


@pytest.mark.asyncio
async def test_g06_redirect_fails_without_second_destination_request() -> None:
    calls = 0

    def handler(request: httpx.Request) -> httpx.Response:
        nonlocal calls
        calls += 1
        return httpx.Response(
            302, headers={"Location": "https://evil.example/models"}, request=request
        )

    with pytest.raises(ProviderRedirectError):
        await GapGPTModelDiscoveryClient(transport=httpx.MockTransport(handler)).discover_models(
            SECRET
        )
    assert calls == 1


@pytest.mark.asyncio
async def test_g07_malformed_json_fails() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, content=b"{broken", request=request)

    with pytest.raises(ProviderResponseError, match="malformed"):
        await GapGPTModelDiscoveryClient(transport=httpx.MockTransport(handler)).discover_models(
            SECRET
        )


@pytest.mark.asyncio
async def test_g08_oversized_response_fails() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, content=b"x" * 101, request=request)

    with pytest.raises(ProviderResponseError, match="size"):
        await GapGPTModelDiscoveryClient(
            GapGPTConfig(max_response_bytes=100),
            transport=httpx.MockTransport(handler),
        ).discover_models(SECRET)


@pytest.mark.asyncio
async def test_g09_invalid_model_id_is_rejected() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return response(200, {"data": [{"id": "bad id with spaces"}]}, request)

    with pytest.raises(ProviderResponseError, match="descriptor"):
        await GapGPTModelDiscoveryClient(transport=httpx.MockTransport(handler)).discover_models(
            SECRET
        )


@pytest.mark.asyncio
async def test_g10_duplicate_id_is_deduplicated_with_warning() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return response(
            200,
            {"data": [{"id": "same-model"}, {"id": "same-model"}]},
            request,
        )

    inventory = await GapGPTModelDiscoveryClient(
        transport=httpx.MockTransport(handler)
    ).discover_models(SECRET)
    assert [model.id for model in inventory.models] == ["same-model"]
    assert inventory.warnings == ("duplicate_model_id:same-model",)


@pytest.mark.asyncio
async def test_g11_errors_never_contain_secret() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return response(401, {}, request)

    with pytest.raises(ProviderAuthenticationError) as captured:
        await GapGPTModelDiscoveryClient(transport=httpx.MockTransport(handler)).discover_models(
            SECRET
        )
    assert SECRET not in str(captured.value)
    assert SECRET not in repr(captured.value)


def test_g12_non_https_base_url_is_rejected() -> None:
    with pytest.raises(ValidationError):
        GapGPTConfig(base_url="http://api.gapgpt.app/v1")


def test_g13_non_allowlisted_host_is_rejected() -> None:
    with pytest.raises(ValidationError):
        GapGPTConfig(base_url="https://evil.example/v1")


def test_g14_atomic_output_write(tmp_path: Path) -> None:
    target = tmp_path / "nested" / "inventory.json"
    atomic_write(target, "first")
    atomic_write(target, "second")
    assert target.read_text() == "second"
    assert not list(target.parent.glob("*.tmp"))
    if os.name == "posix":
        assert target.stat().st_mode & 0o777 == 0o600
    inventory = ModelInventory(
        fetched_at=datetime.now(UTC),
        base_url_host="api.gapgpt.app",
        models=(ModelDescriptor(id="safe-model"),),
    )
    write_inventory(inventory, target, tmp_path / "inventory.md")
    assert SECRET not in target.read_text()


def test_g15_client_contains_no_generation_endpoints() -> None:
    source = Path("src/athena_runtime/providers/gapgpt.py").read_text(encoding="utf-8")
    forbidden = ("/chat", "chat/completions", "/images", "/embeddings", "client.post")
    assert all(token not in source for token in forbidden)
    assert 'client.stream("GET", "models")' in source
