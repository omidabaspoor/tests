import json
from pathlib import Path

import httpx
import pytest

from athena_runtime.providers.errors import (
    MissingProviderSecret,
    ProviderAuthenticationError,
    ProviderRedirectError,
)
from athena_runtime.providers.gapgpt_chat import (
    ALLOWED_SMOKE_MODELS,
    MAX_OUTPUT_TOKENS,
    ChatResponse,
    ChatUsage,
    GapGPTUnderstandingChatClient,
)
from athena_runtime.providers.gapgpt_smoke import (
    LOGICAL_CALL_CAP,
    SMOKE_CASES,
    SmokeRecord,
    SmokeSummary,
    run_smoke,
    write_summary,
)
from athena_runtime.providers.understanding import (
    StructuredParseError,
    parse_understanding,
)
from athena_runtime.providers.understanding_prompt import PROMPT_HASH, PROMPT_VERSION

SECRET = "mock-secret-not-for-logs"


def valid_understanding(**changes: object) -> str:
    value = {
        "task_type": "caption",
        "goal_summary": "synthetic classification",
        "slots": [
            {
                "name": "subject",
                "value": None,
                "status": "unknown",
                "confidence": 0.0,
            }
        ],
        "conflicts": [],
        "missing_hard_slots": ["subject"],
        "should_clarify": True,
        "clarification_slot": "subject",
        "freshness": "stable",
        "risk_category": "low",
        "warning_required": False,
        "required_capability": "text_generation",
    }
    value.update(changes)
    return json.dumps(value, ensure_ascii=False)


def envelope(request: httpx.Request, content: str, status: int = 200) -> httpx.Response:
    return httpx.Response(
        status,
        json={
            "model": "gpt-5.6-luna",
            "choices": [
                {
                    "message": {"role": "assistant", "content": content},
                    "finish_reason": "stop",
                }
            ],
            "usage": {
                "prompt_tokens": 10,
                "completion_tokens": 20,
                "total_tokens": 30,
            },
        },
        request=request,
    )


async def no_sleep(seconds: float) -> None:
    del seconds


def test_p01_model_allowlist_is_exact() -> None:
    assert ALLOWED_SMOKE_MODELS == (
        "gpt-5.6-luna",
        "gemini-3.6-flash",
        "claude-sonnet-5",
        "gpt-5.6-sol",
    )


@pytest.mark.asyncio
async def test_p02_model_outside_allowlist_is_rejected() -> None:
    with pytest.raises(ValueError, match="allowlist"):
        await GapGPTUnderstandingChatClient(
            transport=httpx.MockTransport(lambda request: envelope(request, valid_understanding()))
        ).understand(model="forbidden-opus", synthetic_user_input="synthetic", secret=SECRET)


@pytest.mark.asyncio
async def test_p03_missing_secret_fails_safely() -> None:
    with pytest.raises(MissingProviderSecret):
        await GapGPTUnderstandingChatClient().understand(
            model=ALLOWED_SMOKE_MODELS[0], synthetic_user_input="synthetic", secret=""
        )


@pytest.mark.asyncio
async def test_p04_request_body_is_bounded_and_correct() -> None:
    async def handler(request: httpx.Request) -> httpx.Response:
        body = json.loads(await request.aread())
        assert request.url.path == "/v1/chat/completions"
        assert body["model"] == "gpt-5.6-luna"
        assert body["temperature"] == 0
        assert body["max_tokens"] == MAX_OUTPUT_TOKENS == 600
        assert body["stream"] is False
        assert len(body["messages"]) == 2
        assert "USER_INPUT_DATA_BEGIN" in body["messages"][1]["content"]
        assert "chain-of-thought" not in body["messages"][0]["content"].casefold()
        return envelope(request, valid_understanding())

    await GapGPTUnderstandingChatClient(transport=httpx.MockTransport(handler)).understand(
        model="gpt-5.6-luna", synthetic_user_input="یه کپشن میخوام", secret=SECRET
    )


@pytest.mark.asyncio
async def test_p05_redirect_fails_without_follow() -> None:
    calls = 0

    def handler(request: httpx.Request) -> httpx.Response:
        nonlocal calls
        calls += 1
        return httpx.Response(307, headers={"Location": "https://evil.example"}, request=request)

    with pytest.raises(ProviderRedirectError):
        await GapGPTUnderstandingChatClient(transport=httpx.MockTransport(handler)).understand(
            model="gpt-5.6-luna", synthetic_user_input="synthetic", secret=SECRET
        )
    assert calls == 1


@pytest.mark.asyncio
async def test_p06_401_has_no_retry() -> None:
    calls = 0

    def handler(request: httpx.Request) -> httpx.Response:
        nonlocal calls
        calls += 1
        return httpx.Response(401, request=request)

    with pytest.raises(ProviderAuthenticationError):
        await GapGPTUnderstandingChatClient(transport=httpx.MockTransport(handler)).understand(
            model="gpt-5.6-luna", synthetic_user_input="synthetic", secret=SECRET
        )
    assert calls == 1


@pytest.mark.asyncio
async def test_p07_429_retries_once() -> None:
    calls = 0

    def handler(request: httpx.Request) -> httpx.Response:
        nonlocal calls
        calls += 1
        return (
            httpx.Response(429, request=request)
            if calls == 1
            else envelope(request, valid_understanding())
        )

    await GapGPTUnderstandingChatClient(
        transport=httpx.MockTransport(handler), sleep=no_sleep
    ).understand(model="gpt-5.6-luna", synthetic_user_input="synthetic", secret=SECRET)
    assert calls == 2


def test_p08_malformed_json_is_recorded_as_fail() -> None:
    with pytest.raises(StructuredParseError) as captured:
        parse_understanding("{bad")
    assert captured.value.code == "MALFORMED_JSON"


def test_p09_code_fence_is_not_silently_cleaned() -> None:
    with pytest.raises(StructuredParseError) as captured:
        parse_understanding(f"```json\n{valid_understanding()}\n```")
    assert captured.value.code == "CODE_FENCE_NOT_ALLOWED"


def test_p10_extra_field_is_rejected() -> None:
    with pytest.raises(StructuredParseError) as captured:
        parse_understanding(valid_understanding(extra="forbidden"))
    assert captured.value.code == "SCHEMA_VALIDATION_FAILED"


def test_p11_oversized_structured_output_is_rejected() -> None:
    with pytest.raises(StructuredParseError) as captured:
        parse_understanding("x" * 40_000)
    assert captured.value.code == "OUTPUT_TOO_LARGE"


@pytest.mark.asyncio
async def test_p12_usage_model_and_latency_are_captured() -> None:
    client = GapGPTUnderstandingChatClient(
        transport=httpx.MockTransport(lambda request: envelope(request, valid_understanding()))
    )
    result = await client.understand(
        model="gpt-5.6-luna", synthetic_user_input="synthetic", secret=SECRET
    )
    assert result.response_model == "gpt-5.6-luna"
    assert result.usage == ChatUsage(10, 20, 30)
    assert result.latency_ms >= 0


def test_p13_artifact_schema_has_no_secret_prompt_or_raw_response(tmp_path: Path) -> None:
    record = SmokeRecord(
        case_id="U01",
        requested_model="gpt-5.6-luna",
        status="SUCCESS",
        parse_status="DIRECT_JSON",
        schema_status="VALID",
    )
    summary = SmokeSummary(
        prompt_version=PROMPT_VERSION,
        prompt_hash=PROMPT_HASH,
        logical_call_cap=20,
        planned_calls=20,
        available_models=("gpt-5.6-luna",),
        missing_models=ALLOWED_SMOKE_MODELS[1:],
        records=(record,),
    )
    json_path, markdown_path = tmp_path / "summary.json", tmp_path / "summary.md"
    write_summary(summary, json_path, markdown_path)
    combined = json_path.read_text() + markdown_path.read_text()
    assert SECRET not in combined
    assert "یه کپشن میخوام" not in combined
    assert "SYSTEM_INSTRUCTION" not in combined
    assert "raw_response" not in combined


def test_p14_logical_call_cap_is_exactly_20() -> None:
    assert len(ALLOWED_SMOKE_MODELS) == 4
    assert len(SMOKE_CASES) == 5
    assert LOGICAL_CALL_CAP == 20


@pytest.mark.asyncio
async def test_p15_runner_never_calls_model_outside_allowlist(tmp_path: Path) -> None:
    class FakeClient:
        def __init__(self) -> None:
            self.calls: list[str] = []

        async def understand(
            self, *, model: str, synthetic_user_input: str, secret: str
        ) -> ChatResponse:
            del synthetic_user_input, secret
            self.calls.append(model)
            return ChatResponse(
                requested_model=model,
                response_model=model,
                content=valid_understanding(),
                finish_reason="stop",
                usage=ChatUsage(1, 1, 2),
                latency_ms=1,
            )

    inventory = tmp_path / "inventory.json"
    inventory.write_text(
        json.dumps(
            {"models": [{"id": model} for model in (*ALLOWED_SMOKE_MODELS, "forbidden-terra")]}
        )
    )
    fake = FakeClient()
    summary = await run_smoke(
        secret=SECRET,
        inventory_path=inventory,
        client=fake,  # type: ignore[arg-type]
    )
    assert len(fake.calls) == 20
    assert set(fake.calls) == set(ALLOWED_SMOKE_MODELS)
    assert "forbidden-terra" not in fake.calls
    assert len(summary.records) == 20
