# GapGPT Structured Capability 01E.2 — Test Results

هیچ Request واقعی GapGPT ارسال نشد. همه HTTP tests از MockTransport استفاده کردند.

## J01–J12

| ID | Result |
|---|---|
| J01 strict json_schema request | PASS_MOCK |
| J02 all fields required | PASS_STATIC |
| J03 all objects additionalProperties=false | PASS_STATIC |
| J04 400 unsupported/no retry | PASS_MOCK |
| J05 valid schema parse | PASS |
| J06 extra field reject | PASS |
| J07 diagnostic excludes input/url | PASS |
| J08 artifact excludes raw/prompt/secret | PASS |
| J09 call cap=8 | PASS |
| J10 no fallback/retry | PASS_STATIC |
| J11 finish length fail | PASS |
| J12 four-model allowlist only | PASS_MOCK |

Full Unit/Security suite: **173 passed, 37 integration deselected**. Ruff و compileall نیز PASS هستند.

## Security

- Secret واقعی موجود/استفاده نشد.
- API key، Authorization، raw response، full prompt و system prompt در Artifact schema نیستند.
- Workflow دستی است و اجرا نشده است.
- Inventory واقعی و model capability فقط در GitHub Actions آینده مشخص می‌شود.
