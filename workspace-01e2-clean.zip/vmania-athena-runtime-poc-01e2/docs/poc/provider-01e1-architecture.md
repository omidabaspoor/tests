# GapGPT Structured Understanding Smoke — 01E.1

## Scope

این مرحله فقط Adapter محدود `POST /v1/chat/completions` برای 4 مدل allowlisted و 5 ورودی کاملاً ساختگی را آماده می‌کند. هیچ Call واقعی در Agent انجام نشده است. Streaming، Tool، Image، Search، Memory، Router production mapping و endpoint عمومی وجود ندارند.

## Allowlist and budget

Models فقط:

- `gpt-5.6-luna`
- `gemini-3.6-flash`
- `claude-sonnet-5`
- `gpt-5.6-sol`

Caseها U01–U05 ثابت و synthetic هستند. سقف logical call دقیقاً 20 است. هر logical call حداکثر یک retry دارد؛ repair call وجود ندارد. Inventory قبل از Smoke خوانده می‌شود و مدل غایب با `MODEL_UNAVAILABLE` ثبت و call نمی‌شود.

## Adapter

`GapGPTUnderstandingChatClient` از config امن 01E.0 استفاده می‌کند: HTTPS/host allowlist، TLS verify، redirects off، proxy environment off، timeout و response byte ceiling. Request ثابت است:

- temperature=0
- max_tokens=600
- stream=false
- system/user messages only

401/403/400/404/redirect بدون retry؛ 429/500/502/503/504 و timeout فقط یک retry. پارامتر جایگزین یا random probing وجود ندارد.

## Prompt and parsing

Prompt version `understanding-smoke-0.1` است. System instruction کوتاه، ثابت، JSON-only و classification/extraction-only است. User text داخل `USER_INPUT_DATA_BEGIN/END` untrusted data است. Artifact فقط prompt version/hash را دارد؛ prompt کامل، system text و synthetic input ذخیره نمی‌شوند.

Parser مستقیم `json.loads` می‌کند. Code fence fail است و silently strip نمی‌شود. سپس Pydantic strict/extra-forbid schema validate می‌شود. Output بیش از 32768 bytes fail است. Raw response فقط تا parse در حافظه local call می‌ماند.

## Artifact

هر record فقط model/case IDs، status، latency، usage، finish reason، parse/schema status، selected classifications، score booleans و safe error code دارد. API key، Authorization، full prompt، synthetic user input، raw response و system prompt field وجود ندارد.

## Manual execution

Workflow `gapgpt-understanding-smoke.yml` فقط `workflow_dispatch` است. ابتدا unit tests، سپس model discovery/inventory confirmation، plan=20، smoke و upload artifact با retention سه روز انجام می‌شود. Failure یک مدل مانع ادامه مدل‌های دیگر نمی‌شود.
