# GapGPT JSON Schema Capability Probe — 01E.2

## Purpose

این Probe فقط بررسی پشتیبانی واقعی `response_format.type=json_schema` را آماده می‌کند. هیچ Call واقعی در Arena انجام نشده است. چهار Model allowlisted و دو Case synthetic دارد؛ Chat production، fallback، repair، retry، streaming، Tool و Image وجود ندارند.

## Schema

- Version: `athena-understanding-schema-0.1`
- SHA-256: `02faf0201b6e88c5b31aa0c7b999836a9273d9f04724b8c24a02651345c21b72`

Root و Slot object هر دو `additionalProperties=false` دارند. تمام 11 field required هستند، از جمله nullable `clarification_slot`. Enumها، string/array lengths، confidence 0..1 و slot scalar/null value صریح‌اند. Keyword غیرضروری یا capability ناشناخته استفاده نشده است.

Request شامل strict response format، temperature=0، max_tokens=300 و stream=false است. Prompt کوتاه فقط classification/extraction، data boundary و منع final answer/private reasoning را می‌گوید؛ Schema را در متن تکرار نمی‌کند. Artifact فقط prompt/schema version و hash دارد.

## Stair-step plan

- Stage A: C01 روی هر 4 model allowlisted؛ حداکثر 4 call.
- Stage B: C02 فقط برای modelهای Schema-Valid Stage A؛ 0..4 call.
- Hard cap: 8 logical calls.
- Retry، repair، fallback به json_object/prompt-only و token increase ممنوع است.

Inventory قبل از Probe خوانده می‌شود. Model غایب call نمی‌شود. 400/422 به `STRUCTURED_OUTPUT_UNSUPPORTED` تبدیل می‌شود و مدل وارد Stage B نمی‌شود. Failure یک مدل، سایر مدل‌ها را متوقف نمی‌کند.

## Diagnostics

Artifact فقط length، first non-whitespace character، code-fence flag، finish reason، response format mode و اولین Pydantic error location/type/message sanitize‌شده را دارد. `errors(include_input=False, include_url=False)` استفاده می‌شود. Raw content/prompt/system/API key/header ذخیره نمی‌شود.

Finish reason `length` همیشه Fail است و max token خودکار افزایش نمی‌یابد. Usage/latency و requested/response model بدون تفسیر ثبت می‌شوند.

## Manual workflow

`.github/workflows/gapgpt-structured-capability.yml` فقط workflow_dispatch است: unit tests، discovery، plan=8، Probe و artifact سه‌روزه. اجرای واقعی به GitHub Secret وابسته و در این Workspace انجام نشده است.
